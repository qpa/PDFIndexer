/*
* ===========================================
* Java Pdf Extraction Decoding Access Library
* ===========================================
*
* Project Info:  http://www.jpedal.org
* Project Lead:  Mark Stephens (mark@idrsolutions.com)
*
* (C) Copyright 2003, IDRsolutions and Contributors.
* 
* 	This file is part of JPedal
*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*
* ---------------
* PdfFilteredReader.java
* ---------------
* (C) Copyright 2002, by IDRsolutions and Contributors.
*
* Original Author:  Mark Stephens (mark@idrsolutions.com)
* Contributor(s):
*
*/
package org.jpedal.io;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.zip.Inflater;

import javax.media.jai.JAI;

import org.jpedal.sun.LZWDecoder;
import org.jpedal.sun.TIFFFaxDecoder;
import org.jpedal.sun.TIFFLZWDecoder;
import org.jpedal.utils.LogWriter;
import org.jpedal.utils.Strip;

/**
 * Adds the abilty to decode streams to the PdfFIleReader class
 */
public class PdfFilteredReader extends PdfFileReader {

	/**lookup for ASCII85 decode*/
	private final static long[] base_85_indices =
		{ 85 * 85 * 85 * 85, 85 * 85 * 85, 85 * 85, 85, 1 };

	/**lookup for hex multiplication*/
	private final static long[] hex_indices =
		{ 256 * 256 * 256, 256 * 256, 256, 1 };

	//////////////////////////////////////////////////////////////////////////
	/**
	 * main routine which is passed list of filters to decode
	 * and the binary data. JPXDecode/DCTDecode are not handled here (we leave data
	 * as is and then put straight into a JPEG)<br>
	 * <p><b>Note</b></p>Not part of API</p>
	 */
	final public byte[] decodeFilters(byte[] data,String filter_list,Map objData,int width,int height,boolean useNewCCITT) throws Exception{
		
		Map decodeParams = new Hashtable();	
		
		//put params in Map
		if(objData!=null){
			Object rawParams= objData.get("DecodeParms");
			if(rawParams!=null){
				
				if(rawParams instanceof String){
					convertStringToMap(decodeParams, rawParams);
				}else
					decodeParams=(Hashtable) rawParams;
			}
		}
		
		//make sure no []
		if (filter_list.startsWith("[")) {
			if (filter_list.endsWith("]"))
				filter_list = filter_list.substring(1, filter_list.length() - 1);
			else
				filter_list = filter_list.substring(1);
		} else if (filter_list.endsWith("]"))
			filter_list = filter_list.substring(0, filter_list.length() - 1);
		
		String filter_type;

		//allow for no filters
		if (filter_list.length() > 0) {
			
			//decode each filter in turn
			StringTokenizer filters_to_decode =new StringTokenizer(filter_list);

			//turn into list we can scan
			while (filters_to_decode.hasMoreTokens()){

			/**
			 * apply each filter
			 */

				filter_type = filters_to_decode.nextToken();
						
				//decode filters (load data for first one)
				if (filter_type.startsWith("/")) {
					
					//apply decode
					if((filter_type.indexOf("/FlateDecode") != -1)|(filter_type.indexOf("/Fl") != -1)){
						data = flateDecode(data, decodeParams);
						
					}else if ((filter_type.indexOf("/ASCII85Decode") != -1)|(filter_type.indexOf("/A85") != -1))
						data = ascii85Decode(data);
					else if (isCCITTEncoded(filter_type)){
						if(useNewCCITT){
 
							TiffDecoder decode= new TiffDecoder(width, height,decodeParams,data);
							data=decode.getRawBytes();
							
						}else{
							
							data=ccittDecode(data, decodeParams,width,height);
							
						}
					}else if (filter_type.indexOf("/LZW") != -1)
						data = lzwDecode(data, decodeParams,width,height);
					else if( (filter_type.indexOf("/RunLengthDecode") != -1)| (filter_type.indexOf("/RL") != -1))
						data = runLengthDecode(data);	
					else if( (filter_type.indexOf("/ASCIIHexDecode") != -1)|(filter_type.indexOf("/AHx") != -1))
						data = asciiHexDecode(data);						
					else if((filter_type.indexOf("/DCTDecode") == -1)&&(filter_type.indexOf("/JPXDecode")==-1)){
						LogWriter.writeLog("[PDF] Unsupported decompression stream "+filter_type);
						data=null;
					}
				}
			}
		}
		
		return data;
	}


	/**
	 * @param decodeParams
	 * @param rawParams
	 */
	public void convertStringToMap(Map decodeParams, Object rawParams) {
		StringTokenizer paraValues=new StringTokenizer(Strip.removeArrayDeleminators((String)rawParams));
		while(paraValues.hasMoreTokens()){
			String value=paraValues.nextToken();
			
			if(value.startsWith("<<"))
				value=value.substring(2).trim();
			
			if(value.startsWith("/")){
				String key=value.substring(1);
				value=paraValues.nextToken();
				if(value.endsWith(">>"))
					value=value.substring(0,value.length()-2).trim();
				
				decodeParams.put(key,value);
			}
		}
	}


	/**
	 *Run length decode
	 */
	private byte[] runLengthDecode(byte[] data) throws Exception{
		
		ByteArrayOutputStream bos= new ByteArrayOutputStream(data.length);
		
		for(int i=0;i<data.length;i++){	
			
				int len=data[i];
				
				if(len<0)
					len=256+len;
				
				if(len==128){
					
					i=data.length;
					
				}else if(len>128){
					
					i++;
					len=257-len;
					
					for(int j=0;j<len;j++)
					bos.write(data[i]);
					
		  		}else{
					i++;
		  			len++;
					for(int j=0;j<len;j++)
					bos.write(data[i+j]);
					i=i+len-1;
				}
				
		}
		  
		bos.close();
		
		return bos.toByteArray();
		
	}
	//////////////////////////////////////////////////
	/**
	 * lzw decode using adobes class

	 private byte[] lzwDecode(byte[] data,String filter_list,
	 String decode_params){

	 Object key;
	 Object value;
	 byte[] processed_data=null;

	 Integer Predictor=new Integer(1);
	 Integer Colors=new Integer(1);
	 Integer BitsPerComponent=new Integer(8);
	 Integer Columns=new Integer(1);
	 Integer EarlyChange=new Integer(1);

	 try{

	 //put params in object
	 FilterParams params=new FilterParams();

	 //reset vales
	 StringTokenizer values=new StringTokenizer(decode_params,"< >");
	 while(values.hasMoreTokens()){
	 key=values.nextToken();
	 String test=key.toString();

	 if(test.startsWith("/")){
	 value=values.nextElement();

	 //set values
	 if(test.equals("/Predictor"))
	 Predictor=new Integer(value.toString());
	 if(test.equals("/Colors"))
	 Colors=new Integer(value.toString());
	 if(test.equals("/BitsPerComponent"))
	 BitsPerComponent=new Integer(value.toString());
	 if(test.equals("/Columns"))
	 Columns=new Integer(value.toString());
	 if(test.equals("/EarlyChange"))
	 EarlyChange=new Integer(value.toString());
	 }
	 }

	 params.put("Predictor",Predictor);
	 params.put("Colors",Colors);
	 params.put("BitsPerComponent",BitsPerComponent);
	 params.put("Columns",Columns);
	 params.put("EarlyChange",EarlyChange);

	 LZWInputStream lzw_filter=
	 new LZWInputStream(new BufferedInputStream(new ByteArrayInputStream(data)),params);

	 ByteArrayOutputStream out=new ByteArrayOutputStream();
	 byte[] buffer = new byte[4096];
	 int bytes_read;

	 //loop to write the data
	 while((bytes_read =lzw_filter.read(buffer))!=-1)
	 out.write(buffer,0,bytes_read);

	 //close and get the data
	 lzw_filter.close();
	 out.close();

	 processed_data=out.toByteArray();

	 }catch(Exception e){
	 LogWriter.writeLog("Exception "+e+" accessing LZW filter");
	 }

	 return processed_data;
	 }
	 */
	//////////////////////////////////////////////////
	/**
	 * lzw decode using our own class
	 */
	final private byte[] lzwDecode(
		byte[] data,
		Map values,int width,int height) throws Exception{

		//default values
		int predictor = 1;
		//int Colors=1;
		int BitsPerComponent = 8;
		int EarlyChange=1;
		int rows=height,columns=width;
			
		//get Predictor
		String value = (String) values.get("Predictor");
		if (value != null)
			predictor = Integer.parseInt(value);
			
		value = (String) values.get("Rows");
		if (value != null)
		rows = Integer.parseInt(value);	
			
		value = (String) values.get("Columns");
		if (value != null)
		columns= Integer.parseInt(value);	
		
		value = (String) values.get("EarlyChange");
		if (value != null)
		EarlyChange= Integer.parseInt(value);	
		
		//get BitsPerComponent
		value = (String) values.get("BitsPerComponent");
		if (value != null)
			BitsPerComponent = Integer.parseInt(value);
			
		if(rows*columns==1){		
				
		byte[] processed_data = new byte[BitsPerComponent*rows*((columns+7)>>3)]; //will be resized if needed 9allow for not a full 8 bits
		
		//byte[] processed_data = new byte[(rows*columns/(8/BitsPerComponent))]; //will be resized if needed
		
		TIFFLZWDecoder lzw_decode =new TIFFLZWDecoder(columns, predictor, BitsPerComponent);
		
		lzw_decode.decode(data, processed_data, rows);
		
		return applyPredictor(predictor, values, processed_data);
		
		}else{ //version for no parameters
			ByteArrayOutputStream processed = new ByteArrayOutputStream();
			LZWDecoder lzw = new LZWDecoder();
			
			lzw.decode(data, processed);

			processed.close();
			return applyPredictor(predictor, values, processed.toByteArray());
		}
		
		
	}
	///////////////////////////////////////////////////////////////////////////
	/**
	 * ccitt decode using adobes class

	 private byte[] ccittDecodeAdobe(byte[] data,String filter_list,
	 String decode_params){

	 //default paramter values
	 Integer K=new Integer(0);
	 Boolean EndOfLine=new Boolean(false);
	 Boolean EncodedByteAlign=new Boolean(false);
	 Integer Columns=new Integer(1728);
	 Integer Rows=new Integer(0);
	 Boolean EndOfBlock=new Boolean(true);
	 Boolean Blackls1=new Boolean(false);
	 Integer DamagedRowsBeforeError=new Integer(000);

	 Object key;
	 Object value;
	 byte[] processed_data=null;

	 try{
	 //put params in object
	 FilterParams params=new FilterParams();

	 //reset vales
	 StringTokenizer values=new StringTokenizer(decode_params,"< >");
	 while(values.hasMoreTokens()){
	 key=values.nextToken();
	 String test=key.toString();

	 if(test.startsWith("/")){
	 value=values.nextElement();

	 //set values
	 if(test.equals("/K"))
	 K=new Integer(value.toString());
	 if(test.equals("/EndOfLine"))
	 EndOfLine=new Boolean(value.toString());
	 if(test.equals("/EncodedByteAlign"))
	 EncodedByteAlign=new Boolean(value.toString());
	 if(test.equals("/Columns"))
	 Columns=new Integer(value.toString());
	 if(test.equals("/Rows"))
	 Rows=new Integer(value.toString());
	 if(test.equals("/EndOfBlock"))
	 EndOfBlock=new Boolean(value.toString());
	 if(test.equals("/Blackls1"))
	 Blackls1=new Boolean(value.toString());
	 if(test.equals("/DamagedRowsBeforeError"))
	 DamagedRowsBeforeError=new Integer(value.toString());

	 }
	 }

	 //put in values
	 params.put("K",K);
	 params.put("EndOfLine",EndOfLine);
	 params.put("EncodedByteAlign",EncodedByteAlign);
	 params.put("Columns",Columns);
	 params.put("Cols",Columns);
	 params.put("Rows",Rows);
	 params.put("EndOfBlock",EndOfBlock);
	 params.put("Blackls1",Blackls1);
	 params.put("DamagedRowsBeforeError",DamagedRowsBeforeError);

	 CCITTFaxInputStream CCITT_filter=
	 new CCITTFaxInputStream(new BufferedInputStream(new ByteArrayInputStream(data)),params);

	 ByteArrayOutputStream out=new ByteArrayOutputStream();
	 byte[] buffer = new byte[4096];
	 int bytes_read;

	 //loop to write the data
	 while((bytes_read =CCITT_filter.read(buffer))!=-1)
	 out.write(buffer,0,bytes_read);

	 //close and get the data
	 CCITT_filter.close();
	 out.close();

	 processed_data=out.toByteArray();

	 }catch(Exception e){
	 LogWriter.writeLog("Exception "+e+" accessing CCITT filter");
	 }

	 ShowGUIMessage.showGUIMessage("CCITT used","CCITT used");

	 return processed_data;
	 }
	 */
	
	///////////////////////////////////////////////////////////////////////////
	/**
	 * ccitt decode using Sun class
	 */
	final private byte[] ccittDecode(
		byte[] data,
		Map values,int width,int height) throws Exception{
		
		//flag to show if default is black or white
		boolean isBlack = false;
		int columns = 1728;
		int rows = height;
		int k = 0;
		boolean isByteAligned=false;
		
		
		//get k
		String value = (String) values.get("K");
		if (value != null)
			k = Integer.parseInt(value);

//		get flag for white/black as default
		value = (String) values.get("EncodedByteAlign");
		if (value != null)
		    isByteAligned = Boolean.valueOf(value).booleanValue();
		
		//get flag for white/black as default
		value = (String) values.get("BlackIs1");
		if (value != null)
			isBlack = Boolean.valueOf(value).booleanValue();
		
		value = (String) values.get("Rows");
		if (value != null)
		rows = Integer.parseInt(value);	
		
		value = (String) values.get("Columns");
		if (value != null)
		columns= Integer.parseInt(value);	
		
		byte[] processed_data = new byte[rows*((columns+7)>>3)]; //will be resized if needed 9allow for not a full 8 bits
		
		try {
			
			TIFFFaxDecoder tiff_decode = new TIFFFaxDecoder(1, columns, rows);
			
			//use Sun TIFFFaxDecoder class
			if (k == 0)
				tiff_decode.decode1D(processed_data, data, 0, rows);
			else if (k > 0)
				tiff_decode.decode2D(processed_data, data, 0, rows, 0);
			else if (k < 0)
				tiff_decode.decodeT6(processed_data, data, 0, rows, 0,isByteAligned);
			
			//invert image if needed -
			//ultimately will be quicker to add into decode
			if (!isBlack) {
				for (int i = 0; i < processed_data.length; i++)
					processed_data[i] = (byte) (255 - processed_data[i]);
			}
		} catch (Exception e) {
			LogWriter.writeLog("Exception " + e + " accessing CCITT filter "+e);
			
		}
		
		return processed_data;
	}
	//////////////////////////////////////////////////
	/**
	 * ascii85decode using our own implementation
	 */
	final private byte[] ascii85Decode(byte[] data) {
		int special_cases = 0;
		String line="";
		StringBuffer valuesRead=new StringBuffer();
		
		BufferedReader mappingStream=null;
		ByteArrayInputStream bis=null;
		
		//read in ASCII mode to handle line returns
		try {
			bis=new ByteArrayInputStream(data);
			mappingStream =new BufferedReader(new InputStreamReader(bis));
			
			//read values into lookup table
			if (mappingStream != null) {
				
				while (true) {
					line = mappingStream.readLine();
					
					if (line == null)
						break;
					
					//append to XML data
					valuesRead.append(line);
					
				}
			}
			
		} catch (Exception e) {
			LogWriter.writeLog("Exception " + e + " reading ASCII stream ");
			
		}
		
		if(mappingStream!=null){
			try {
				mappingStream.close();
				bis.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
		int data_size = valuesRead.length();
		
		//allow for special cases
		for (int i = 0; i < data_size; i++) {
			if (valuesRead.charAt(i) == 122)
				special_cases++;
		}
		
		//pointer in output buffer
		int output_pointer = 0;
		long value = 0;
		
		//buffer to hold data
		byte[] temp_data = new byte[data_size + 1 + (special_cases * 3)];
		int ii = 0;
		
		/**
		 * translate each set of 5 to 4 bytes
		 * (note lookup tables)
		 */
		
		//5 bytes in base 85
		for (int i = 0; i < data_size; i ++) {
			value = 0;
			
			//check special case first
			if (valuesRead.charAt(i) == 122) {
				
				//and write out 4 bytes
				for (int i3 = 0; i3 < 4; i3++) {
					temp_data[output_pointer] = 0;
					output_pointer++;
				}
			} else if ((data_size-i>4)&&(valuesRead.charAt(i) > 32) & (valuesRead.charAt(i) < 118)) {
				for (ii = 0; ii < 5; ii++)
					value = value + ((valuesRead.charAt(i+ii) - 33) * base_85_indices[ii]);
				
				//and write out 4 bytes
				for (int i3 = 0; i3 < 4; i3++) {
					temp_data[output_pointer] =
						(byte) ((value / hex_indices[i3]) & 255);
					output_pointer++;
				}
				i=i+4;
			}
		}
		
		//now put values into processed data
		byte[] processed_data = new byte[output_pointer];
		System.arraycopy(temp_data, 0, processed_data, 0, output_pointer);
		
		
		return processed_data;
	}
	
	/**
	 * asciihexdecode using our own implementation
	 */
	final private byte[] asciiHexDecode(byte[] data) throws IOException {
		
		String line="";
		StringBuffer value=new StringBuffer();
		StringBuffer valuesRead=new StringBuffer();
		BufferedReader mappingStream=null;
		ByteArrayInputStream bis=null;
		
		//read in ASCII mode to handle line returns
		try {
			bis=new ByteArrayInputStream(data);
			mappingStream =new BufferedReader(new InputStreamReader(bis));
			
			//read values into lookup table
			if (mappingStream != null) {
				
				while (true) {
					line = mappingStream.readLine();
					
					if (line == null)
						break;
					
					//append to  data
					valuesRead.append(line);
					
				}
			}
			
		} catch (Exception e) {
			LogWriter.writeLog("Exception " + e + " reading ASCII stream ");
			
		}
		
		if(mappingStream!=null){
			try {
				mappingStream.close();
				bis.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
		int data_size = valuesRead.length();
		int i=0,count=0;
		char current=' ';
		
		ByteArrayOutputStream bos= new ByteArrayOutputStream(data.length);
		
		/**loop to read and process*/
		while(true){
			
			current=valuesRead.charAt(i);
			
			if(((current>='0')&(current<='9'))|
					((current>='a')&(current<='f'))|
					((current>='A')&(current<='F'))){
				value.append(current);
				if(count==1){
					bos.write(Integer.valueOf(value.toString(),16).intValue());
					count=0;
					value=new StringBuffer();
				}else
					count++;
				
			}
			
			if(current=='>')
				break;
			
			i++;
			
			if(i==data_size)
				break;
		}  
		
		//write any last char
		if(count==1){
			value.append('0');
			bos.write(Integer.valueOf(value.toString(),16).intValue());
		}
		
		bos.close();
		
		return bos.toByteArray();
	}
	
        /**
	   * flate decode
	   * - use a byte array stream to decompress data in memory
	   */
	  final private byte[] flateDecode(byte[] data, Map params) throws Exception {

        int predictor = 1;
        String value = (String) params.get("Predictor");
        if (value != null)
            predictor = Integer.parseInt(value);

        /**
        FileOutputStream fos=new FileOutputStream(data.length+".comp");
        fos.write(data);
        System.out.println("Writing "+data.length);
        fos.close();
        /**/
        
        //InflaterInputStream inf = new java.util.zip.InflaterInputStream(
          //      new ByteArrayInputStream(data));
        
        /**/
         // create a inflater and initialize it Inflater inf=new Inflater();
         Inflater inf = new Inflater();
         
         inf.setInput(data); 
          
         int size=data.length;
         ByteArrayOutputStream bos= new ByteArrayOutputStream(size);
         
         int bufSize=512000;
         if(size<bufSize)
             bufSize=size;
        
         byte[] buf=new byte[bufSize]; int debug=20; 
         int count;
         while(!inf.finished()) {
           
         count=inf.inflate(buf);
             //System.out.println(data.length+" "+count+" "+inf.getRemaining()+" "+inf.getTotalIn()+" "+inf.getTotalOut()+" "+inf.finished());
             bos.write(buf,0,count);
         
	         if(inf.getRemaining()==0)
         	break;
         //System.out.println("ammount done="+count+" isfinished="+inf.finished()+" bytesin input buffer left="+inf.getRemaining());
         
         
         }
         
/**
        ByteArrayOutputStream bos = new ByteArrayOutputStream(data.length);

        while (true) {
            int i = inf.read();
            if (i == -1)
                break;
            bos.write(i);
            
            System.out.println(inf.available()+" "+i);

        }
*/
		/**
        ByteArrayOutputStream bos= new ByteArrayOutputStream(data.length);
//  	byte[] buf=new byte[1024]; int debug=20; 
 		 // Compress the bytes
        int done=0;
        int debug=20;
		 byte[] output2 = new byte[1970000];
		 Inflater compresser2 = new Inflater();
		 compresser2.setInput(data);
		 //compresser2.finish();
		 while(true){
		 	done = compresser2.inflate(output2);
		 	//System.out.println(done);
		 	bos.write(output2,0,done);
		 	
		 	//if(debug<0){
		 	//	System.out.println("debug exit");
		 	//	break;//System.exit(1);
		 	//}
		 	if(done==0)
		 		debug--;
		 	//if(compresser2.getRemaining()==0){
		 	//	System.out.println("remaining=0");
		 	//	System.exit(1);
		 	//}
		 	if(compresser2.finished()){
		 		System.out.println("finished"+debug);
		 		break;//System.exit(1);
		 	}
		 	if((done==0)){
		 		System.out.println("done=0");
		 		break;//System.exit(1);
		 	}
		 	if(false)
		 		break;
		 }
		 
		//int count,i=0;
 		//while(i<tSize.length()) {
 		//	i=i+1024;
 		//	count=compression.deflate(buf);
 		//	bos.write(buf,0,buf.length);
 		//}
 		System.out.println("size="+data.length+" amount done="+done+" isfinished="+compresser2.finished()+" bytesin input buffer left="+compresser2.getRemaining()+" totalouputed="+compresser2.getTotalOut());
 		/**/
 		
        bos.flush();
        bos.close();
        /**
        FileOutputStream fos2=new FileOutputStream(data.length+".def");
        System.out.println("Writing "+data.length);
        fos2.write(bos.toByteArray());
        fos2.close();
        /**/
        return applyPredictor(predictor, params, bos.toByteArray());

    }
	  
	 private byte[] applyPredictor(int predictor,Map params, byte[] data) throws Exception{
	 	
	 	if((predictor!=1)&(predictor!=10)){
	 		
	 		ByteArrayOutputStream bos= new ByteArrayOutputStream(data.length);
	 		ByteArrayInputStream in=new ByteArrayInputStream(data);
	 		DecodePredictor is =  new DecodePredictor(in, predictor,params);
	 		
	 		while(true){
	 			int current=is.read(in);
	 			
	 			if(current==-1)
	 				break;	
	 			
	 			bos.write(current);
	 		}
	 		
	 		bos.close();
	 		in.close();
	 		is=null;
	 		in=null;
	 		data=bos.toByteArray();
	 	}
	 	
	 	return data;
	 	
	 }

	 /**decide if we convert straight to image or into byte stream so we
	  * can manipulate further
	  */
	private boolean isCCITTEncoded(String filter) {
		if(filter==null)
			return false;
		else
			return ((filter.startsWith("/CCITT"))|(filter.startsWith("/CCF")));
	}
	

}

