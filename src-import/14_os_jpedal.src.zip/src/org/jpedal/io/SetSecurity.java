/*
 * Created on 28-Apr-2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package org.jpedal.io;

import java.security.Security;

/**
 * @author markee
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class SetSecurity {

	
	public static void init(){
		
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		
	}
}
