/*
* ===========================================
* Java Pdf Extraction Decoding Access Library
* ===========================================
*
* Project Info:  http://www.jpedal.org
* Project Lead:  Mark Stephens (mark@idrsolutions.com)
*
* (C) Copyright 2003, IDRsolutions and Contributors.
*
* 	This file is part of JPedal
*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*
* ---------------
* ICCColorSpace.java
* ---------------
* (C) Copyright 2003, by IDRsolutions and Contributors.
*
* Original Author:  Mark Stephens (mark@idrsolutions.com)
* Contributor(s):
*
*
*/
package org.jpedal.color;

import java.awt.Color;
import java.awt.color.ColorSpace;
import java.awt.color.ICC_ColorSpace;
import java.awt.color.ICC_Profile;
import java.awt.image.BufferedImage;

import org.jpedal.exception.PdfException;
import org.jpedal.io.PdfObjectReader;
import org.jpedal.utils.LogWriter;


/**
 * handle ICCColorSpace
 */
public class ICCColorSpace
	extends GenericColorSpace {
	
	//cache values to speed up translation
	private int[] a1,b1,c1;
			
	public ICCColorSpace(PdfObjectReader currentPdfFile,String currentColorspace) {
		
		//set cache to -1 as flag
		a1=new int[256];
		b1=new int[256];
		c1=new int[256];
		
		for(int i=0;i<256;i++){
			a1[i]=-1;
			b1[i]=-1;
			c1[i]=-1;
		}
		
		value = ColorSpaces.ICC;
		cs = ColorSpace.getInstance(ColorSpace.CS_sRGB);
		
		//remove /ICCBased & ] to get object ref
		 int  pointer = currentColorspace.indexOf("/ICCBased");
		  String object_ref = currentColorspace.substring(pointer + 9);
		  pointer = object_ref.indexOf("]");
		  if (pointer != -1)
			  object_ref = object_ref.substring(0, pointer - 1);
		 
		  //read the ICC profile in the file
		  byte[] icc_data = currentPdfFile.readStream(object_ref.trim());
		
		  if (icc_data == null)
			  LogWriter.writeLog(
				  "Error in reading ICC data with ref " + object_ref);
		  else {
			  try{
				  cs = new ICC_ColorSpace(ICC_Profile.getInstance(icc_data));
			  }catch(Exception e){
				  LogWriter.writeLog("[PDF] Problem "+e.getMessage()+" with ICC data ");
			  }
		  }
	}


	/**set color*/
	final public void setColor(String[] operand,int size) {
		
		float[] values=new float[size];
		int[] lookup=new int[size];
		
		for(int i=0;i<size;i++){
			float val=Float.parseFloat(operand[i]);
			values[size-i-1]=val;
			lookup[size-i-1]=(int)(val*255);
		}
		
		if((size==3)&&(a1[lookup[0]]!=-1)&&
				(b1[lookup[1]]!=-1)&&(c1[lookup[2]]!=-1))
		{
			currentColor=new Color(a1[lookup[0]],b1[lookup[1]],c1[lookup[2]]);
			
		}else{
			values=cs.toRGB(values);
			
			currentColor=new Color(values[0],values[1],values[2]);
			
			if(size==3){
				a1[lookup[0]]=(int)(values[0]*255);
				b1[lookup[1]]=(int)(values[1]*255);
				c1[lookup[2]]=(int)(values[2]*255);
			}
		}
	}

	/**
	 * convert Index to RGB
	  */
	public byte[] convertIndexToRGB(byte[] data){

		return convert4Index(data);


	}		

	/**
	 * <p>
	 * Convert DCT encoded image bytestream to sRGB
	 * </p>
	 * <p>
	 * It uses the internal Java classes and the Adobe icm to convert CMYK and
	 * YCbCr-Alpha - the data is still DCT encoded.
	 * </p>
	 * <p>
	 * The Sun class JPEGDecodeParam.java is worth examining because it contains
	 * lots of interesting comments
	 * </p>
	 * <p>
	 * I tried just using the new IOImage.read() but on type 3 images, all my
	 * clipping code stopped working so I am still using 1.3
	 * </p>
	 */
	public BufferedImage JPEGToRGBImage(
			byte[] data,int w,int h) throws PdfException {

		return nonRGBJPEGToRGBImage(data,w,h);

	}		
}
