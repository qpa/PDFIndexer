/*
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * Project Lead:  Mark Stephens (mark@idrsolutions.com)
 *
 * (C) Copyright 2005, IDRsolutions and Contributors.
 * 
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 *
 * ---------------
 * PdfPageData.java
 * ---------------
 * (C) Copyright 2005, by IDRsolutions and Contributors.
 *
 * Original Author:  Mark Stephens (mark@idrsolutions.com)
 * Contributor(s):
 */
package org.jpedal.objects;

import java.util.StringTokenizer;

import org.jpedal.utils.LogWriter;
import org.jpedal.utils.Strip;
import org.jpedal.utils.repositories.Vector_Int;
import org.jpedal.utils.repositories.Vector_String;

/**
 * store data relating to page sizes set in PDF (MediaBox, CropBox, rotation)
 */
public class PdfPageData {

    private int raw_rotation = 0;

    /** any rotation on page (defined in degress) */
    private Vector_Int rotation = new Vector_Int(20);

    /** max media string for page */
    private Vector_String mediaString = new Vector_String(20);

    /** max crop string for page */
    private Vector_String cropString = new Vector_String(20);
 
    /** max x size on current object */
    private Vector_Int mediaBoxWidths = new Vector_Int(20);

    /** max y size on current object */
    private Vector_Int mediaBoxHeights = new Vector_Int(20);

    /** min x size on current object */
    private Vector_Int mediaBoxXs = new Vector_Int(20);

    /** min y size on current object */
    private Vector_Int mediaBoxYs = new Vector_Int(20);

    /** max x crop size on current object */
    private Vector_Int cropBoxWidths = new Vector_Int(20);

    /** max y crop size on current object */
    private Vector_Int cropBoxHeights = new Vector_Int(20);

    /** min x crop size on current object */
    private Vector_Int cropBoxXs = new Vector_Int(20);

    /** min y crop size on current object */
    private Vector_Int cropBoxYs = new Vector_Int(20);

    /** current x and y read from page info */
    private int cropBoxX = -99999, cropBoxY = -1,
            cropBoxW = -1, cropBoxH = -1;

    /** current x and y read from page info */
    private int mediaBoxX=-1, mediaBoxY, mediaBoxW, mediaBoxH;

    /** string representation of crop box */
    private String cropValue = "";

    /** string representation of media box */
    private String mediaValue = "";

    /**
     * make sure a value set for crop and media box (used internally to trap 'odd' settings and insure setup correctly)
     */
    public void checkSizeSet(int pageNumber) {

    	
        //allow for no settings
        if ((mediaBoxW == 0) | (mediaBoxH == 0)) {
            LogWriter.writeLog("NO page co-ords set - using 800 * 800");
            mediaBoxW = 800;
            mediaBoxH = 800;
            cropBoxW=800;
            cropBoxH=800;
        }
        
        //store values
        mediaBoxXs.setElementAt(mediaBoxX, pageNumber);
        mediaBoxYs.setElementAt(mediaBoxY, pageNumber);
        mediaBoxWidths.setElementAt(mediaBoxW, pageNumber);
        mediaBoxHeights.setElementAt(mediaBoxH, pageNumber);

        cropBoxXs.setElementAt(cropBoxX, pageNumber);
        cropBoxYs.setElementAt(cropBoxY, pageNumber);
        cropBoxWidths.setElementAt(cropBoxW, pageNumber);
        cropBoxHeights.setElementAt(cropBoxH, pageNumber);

        cropString.setElementAt(cropValue,pageNumber);
        mediaString.setElementAt(mediaValue,pageNumber);
        
    }
    
    /**
     * return height of mediaBox
     */
    final public int getMediaBoxHeight(int pageNumber) {

        return mediaBoxHeights.elementAt(pageNumber);
    }

    /** return rotation value (for outside class) */
    final public int getRotation(int pageNumber) {

        return rotation.elementAt(pageNumber);
    }

    /**
     * return mediaBox y value
     */
    final public int getMediaBoxY(int pageNumber) {

        return mediaBoxYs.elementAt(pageNumber);
    }

    /**
     * return mediaBox x value
     */
    final public int getMediaBoxX(int pageNumber) {
    	
        return mediaBoxXs.elementAt(pageNumber);
    }

    /**
     * set string with raw values and assign values to crop and media size
     */
    public void setMediaBox(String value) {
    	
        String media_box = Strip.removeArrayDeleminators(value);
        StringTokenizer media_values = new StringTokenizer(media_box, " ");

        mediaValue = media_box;
        
        //reset crop box
        cropValue=media_box;

        mediaBoxX = ((int) Float.parseFloat(media_values.nextToken()));
        mediaBoxY = ((int) Float.parseFloat(media_values.nextToken()));
        mediaBoxW = ((int) Float.parseFloat(media_values.nextToken()))-mediaBoxX;
        mediaBoxH = ((int) Float.parseFloat(media_values.nextToken()))-mediaBoxY;

        //set crop if unset
        //if (cropBoxW == -1) {
            cropBoxX = mediaBoxX;
            cropBoxY = mediaBoxY;
            cropBoxW = mediaBoxW;
            cropBoxH = mediaBoxH;
        //}
    }

    /**
     * set crop with values and align with media box
     */
    public void setCropBox(String value) {
    	
        String cropBox = Strip.removeArrayDeleminators(value);
        StringTokenizer media_values = new StringTokenizer(cropBox, " ");

        cropValue = cropBox;

        cropBoxX = ((int) Float.parseFloat(media_values.nextToken()));
        cropBoxY = ((int) Float.parseFloat(media_values.nextToken()));
        cropBoxW = ((int) Float.parseFloat(media_values.nextToken()))-cropBoxX;
        cropBoxH = ((int) Float.parseFloat(media_values.nextToken()))-cropBoxY;

        //adjust bounds
        /* current_max_x = current_crop_max_x;
        current_max_y = current_crop_max_y;
        current_min_x = current_crop_min_x;
        current_min_y = current_crop_min_y;
        */
    }

    public int setPageRotation(String value, int pageNumber) {

        raw_rotation = 0;

        try {
            raw_rotation = Integer.parseInt(value);

            //convert negative
            if (raw_rotation < 0)
                raw_rotation = 360 + raw_rotation;

            //save to lookup table
            rotation.setElementAt(raw_rotation, pageNumber);
        } catch (Exception e) {
            LogWriter.writeLog("Exception " + e + " reading rotation");
        }

        return raw_rotation;
    }

    /**
     * return width of media box
     */
    final public int getMediaBoxWidth(int pageNumber) {

        return mediaBoxWidths.elementAt(pageNumber);
    }

    /**
     * return mediaBox string found in PDF file
     */
    public String getMediaValue(int currentPage) {

        return mediaString.elementAt(currentPage);
    }

    /**
     * return cropBox string found in PDF file
     */
    public String getCropValue(int currentPage) {

        return cropString.elementAt(currentPage);
    }

    /**
     * return x value for cropBox
     */
    public int getCropBoxX(int pageNumber) {

    	return cropBoxXs.elementAt(pageNumber);
    }

    /**
     * return cropBox width
     */
    public int getCropBoxWidth(int pageNumber) {

    	return cropBoxWidths.elementAt(pageNumber);
    }

    /**
     * return y value for cropox
     */
    public int getCropBoxY(int pageNumber) {

    	return cropBoxYs.elementAt(pageNumber);
    }

    /**
     * return cropBox height
     */
    public int getCropBoxHeight(int pageNumber) {
        
    	return cropBoxHeights.elementAt(pageNumber);
    }
}