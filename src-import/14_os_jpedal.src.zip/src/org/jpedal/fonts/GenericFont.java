/*
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * Project Lead:  Mark Stephens (mark@idrsolutions.com)
 *
 * (C) Copyright 2004, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 *
 * ---------------
 * GenericFont.java
 * ---------------
 * (C) Copyright 2004, by IDRsolutions and Contributors.
 *
 * Original Author:  Mark Stephens (mark@idrsolutions.com)
 * Contributor(s):
 *
 * 20040223 Substantially rewritten.
 */
package org.jpedal.fonts;

import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.util.Map;

import org.jpedal.io.PdfObjectReader;
import org.jpedal.utils.LogWriter;

/**provides general unembedded font support for GPL or LGPL code
 * to renderer using non-embedded fonts*/
public class GenericFont extends PdfFont {
	
	public void readFontData(byte[] fontData){
		
		LogWriter.writeMethod("{readFontData}", 0);
		
	}
	
	
	/**get handles onto Reader so we can access the file*/
	public GenericFont(PdfObjectReader current_pdf_file,String substituteFont) {
		
		init(current_pdf_file);
		this.substituteFont=substituteFont;
		
	}
	
	/**read in a font and its details from the pdf file*/
	public Map createFont(Map values, String fontID,boolean renderPage,Map descFontValues) throws Exception{
		
		LogWriter.writeMethod("{readTrueTypeFont}"+values, 0);
		
		Map fontDescriptor = null;
		
		if((fontTypes==StandardFonts.TRUETYPE)|(fontTypes== StandardFonts.TYPE1)){
			
			fontDescriptor =super.createFont(values, fontID,renderPage,descFontValues);
			
			//get the data for an object
			if (fontDescriptor!= null){
				
				if(fontTypes==StandardFonts.TRUETYPE){
					String streamName=(String) fontDescriptor.get("FontFile2");
					
					if(streamName!=null){
						
						//see if installed - if so cannot reinstall
						// without memory leak
						boolean isFontInstalled = false;			
						Font[] PSfontList =GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
						
						int count = PSfontList.length;
						for (int i = 0; i < count; i++) {
							if (PSfontList[i].getPSName().equals(getFontName())) {
								isFontInstalled = true;
								i = count;		
							}
						}
						
						if(!isFontInstalled){
							//process the font data
							try {
								
								LogWriter.writeLog("Embedded TrueType font used");
								isFontEmbedded=true;
								byte[] bytes=currentPdfFile.readStream(streamName);
								java.io.ByteArrayInputStream in=new java.io.ByteArrayInputStream(bytes);
								java.awt.Font f=java.awt.Font.createFont(java.awt.Font.TRUETYPE_FONT,in);
								in.close();
								
								f=null;
								
							} catch (Exception e) {
								LogWriter.writeLog("Exception " + e + " processing TrueType font");				
							}
						}
					}
				}else{ //type 1
					String fontFileRef =(String) fontDescriptor.get("FontFile");
					
					if (fontFileRef != null) 
						isFontEmbedded=true;	
					else{
						fontFileRef = (String) fontDescriptor.get("FontFile3");
						if (fontFileRef != null) 
							isFontEmbedded=true;
					}
				}
			}
			
			readWidths(values);
			
		}else if((fontTypes==StandardFonts.CIDTYPE0)|(fontTypes==StandardFonts.CIDTYPE2)){
			
			this.fontID=fontID;
			this.isCIDFont=true;
			
			fontDescriptor=createCIDFont(values,descFontValues);
			
			if(!isFontEmbedded)
				selectDefaultFont();
			
		}
		
		//make sure a font set
		setFont(baseFontName,1);
		
		return fontDescriptor ;
	}
}
