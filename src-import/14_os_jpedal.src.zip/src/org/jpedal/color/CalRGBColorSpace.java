/*
* ===========================================
* Java Pdf Extraction Decoding Access Library
* ===========================================
*
* Project Info:  http://www.jpedal.org
* Project Lead:  Mark Stephens (mark@idrsolutions.com)
*
* (C) Copyright 2003, IDRsolutions and Contributors.
*
* 	This file is part of JPedal
*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*
* ---------------
* CalRGBColorSpace.java
* ---------------
* (C) Copyright 2003, by IDRsolutions and Contributors.
*
* Original Author:  Mark Stephens (mark@idrsolutions.com)
* Contributor(s):
*
*
*/
package org.jpedal.color;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.Raster;

import org.jpedal.utils.LogWriter;


/**
 * handle CalRGBColorSpace
 */
public class CalRGBColorSpace
	extends  GenericColorSpace{
		
	private int r,g,b;
	
	/**cache for values to stop recalculation*/
	private float lastC=-255,lastI=-255,lastE=-255;	
		
	public CalRGBColorSpace(String whitepoint,String blackpoint,String matrix,String gamma) {
			
		setCIEValues(whitepoint,blackpoint,null,matrix,gamma);
		value = ColorSpaces.CalRGB;
		
	}

	/**
	 * convert LAB stream to RGB and return as an image
	  */
	final public BufferedImage  dataToRGB(byte[] data,int width,int height) {

		BufferedImage image = null;
		DataBuffer db = new DataBufferByte(data, data.length);
		int size = width * height;

		try {

			for (int i = 0;
				i < size * 3;
				i = i + 3) { //convert all values to rgb

				float cl = db.getElemFloat(i);
				float ca = db.getElemFloat(i + 1);
				float cb = db.getElemFloat(i + 2);

				convertToRGB(cl, ca, cb);

				db.setElem(i, r);
				db.setElem(i + 1, g);
				db.setElem(i + 2, b);

			}

			int[] bands = { 0, 1, 2 };
			image =
				new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Raster raster =
				Raster.createInterleavedRaster(
					db,
					width,
					height,
					width * 3,
					3,
					bands,
					null);
			image.setData(raster);

		} catch (Exception ee) {
			image = null;
			LogWriter.writeLog("Couldn't read JPEG, not even raster: " + ee);
		}

		return image;

	}
	
	/**
	 * set CalRGB color (in terms of rgb)
	 */
	final public void setColor(String[] number_values,int items) {

		//get values (and allow for mapped from separatin where only 1 value
		float[] A = { 1.0f, 1.0f, 1.0f };
		
		//allow for use as alt colorspace which only has one value
		if (items == 3) {
			for (int i = 0; i < items; i++){
				A[i] =Float.parseFloat(number_values[2 - i]);
			//	System.out.println(A[i]);
			}
		}
		
		convertToRGB(A[0],A[1],A[2]);
		
		this.currentColor= new Color(r,g,b);
	}
	
	final private void convertToRGB(float C,float I, float E){
		
			if((lastC==C)&&(lastI==I)&&(lastE==E)){	
				
			}else{
			
			  //standard calc (see pdf spec 1.3 page 170)
				
			  //factor in gamma
			  float AG = (float) Math.pow(C, G[0]);
			  float BG = (float) Math.pow(I, G[1]);
			  float CG = (float) Math.pow(E, G[2]);
			  
			  float[] values=new float[3];
			  
			  //calcuate using Tristimulus values
			  values[0]=(calibrateValues(((Ma[0]* AG) + (Ma[3] * BG) + (Ma[6] * CG)),0));
			  values[1]=(calibrateValues(((Ma[1] * AG) + (Ma[4] * BG) + (Ma[7] * CG)),1));
			  values[2] =(calibrateValues(((Ma[2] * AG) + (Ma[5] * BG) + (Ma[8] * CG)),2));
			  
			  //convert to rgb
			  values = cs.toRGB(values);
			 
			  if((values[0]>0.95)&&(values[1]>0.95)&&(values[2]>0.95)){
			  	for(int aa=0;aa<3;aa++)
			  			values[aa]=1;
			  }
			  		
			  /**
			  //allow for rounding error
			  for(int aa=0;aa<3;aa++){
			      if(values[aa]>0.95)
			          values[aa]=1;
			      if(values[aa]<0.05)
			          values[aa]=0;
			  }*/
			  
			  //calcuate using Tristimulus values
			  r=(int)(values[0]*255);
			  g=(int)(values[1]*255);
			  b =(int)(values[2]*255);
				
			lastC=C;
			lastI=I;
			lastE=E;	
		}
	}

	/**
	 * convert Index to RGB
	  */
	final public byte[] convertIndexToRGB(byte[] index){
		/**
		//array
		int size=index.length;
		byte[] newData=new byte[size];
			
		for(int i=0;i<size-1;i=i+3){
			
			float C=(float)index[i]-128f;
			float I=(float)index[i+1]- 128f;
			float E=(float)index[i+2]-128f;
			
			convertToRGB(C,I,E);
			
			//System.out.println(C+" "+I+" "+E+" = "+r+" "+g+" "+b);

			newData[i]=(byte) r;
			newData[i+1]=(byte) g;
			newData[i+2]=(byte) b;
		  
	  	}
	 	*/
		
		return index;
	}	
}
