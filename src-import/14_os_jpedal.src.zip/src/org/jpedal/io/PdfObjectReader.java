/*
* ===========================================
* Java Pdf Extraction Decoding Access Library
* ===========================================
*
* Project Info:  http://www.jpedal.org
* Project Lead:  Mark Stephens (mark@idrsolutions.com)
*
* (C) Copyright 2003, IDRsolutions and Contributors.
*
* 	This file is part of JPedal
*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*
* ---------------
* PdfObjectReader.java
* ---------------
* (C) Copyright 2002, by IDRsolutions and Contributors.
*
* Original Author:  Mark Stephens (mark@idrsolutions.com)
* Contributor(s):
*
*/
package org.jpedal.io;

//standard java
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

//<start-13>
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
//<end-13>

import org.jpedal.exception.PdfException;
import org.jpedal.exception.PdfSecurityException;
import org.jpedal.fonts.StandardFonts;
import org.jpedal.objects.PageLookup;
import org.jpedal.objects.PdfFileInformation;
import org.jpedal.utils.LogWriter;
import org.jpedal.utils.Sorts;
import org.jpedal.utils.Strip;
import org.jpedal.utils.repositories.Vector_Int;

/**
 * extends PdfFileReader and PdfFilteredFileReader to
 * provide access at object level to data in pdf file
 */
public class PdfObjectReader extends PdfFilteredReader {
    
    /**used to cache last compressed object*/
    private byte[] lastCompressedStream=null;
    
    /**location of end ref*/
    private Vector_Int xref=new Vector_Int(100);
    
    /**used to cache last compressed object*/
    private Map lastOffsetStart,lastOffsetEnd;
    
    /**used to cache last compressed object*/
    private int lastFirst;
    
    /**current/last object read*/
    private Map objData=null;
    
    /**names lookup table*/
    private Map nameLookup=new Hashtable();
    
    /**allows cache of data so not reread if requested consecutive times*/
    private String lastRef="";

	/**Information object holds information from file*/
	PdfFileInformation currentFileInformation = new PdfFileInformation();

	/**flag to show if extraction allowed*/
	private boolean extractionIsAllowed = true;
	
	private final static byte[] endPattern = { 101, 110, 100, 111, 98, 106 }; //pattern endobj
	
	/**flag to show data encrytped*/
	private boolean isEncrypted = false;
	
	/**flag to show provider read*/
	private boolean isInitialised=false;
	
	/**encryption password*/
	private byte[] encryptionPassword = new byte[ 0 ];
	
	/**info object*/
	private String infoObject=null;
	
	/**key used for encryption*/
	private byte[] encryptionKey=null;
		
	/**flag to show if user can view file*/
	private boolean isFileViewable=true;
	
	/** revision used for encryption*/
	private int rev=0;
	
	/**length of encryption key used*/
	private int keyLength=5;
	
	/**P value in encryption*/
	private int P=0;
	
	/**O value in encryption*/
	private byte[] O=new byte[0];
	
	/**U value in encryption*/
	private byte[] U=new byte[0];
	
	/**holds file ID*/
	private String ID="";
	
	/**flag if password supplied*/
	private boolean isPasswordSupplied=false;
	
	//<start-13>
	/**cipher used for decryption*/
	private Cipher cipher=null;
	//<end-13>
	
	/**encryption padding*/
	private String[] padding={"28","BF","4E","5E","4E","75","8A","41","64","00","4E","56","FF","FA","01","08",
											 "2E","2E","00","B6","D0","68","3E","80","2F","0C","A9","FE","64","53","69","7A"};

	/**length of each object*/
    private int[] ObjLengthTable;

	private boolean refTableInvalid=false;

	public PdfObjectReader() {

	}
	/**
	 * read first start ref from last 1024 bytes
	 */
	final public int readFirstStartRef() throws PdfException {

		//reset flag
		refTableInvalid=false;
		int pointer = -1;
		int i = 0;
		StringBuffer startRef = new StringBuffer();
	
		/**move to end of file and read last 1024 bytes*/
		byte[] lastBytes = new byte[1024];
		try {
			
			//allow for very small file
			int count=(int)(pdf_datafile.length() - 1024);
			if(count<0){
				count=0;
				lastBytes=new byte[(int)pdf_datafile.length() ];
			}
			
			movePointer(count);
			
			pdf_datafile.read(lastBytes);
		} catch (Exception e) {
			LogWriter.writeLog("Exception " + e + " reading last 1024 bytes");
			throw new PdfException( e + " reading last 1024 bytes");
		}
		
		//look for tref as end of startxref
		int fileSize=lastBytes.length;
		while ((i < 1024)) {
			if ((lastBytes[i] == 116)
				&& (lastBytes[i + 1] == 120)
				&& (lastBytes[i + 2] == 114)
				&& (lastBytes[i + 3] == 101)
				&& (lastBytes[i + 4] == 102))
				break;

				
			i++;
			
			/**trap buggy files*/
			if(fileSize==i){
			    try {
                    this.pdf_datafile.close();
                } catch (IOException e1) {
                   LogWriter.writeLog("Exception "+e1+" closing file");
                }
			    throw new PdfException( "No Startref found in last 1024 bytes!!");
			}
		}
		
		i = i + 5; //allow for word length
		
		//move to start of value ignoring spaces or returns
		while ((i < 1024)
			&& ((lastBytes[i] == 10)
				| (lastBytes[i] == 32)
				| (lastBytes[i] == 13)))
			i++;

		//move to start of value ignoring spaces or returns
		while ((i < 1024)
			&& (lastBytes[i] != 10)
			&& (lastBytes[i] != 32)
			&& (lastBytes[i] != 13)) {
			startRef.append((char) lastBytes[i]);
			i++;
		}
		
		/**convert xref to string to get pointer*/
		if (startRef.length() > 0)
			pointer = Integer.parseInt(startRef.toString());

		if (pointer == -1){
			LogWriter.writeLog("No Startref found in last 1024 bytes!!");
			try {
                this.pdf_datafile.close();
            } catch (IOException e1) {
               LogWriter.writeLog("Exception "+e1+" closing file");
            }
			throw new PdfException( "No Startref found in last 1024 bytes!!");
		}

		return pointer;
	}
	/**set a password for encryption*/
	public void setEncryptionPassword(String password){
        this.encryptionPassword = password.getBytes();
	}
	
	/**
	 * convert direct values into Map
	 */
	public static Map directValuesToMap(String value) {
		Map colorValues;
		colorValues=new Hashtable();
		
		int start=value.indexOf("<<");
		int end=value.indexOf(">>");
		
		String values=value.substring(start+2,end).trim();
		
		StringTokenizer vals=new StringTokenizer(values,"/");
		while(vals.hasMoreTokens()){
			String nextValue=vals.nextToken();
			
			int pointer=nextValue.indexOf(" ");
			String key="/"+nextValue.substring(0,pointer);
			String operand=nextValue.substring(pointer+1);
			colorValues.put(key,operand);
		}
		return colorValues;
	}
	
	/**
	 * read object data
	  */
	private byte[] readObjectData(int length){

		//read an extra 8 bytes to check end
		int end=length+1;
		
	    int origLength=length;
	    /**adjust buffer if less than bytes left in file*/
	    long pointer = this.getPointer();
		if (pointer + length > eof)
		    length = (int) (eof - pointer);

		//if(length<0){
		//    System.out.println(origLength+" "+length+" "+pointer+" "+length+" "+eof);
		//}
		int bufSize =256,charReached = 0;
		byte[] array=null;		
		
		/**read the object*/
		try {
			
			array= new byte[length+6];
			
			/**get bytes into buffer*/
			pdf_datafile.read(array);
			
			//align to endobj
			int len=array.length;
			for (int i = len-6; i >5;i--){
				
				//find end
				if ((array[i] == 101)&& (array[i + 1] == 110)&&
						(array[i + 2] == 100)&& (array[i + 3] == 111)&&
						(array[i + 4] == 98)&& (array[i + 5] == 106)){
					end=i+5;
					i=0;
				}
			}
			
			//if(end==0){
				//for(int jj=0;jj<array.length;jj++){
					//System.out.print((char)array[jj]);
				//}
		
	//}
			//size correctly
			byte[] newArray=new byte[end];
			System.arraycopy(array,0,newArray,0,end);
			array=newArray;
			
		} catch (Exception e) {
			LogWriter.writeLog("Exception " + e + " reading object");
		}
		/**
		for(int jj=0;jj<array.length;jj++)
	System.out.print((char)array[jj]);
		
		System.out.print("<==");
		*/
		return array;
	}
	/**
	 * read a dictionary object
	*/
	private int readDictionary(String objectRef,int level,Map rootObject,int i,byte[] raw,boolean isEncryptionObject,Map textFields){
		
		boolean preserveTextString=false;
		boolean debug=false;
		//debug=objectRef.equals("37004 0 R");
		StringBuffer operand=new StringBuffer(255);
		StringBuffer key=new StringBuffer(20);
		
		while(true){
			
			i++;
			
			if(i>=raw.length)
				break;
		
			//break at end	
			if ((raw[i] == 62) && (raw[i + 1] == 62))
				break;
			
			if ((raw[i] == 101)&& (raw[i + 1] == 110)&& (raw[i + 2] == 100)&& (raw[i + 3] == 111))
				break;	
			
			//handle recursion
			if ((raw[i] == 60) && ((raw[i + 1] == 60))){
				level++;
				i++;
				
				if(debug)
				System.err.println(level+" << found key="+key+"= nextchar="+raw[i + 1]);
					
				Map dataValues=new Hashtable();
				rootObject.put(key.toString(),dataValues);
				i=readDictionary(objectRef,level,dataValues,i,raw,isEncryptionObject,textFields);
				//i++;
				key=new StringBuffer(20);
				level--;
				//allow for >>>> with no spaces	
				if ((raw[i] == 62) && (raw[i + 1] == 62))
				i++;
				
			}else  if ((raw[i] == 47)&(key.length()==0)) { //everything from /	
				
				key=new StringBuffer(20);
				i++;
	
				while (true) { //get key up to space or [ or / or ( or < or carriage return
					if ((raw[i] == 32)| (raw[i] == 13)  | (raw[i] == 10) |(raw[i] == 91)|(raw[i]==47)|(raw[i]==40)|(raw[i]==60))
						break;
					key.append((char) raw[i]);
					i++;
				}	
				
				if(debug)
				System.err.println(level+" key="+key);
				
				//set flag to extract raw text string
				
				
				if((textFields!=null)&&(key.length()>0)&&(textFields.containsKey(key.toString()))){
					preserveTextString=true;
				}else
					preserveTextString=false;
				
				if((raw[i]==47)|(raw[i]==40)|(raw[i]==60)| (raw[i] == 91)) //move back cursor
				i--;
				
			}else if((raw[i]==32)|(raw[i]==13)|(raw[i]==10)){
			}else if((raw[i]==60)&&(preserveTextString)){ //text string <00ff>	
				
				i++;
				ByteArrayOutputStream bis=new ByteArrayOutputStream();
				while(true){
				
					StringBuffer newValue=new StringBuffer(2);
					for(int j=0;j<2;j++){
						newValue.append((char)raw[i]);
						i++;
					}
					
					bis.write(Integer.parseInt(newValue.toString(),16));
					
					//ignore returns
					while((raw[i]==13)|(raw[i]==10))
						i++;
					
					if((raw[i]==62))
						break;
					
				}
				
				try{
					bis.close();
					
					byte[] streamData=(byte[]) bis.toByteArray();		
        			    streamData=decrypt(streamData,(String) objectRef,null,false);
 
					rootObject.put(key.toString(),streamData); //save pair and reset
				}catch(Exception e){
					LogWriter.writeLog("[PDF] Problem "+e+" writing text string"+key);
					e.printStackTrace();
				}
				
				key = new StringBuffer(20);
				
				//ignore spaces and returns
			}else if(raw[i]==40){ //read in (value) excluding any returns
				
				if(preserveTextString){
					ByteArrayOutputStream bis=new ByteArrayOutputStream();
					try{
						if(raw[i+1]!=41){ //trap empty field
							while(true){
								
								i++;
								boolean isOctal=false;
					
								//trap escape
								if((raw[i]==92)){
									i++;
									
									if(raw[i]=='b')
									    raw[i]='\b';
									else if(raw[i]=='n')
									    raw[i]='\n';
									else if(raw[i]=='t')
									    raw[i]='\t';
									else if(raw[i]=='r')
									    raw[i]='\r';
									else if(raw[i]=='f')
									    raw[i]='\f';
									else if(Character.isDigit((char) raw[i])){ //octal
									    StringBuffer octal=new StringBuffer(3);
									    for(int ii=0;ii<3;ii++){
									        octal.append((char)raw[i]);
									        i++;
									    }
									    //move back 1
									    i--;
									    isOctal=true;
									    raw[i]=(byte) Integer.parseInt(octal.toString(),8);
									}
								}
								
								//exit at end
								if((!isOctal)&&(raw[i]==41)&&((raw[i-1]!=92)|((raw[i-1]==92)&&(raw[i-2]==92))))
									break;
								
								bis.write(raw[i]);
								
							}
						}
					
						bis.close();
						
						byte[] streamData=(byte[]) bis.toByteArray();
						
	        			    streamData=decrypt(streamData,objectRef,null,false);
	        			    rootObject.put(key.toString(),streamData); //save pair and reset
					
					}catch(Exception e){
						LogWriter.writeLog("[PDF] Problem "+e+" handling text string"+key);
					}
				}else if((isEncryptionObject)&&(key.length()==1)&&((key.charAt(0)=='U')|(key.charAt(0)=='O'))){
					int count=32;
					
					ByteArrayOutputStream bis=new ByteArrayOutputStream();
					while(true){
						
						i++;
						
						if((raw[i]==92)){
							
							i++;
							
							//map chars correctly
							if(raw[i]==114)
								raw[i]=13;
							else if(raw[i]==110)
								raw[i]=10;
							else if(raw[i]==116)
								raw[i]=9;
							else if(raw[i]==102) // \f
								raw[i]=12;
							else if(raw[i]==98) // \b
								raw[i]=8;
							
							
						}
						
						bis.write(raw[i]);
						
						count--;
						
						if(count==0)
							break;
						
					}
					try{
						bis.close();
						rootObject.put(key.toString(),bis.toByteArray()); //save pair and reset
					}catch(Exception e){
						LogWriter.writeLog("[PDF] Problem "+e+" writing "+key);
					}
					
				}else{
					boolean inComment=false;
					while(true){
						
						if(!inComment){
							if((raw[i]==13)|(raw[i]==10))
								operand.append(' ');
							else
								operand.append((char)raw[i]);
						}
						
						//avoid \\) where \\ causes problems
						if((raw[i-1]==92)&(raw[i-2]==92))
							raw[i-1]=0;
						
						if((raw[i-1]!=92)&(raw[i]==41))
							break;
						
						i++;
						
						if((raw[i]==37)&&(raw[i-1]!=92)) //ignore comments %
							inComment=true;
						
					}
					
					//save pair and reset
					String finalOp=operand.toString();
					if(!finalOp.equals("null"))
						rootObject.put(key.toString(),finalOp);
					
					if(debug)
						System.err.println(level+" *0 "+key+"=="+operand+"<");
					operand = new StringBuffer(255);
				}
				key = new StringBuffer(20);
				
			}else if(raw[i]==91){ //read in [value] excluding any returns
					
					//ignore any spaces
					while(raw[i]==32){
						operand.append((char)raw[i]);
						i++;
					}
					
					boolean inComment=false,convertToHex=false;
					int squareCount=0,count=0;
					char next=' ',last=' ';
					
					while(true){
						
						//ignore any escapes
						if(raw[i]==92)
							i++;
						
						//track [/Indexed /xx ()] with binary values in ()
						if((raw[i]==40)&(raw[i-1]!=92)&&(operand.toString().indexOf("/Indexed")!=-1)){
							convertToHex=true;
							operand.append(" <");
							
						}else if(convertToHex){
							if((raw[i]==41)&(raw[i-1]!=92)){
								operand.append(">");
								convertToHex=false;
								
							}else{
								String hex_value = Integer.toHexString((raw[i]) & 255);
								//pad with 0 if required
								if (hex_value.length() < 2)
									operand.append("0");
								operand.append(hex_value);
								
							}
							
						}else if(!inComment){
							
							if((raw[i]==13)|(raw[i]==10)){
								operand.append(' ');
							}else{
								
								next=(char)raw[i];
								
								//put space in [/ASCII85Decode/FlateDecode]
								if((next=='/')&&(last!=' '))
									operand.append(' ');
								
								//put space in [()99 0 R]
								if((next!=' ')&&(last==')'))
									operand.append(' ');
								
								operand.append(next);
								
								last=next;
							}
						}
				
						//if((raw[i-1]==92)&&(raw[i]==92)){ //trap \\
						//	i++;
						//}else 
						if((raw[i-1]!=92)|((raw[i-1]==92)&&(raw[i-2]==92))){ //allow for escape and track [] and ()
							if(raw[i]==40)
								count++;
							else if(raw[i]==41)
								count--;
							if(count==0){
								if(raw[i]==91)
									squareCount++;
								else if(raw[i]==93)
									squareCount--;
							}
						}
						
						if((squareCount==0)&&(raw[i-1]!=92)&(raw[i]==93))
						break;
		
						i++;

						if((raw[i]==37)&&(raw[i-1]!=92)&&(squareCount==0)) //ignore comments %
						inComment=true;
						
					}
					
					
					//save pair and reset
					String finalOp=operand.toString();
					if(!finalOp.equals("null"))
						rootObject.put(key.toString(),finalOp);
					
					if(debug)
					System.err.println(level+" *1 "+key+"=="+operand.toString().trim()+"<");
						
					key = new StringBuffer(20);
					operand = new StringBuffer(255);
						
				}else if ((raw[i] != 62)&&(raw[i] != 60)&&(key.length()>0)){
					
						boolean inComment=false;
						while(true){
							
							if((raw[i]!=13)&(raw[i]!=10)&(!inComment))
							operand.append((char)raw[i]);
							
							if((raw[i+1]==47))
							break;
							
							if((raw[i]!=62)&&(raw[i+1]==62))
							break;
			
							i++;

							if((raw[i]==37)&&(raw[i-1]!=92)) //ignore comments %
							inComment=true;
						}
						
						//save pair and reset
						String finalOp=operand.toString().trim();
						if(!finalOp.equals("null"))	
							rootObject.put(key.toString(),finalOp);
						
						if(debug)
						System.err.println(level+"*2 "+key+"=="+operand.toString().trim()+"<");
						key = new StringBuffer(20);
						operand = new StringBuffer(255);
					
				}
			}
		
		if(debug)
		    System.err.println("=====Dictionary read");
			
		return i;
	
	}
	
	/**read a stream*/
	final public byte[] readStream(Map objData,String objectRef,boolean cacheValue)  {
		
		Object data=objData.get("DecodedStream");
		
		byte[] stream;
		
		//decompress first time
		if(data==null){
			
			stream=(byte[]) objData.get("Stream");
			
			if(cacheValue)
			objData.remove("Stream");
			/**decode and save stream*/
			if(stream!=null){

				//decrypt the stream
				try{
					stream=decrypt(stream,objectRef,null,false);
				}catch(Exception e){
					stream=null;
					LogWriter.writeLog("Exception "+e);
				}
			}

			if(stream!=null){
				
				//values for CCITTDecode
				int height=1,width=1,length=1;
				String value=(String) objData.get("Height");
				if(value!=null)
				height = Integer.parseInt(value);
	
				value=(String) objData.get("Width");
				if(value!=null)
				width = Integer.parseInt(value);
	
				value= getValue((String)objData.get("Length"));
				if(value!=null)
				length= Integer.parseInt(value);
	
				/**allow for no width or length*/
				if(height*width==1)
				width=length;

				String filter = this.getValue((String) objData.get("Filter"));
				
				boolean isImageMask=false;
				Object maskFlag=objData.get("ImageMask");
				if((maskFlag!=null)&&(maskFlag.equals("true"))){
					isImageMask=true;
				}
				
				if ((filter != null)&&
				(!filter.startsWith("/JPXDecode"))&&
				(!filter.startsWith("/DCT"))){
					
					try{
						stream =decodeFilters(stream, filter, objData,width,height,true);
					}catch(Exception e){
					
						LogWriter.writeLog("[PDF] Problem "+e+" decompressing stream ");
						stream=null;
					
					}
				}else if((length!=1)&&(length<stream.length)){
					
					/**make sure length correct*/
					if(stream.length!=length){
						byte[] newStream=new byte[length];
						for(int i=0;i<length;i++)
							newStream[i]=stream[i];
						
						stream=newStream;
					}
					
				}
			}
			
			if((stream!=null)&&(cacheValue))
			objData.put("DecodedStream",stream);
			
		}else
			stream=(byte[]) data;
			
		return  stream;
	}
	
	/**read a stream*/
	final public byte[] readStream(String ref)  {
		
		Map currentValues=readObject(ref,false, null);
		
		return readStream(currentValues,ref,true);
	}
	
	/**
	 * read object data
	  */
	private byte[] readObjectData(){

		int bufSize =256,charReached = 0;
		byte[] array=null;		
		
		long pointer = this.getPointer();
		long lastEndStream=-1,objStart=-1;
		/**read in the bytes, using the startRef as our terminator*/
		ByteArrayOutputStream bis = new ByteArrayOutputStream();
		
		/**read the object*/
		try {
			
			while (true) {

				/**adjust buffer if less than bytes left in file*/
				if (pointer + bufSize > eof)
					bufSize = (int) (eof - pointer);

				byte[] buffer = new byte[bufSize];

				/**get bytes into buffer*/
				this.movePointer(pointer);
				this.pdf_datafile.read(buffer);

				/**write out and look for endobj at end*/
				for (int i = 0; i < bufSize; i++) {

					byte currentByte = buffer[i];
					
					/**check for endobj at end - reset if not*/
					if (currentByte == endPattern[charReached])
						charReached++;
					else
						charReached = 0;

					bis.write(currentByte);

					if (charReached == 6) //located endobj
						i = bufSize;

				}

				pointer = pointer + bufSize; //update pointer

				if (charReached == 6)
					break;

			}
	
			bis.close();
			
			array=bis.toByteArray();
			
			int ObjStartCount=0;
			
			//check if mising endobj
			for (int i = 0; i < array.length-8; i++) {

				//track endstream and first or second obj
				if ((ObjStartCount<2)&&(array[i] == 32)&&(array[i+1] == 111)&&
						(array[i + 2] == 98)&& (array[i + 3] == 106)){
					ObjStartCount++;
					objStart=i;
				}
				if ((ObjStartCount<2)&&(array[i] == 101)&& (array[i + 1] == 110)&&
						(array[i + 2] == 100)&& (array[i + 3] == 115)&&
						(array[i + 4] == 116)&& (array[i + 5] == 114)&&
						(array[i + 6] == 101)&& (array[i + 7] == 97)&& (array[i + 8] == 109))
					lastEndStream=i+9;	
			}
			
			if((lastEndStream>0)&&(objStart>lastEndStream)){
				byte[] newArray=new byte[(int)lastEndStream];
				System.arraycopy(array,0,newArray,0,(int)lastEndStream);
				array=newArray;
			}
			
		} catch (Exception e) {
			LogWriter.writeLog("Exception " + e + " reading object");
		}
		
		return array;
	}
	/**
	 * read an object in the pdf into a Map which can be an indirect or an object,
	 * used for compressed objects
	 * 
	 */
	final public Map readObject(int objectRef,boolean isEncryptionObject, Map textFields)  {
	    
	    boolean debug=false,preserveTextString=false;
		objData=new Hashtable();

		//any stream
		byte[] stream=null;
	
		/**read raw object data*/
		try{
			movePointer(objectRef);
		}catch(Exception e){
			LogWriter.writeLog("Exception moving pointer to "+objectRef);
		}
		byte[] raw = readObjectData();
		
		/**read the object name from the start*/
		StringBuffer pattern=new StringBuffer("obj");
		StringBuffer objectName=new StringBuffer();
		char current,last=' ';
		int matched=0,i=0;
		while(i<raw.length){
		    current=(char)raw[i];
		    
		    //treat returns same as spaces
		    if((current==10)|(current==13))
		            current=' ';
		    
		    if((current==' ')&&(last==' ')){//lose duplicate or spaces
		        matched=0;
		    }else if(current==pattern.charAt(matched)){ //looking for obj at end
		        matched++;
		    }else{
		        matched=0;
		        objectName.append(current);
		    }
		    if(matched==3)
		        break;
		    last=current;
		    i++;
		}
		//add end and put into Map
		objectName.append('R');
		objData.put("Reference",objectName.toString());
		//objData.put("obj",objectName.toString());
		
		convertObjectBytesToMap(objData,objectName.toString(),isEncryptionObject, textFields, debug, preserveTextString, stream, raw,false);
		
		lastRef="-1";
		
		return objData;
	}
	
	/**
	 * read an object in the pdf into a Map which can be an indirect or an object
	 * 
	 */
	final synchronized public Map readObject(String objectRef,boolean isEncryptionObject, Map textFields)  {
		
		//System.out.println("Reading="+objectRef);
	    
	    /**return if last read otherwise read*/
	    if(objectRef.equals(lastRef)){
	        return objData;
	    }else{
	        lastRef=objectRef;
	        
			boolean debug=false,preserveTextString=false;
			objData=new Hashtable();
			
			//objData.put("obj",objectRef);
			
			//set flag to extract raw text string
			if((textFields!=null)){
				preserveTextString=true;
			}else
				preserveTextString=false;
			
			if(debug)
			System.err.println("reading objectRef="+objectRef+"<");
			
			/**allow for indirect*/
			if(objectRef.endsWith("]"))
			objectRef=Strip.removeArrayDeleminators(objectRef);
			
			boolean isCompressed=isCompressed(objectRef);
			
			if(objectRef.endsWith(" R")){
	
				//any stream
				byte[] stream=null,raw=null;
			
				/**read raw object data*/
				if(isCompressed){
				   
				    int objectID=Integer.parseInt(objectRef.substring(0,objectRef.indexOf(" ")));
				    int compressedID=getCompressedStreamObject(objectRef);
				    String compressedRef=compressedID+" 0 R",startID=null;
				    int compressedIndex=getOffsetInCompressedStream(objectRef);
				    Map compressedObject,offsetStart=lastOffsetStart,offsetEnd=lastOffsetEnd;
				    int First=lastFirst;
				    byte[] compressedStream;
				    boolean isCached=true; //assume cached
				    
				    //see if we already have values
				    compressedStream=lastCompressedStream;
				    if(lastOffsetStart!=null)
				            startID=(String) lastOffsetStart.get(""+objectID);
					
				    //read 1 or more streams
				    while(startID==null){
				        isCached=false;
				        try{
							movePointer(compressedRef);
						}catch(Exception e){
							LogWriter.writeLog("Exception moving pointer to "+objectRef);
						}
						
						raw = readObjectData(this.ObjLengthTable[compressedID]);
						compressedObject=new Hashtable();
						convertObjectBytesToMap(compressedObject,objectRef,isEncryptionObject, textFields, debug, preserveTextString, stream, raw,false);
						
						/**get offsets table see if in this stream*/
						offsetStart=new HashMap();
						offsetEnd=new HashMap();
						First=Integer.parseInt((String) compressedObject.get("First"));
						compressedStream=this.readStream(compressedObject,objectRef,true);
						
						extractCompressedObjectOffset(offsetStart, offsetEnd,First, compressedStream);
						
						startID=(String) offsetStart.get(""+objectID);
						
						compressedRef=(String) compressedObject.get("Extends");
					
				    }
				    
				    if(!isCached){
				        lastCompressedStream=compressedStream;
				        lastOffsetStart=offsetStart;
				        lastOffsetEnd=offsetEnd;
				        lastFirst=First;
				    }
				    
				    /**put bytes in stream*/
				    int start=First+Integer.parseInt(startID),end=compressedStream.length;
				    
				    String endID=(String) offsetEnd.get(""+objectID);
				    if(endID!=null){
				        end=First+Integer.parseInt(endID);
				    }
				    
				    //System.out.println(First+" "+startID+" "+start+" "+endID+" "+end);
				    
				    int streamLength=end-start;
        				raw = new byte[streamLength];
        				System.arraycopy(compressedStream, start, raw, 0, streamLength);
				
				}else{
					try{
						movePointer(objectRef);
					}catch(Exception e){
						LogWriter.writeLog("Exception moving pointer to "+objectRef);
					}
					int pointer=objectRef.indexOf(" ");
					//System.out.println(objectRef);
					int id=Integer.parseInt(objectRef.substring(0,pointer));
				//	System.out.println(id+" "+ObjLengthTable[id]+" "+pointer);
					if((isEncryptionObject)|(refTableInvalid))
						raw=readObjectData();
					else
						raw = readObjectData(ObjLengthTable[id]);
				}
				
				if(debug)
				System.out.println("convertObjectsToMap");
					
				if(raw.length>1)
				convertObjectBytesToMap(objData,objectRef,isEncryptionObject, textFields, debug, preserveTextString, stream, raw,isCompressed);
				
				if(debug)
					System.out.println("converted");
					
			}else{
				
				try {
				//put direct value into array and read
				ByteArrayOutputStream bos=new ByteArrayOutputStream();
				
				for (int ii=0;ii<objectRef.length();ii++)
					bos.write((byte) objectRef.charAt(ii));
				
				if(debug)
				System.out.println("reading dictionary");
					
					
						bos.close();
					
				byte[] bytes=bos.toByteArray();
				
				if(bytes.length>0)
				readDictionary(objectRef,1,objData,0,bytes,isEncryptionObject,textFields);
				
				//System.out.println("Direct object read "+objectRef+"<<");
				LogWriter.writeLog("Direct object read "+objectRef+"<<");
				
				} catch (IOException e) {
					e.printStackTrace();
			}
			
				
			}
			
			if(debug)
				System.out.println("object read");
				
			
		return objData;
	    }
	}
	
	/**
	 * read an object in the pdf into a Map which can be an indirect or an object
	 * 
	 */
	final synchronized public byte[] readObjectAsByteArray(String objectRef,boolean isEncryptionObject)  {
		
		byte[] raw=null;
		
		/**allow for indirect*/
		if(objectRef.endsWith("]"))
		objectRef=Strip.removeArrayDeleminators(objectRef);
		
		boolean isCompressed=isCompressed(objectRef);
		
		if(objectRef.endsWith(" R")){

			//any stream
			byte[] stream=null;
		
			/**read raw object data*/
			if(isCompressed){
			   
			    int objectID=Integer.parseInt(objectRef.substring(0,objectRef.indexOf(" ")));
			    int compressedID=getCompressedStreamObject(objectRef);
			    String compressedRef=compressedID+" 0 R",startID=null;
			    int compressedIndex=getOffsetInCompressedStream(objectRef);
			    Map compressedObject,offsetStart=lastOffsetStart,offsetEnd=lastOffsetEnd;
			    int First=lastFirst;
			    byte[] compressedStream;
			    boolean isCached=true; //assume cached
			    
			    //see if we already have values
			    compressedStream=lastCompressedStream;
			    if(lastOffsetStart!=null)
			            startID=(String) lastOffsetStart.get(""+objectID);
				
			    //read 1 or more streams
			    while(startID==null){
			        isCached=false;
			        try{
						movePointer(compressedRef);
					}catch(Exception e){
						LogWriter.writeLog("Exception moving pointer to "+objectRef);
					}
					
					raw = readObjectData(this.ObjLengthTable[compressedID]);
					compressedObject=new Hashtable();
					convertObjectBytesToMap(compressedObject,objectRef,isEncryptionObject, null, false, false, stream, raw,false);
					
					/**get offsets table see if in this stream*/
					offsetStart=new HashMap();
					offsetEnd=new HashMap();
					First=Integer.parseInt((String) compressedObject.get("First"));
					compressedStream=this.readStream(compressedObject,objectRef,true);
					
					extractCompressedObjectOffset(offsetStart, offsetEnd,First, compressedStream);
					
					startID=(String) offsetStart.get(""+objectID);
					
					compressedRef=(String) compressedObject.get("Extends");
				
			    }
			    
			    if(!isCached){
			        lastCompressedStream=compressedStream;
			        lastOffsetStart=offsetStart;
			        lastOffsetEnd=offsetEnd;
			        lastFirst=First;
			    }
			    
			    /**put bytes in stream*/
			    int start=First+Integer.parseInt(startID),end=compressedStream.length;
			    String endID=(String) offsetEnd.get(""+objectID);
			    if(endID!=null)
			        end=First+Integer.parseInt(endID);
			   
			    int streamLength=end-start;
    				raw = new byte[streamLength];
    				System.arraycopy(compressedStream, start, raw, 0, streamLength);
			
			}else{
				try{
					movePointer(objectRef);
				}catch(Exception e){
					LogWriter.writeLog("Exception moving pointer to "+objectRef);
				}
				int pointer=objectRef.indexOf(" ");
				int id=Integer.parseInt(objectRef.substring(0,pointer));
				if((isEncryptionObject)|(refTableInvalid))
					raw=readObjectData();
				else
					raw = readObjectData(ObjLengthTable[id]);
			}
			
		}else{
			
			//put direct value into array and read
			ByteArrayOutputStream bos=new ByteArrayOutputStream();
			for (int ii=0;ii<objectRef.length();ii++)
				bos.write((byte) objectRef.charAt(ii));	
			
			try {
				bos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			raw=bos.toByteArray();
			
		}
			
		return raw;
	    
	}
	
	/**
     * @param offsets
     * @param First
     * @param compressedStream
     */
    private void extractCompressedObjectOffset(Map offsetStart, Map offsetEnd,int First, byte[] compressedStream) {
        
        String lastKey=null;
        
        //read the offsets table
        for(int ii=0;ii<First;ii++){
            
            StringBuffer key=new StringBuffer();
            StringBuffer offset=new StringBuffer();
            while(compressedStream[ii]!=32){
                key.append((char)compressedStream[ii]);
                ii++;
        	}
            
            while(compressedStream[ii]==32)
                ii++;
            
            while((compressedStream[ii]!=32)&&(ii<First)){
                offset.append((char)compressedStream[ii]);
                ii++;
            }
            
            offsetStart.put(key.toString(),offset.toString());
            //save end as well
            if(lastKey!=null)
                offsetEnd.put(lastKey,offset.toString());
            
            lastKey=key.toString();
            
        }
    }
    /**
     * converts the bytes from the File into a map object containing the data
     * 
     * / =47
     (=40
     )=41
     \=92
     [=91
     ]=93
    
     */
    
    private void convertObjectBytesToMap(Map objData,String objectRef,boolean isEncryptionObject, Map textFields, 
            boolean debug, boolean preserveTextString,  
            byte[] stream, byte[] raw,boolean isCompressed) {
        
        /**get values*/
        int i = 0;
        
        ByteArrayOutputStream rawStringAsBytes=new ByteArrayOutputStream();	
    	
    	char remainderLastChar=' ';
    	
    	StringBuffer remainder=new StringBuffer();
    	
        if(!isCompressed){
	        //remove the obj start
	        while (true) {
	        	
	        	if ((raw[i] == 111)&& (raw[i + 1] == 98)&& (raw[i + 2] == 106))
	        			break;
	        	i++;
	        }
	        
	        i = i + 2;
	        	
	        //make sure no comment afterwards by rolling onto next CR or < or [ or /
	        while(true){
	            
	           if(raw[i]==47) //allow for command right after obj
	           break;
	            
		        	i++;
		        	//System.out.println(i+" "+(char)raw[i]+" "+raw[i]);
		        	if((raw[i]==10)|(raw[i]==13)|(raw[i]==60)|(raw[i]==91)|(raw[i]==32))
		        	break;
	        }
        }
        
        if(debug){
        	for(int j=i;j<raw.length - 7;j++)
        		System.err.print((char)raw[j]);
        	System.err.print("<==\n\n");
        }
        //avoid root dictionary object
        //if ((raw[i] == 60) && (raw[i + 1] == 60))
        //i++;
        
        //allow for immediate command
        if(raw[i]==47) //allow for command right after obj
            i--;
        
        //look for trailer keyword
        while (i < raw.length - 7) {
        	
        	i++;
        	
        	if(debug)
        	    System.err.println((char)raw[i]);
        	
        	//read a subdictionary
        	if ((raw[i] == 60) && ((raw[i + 1] == 60)| (raw[i - 1] == 60))){
        		
        		if(raw[i - 1] != 60)
        		i++;
        		
        		if(debug)
        		System.err.println("Read dictionary");
        		i=readDictionary(objectRef,1,objData,i,raw,isEncryptionObject,textFields);
        		
        	/**handle a stream*/
        	}else if ((raw[i] == 115)&& (raw[i + 1] == 116)&& (raw[i + 2] == 114)&& (raw[i + 3] == 101)&& (raw[i + 4] == 97)&& (raw[i + 5] == 109)) {
        		
        	    //ignore these characters and first return
        		i = i + 6;
        		
        		if (raw[i] == 13 && raw[i+1] == 10) //allow for double linefeed
        			i=i+2;
        		else if((raw[i]==10)|(raw[i]==13))
        			i++;
        		
        		int start = i;
        		
        		i--; //move pointer back 1 to allow for zero length stream
    
        		int streamLength=0;
        		String setLength=(String)objData.get("Length");
        		if(setLength!=null){
        			//read indirect
        			if(setLength.indexOf(" R")!=-1){
        				/**read raw object data*/
        				try{
        					long currentPos=movePointer(setLength);
        					
        					int buffSize=128;
        					if(currentPos+buffSize>eof)
        						buffSize=(int) (eof-currentPos-1);
        					StringBuffer rawChars=new StringBuffer();
        					byte[] buf=new byte[buffSize];
        					this.pdf_datafile.read(buf);
        					
        					int ii=3;
        					
        					//find start
        					while(true){
        						if((ii<buffSize)&&(buf[ii-3]==111)&&
        								(buf[ii-2]==98)&&(buf[ii-1]==106))
        							break;
        						ii++;
        					}
        					
        					//find first number
        					while(true){
        						if((ii<buffSize)&&(Character.isDigit((char)buf[ii])))
        							break;
        						ii++;
        					}
        					
        					//read number
        					while(true){
        						if((ii<buffSize)&&(Character.isDigit((char)buf[ii]))){
        							rawChars.append((char)buf[ii]);
        							ii++;
        						}else
        							break;
        					}
        					
        					movePointer(currentPos);
        					setLength=rawChars.toString();
        					
        				}catch(Exception e){
        					LogWriter.writeLog("Exception moving pointer to "+objectRef);
        					setLength=null;
        				}
        			}
        			
        			if(setLength!=null){
        				streamLength=Integer.parseInt(setLength);
            			i=start+streamLength;
        			}
        		}
        		int end=0;
        		if(setLength==null){
        			
            		while (true) { //find end
            			
            			i++;
            			
            			if(i==raw.length)
            				break;
            			if ((raw[i] == 101)&& (raw[i + 1] == 110)&& (raw[i + 2] == 100)&& (raw[i + 3] == 115)&& (raw[i + 4] == 116)
            				&& (raw[i + 5] == 114)&& (raw[i + 6] == 101)&& (raw[i + 7] == 97)&& (raw[i + 8] == 109))
            				break;
            			
            		}
        		
	        		end=i-1;
	        		
	        		/**lose any trailing returns*/
	        		while (((raw[end] == 10) | (raw[end] == 13)))
	        			end--;
	        		
	        		/**put into array*/
	        		if(end>start){
//	        			if(setLength!=null){
//	        				if(streamLength!=end-start+1){
//	        					System.out.println("oh dear "+streamLength+" "+(end-start+1));
//						//		System.exit(1);
//	        				}
//	        			}
	        			streamLength=end-start+1;
	        		}	
        		}
	        		
        		//System.out.println(objData);
        		//System.out.println(start+" "+end+" "+setLength+" "+streamLength+" "+raw.length);
	        	if(start+streamLength>raw.length)
	        		streamLength=raw.length-start;
        		stream = new byte[streamLength];
        		System.arraycopy(raw, start, stream, 0, streamLength);
        			
        		i = i + 9; //roll on pointer
        			
        	}else if(raw[i]==91){ //handle just a raw array ie [ /Separation /CMAN /DeviceCMYK 8 0 R]	
        		if(debug)
        			System.err.println("read array");
        		
        		i=readArray(objectRef,i,objData,raw,isEncryptionObject,textFields);
        	
        	}else if((raw[i]!=60)&(raw[i]!=62)){ //direct value
        		
        		if(preserveTextString){
        			
        			//allow for all escape combinations
        			if((raw[i-1]==92)&&(raw[i-2]==92)){
        					//stop match on //( or //)
        				rawStringAsBytes.write(raw[i]);
        			}else if(((raw[i]==40)|(raw[i]==41))&(raw[i-1]!=92)){
        						//ignore //
        			}else
        				rawStringAsBytes.write(raw[i]);
        		}
        		
        		if(((raw[i]==10)|(raw[i]==13)|(raw[i]==32))){
        			
        			if(remainder.length()>0)
        				remainder.append(' ');
        				
        			remainderLastChar=' ';
        			
        		}else{
        			
        			/**allow for no spaces in /a/b/c*/
        			if((raw[i]==47)&&(remainderLastChar!=' '))
        				remainder.append(' ');
        			
        			remainderLastChar=(char)raw[i];
        			remainder.append(remainderLastChar);	
        		}
        	}
        	
        	/**}else if((raw[i]!=60)&(raw[i]!=62)&(raw[i]!=10)&(raw[i]!=13)&(raw[i]!=32)){ //direct value
        			remainder.append((char)raw[i]);				}*/
        }
        
        /**strip any comment from remainder*/
        if(remainder.length()>0)	{
        	int ii=remainder.toString().indexOf("%");
        	if(ii>-1)
        		remainder.setLength(ii);
        }
        
        if(remainder.length()>0)	{
            String rawString=remainder.toString().trim();
        	if((preserveTextString)&&(rawString.startsWith("("))){
        		try {
        			rawStringAsBytes.close();
        
        		  	byte[] streamData=(byte[]) rawStringAsBytes.toByteArray();
        			streamData=decrypt(streamData,objectRef,null,false);
        	       	objData.put("rawValue",streamData); //save pair and reset
        		
        		} catch (Exception e) {
        			LogWriter.writeLog("Exception "+e+" writing out text string");
        		}
        		
        	}else{
        		if(debug)
        			System.err.println("Remainder value="+remainder+"<<");
        		objData.put("rawValue",rawString);	
        	}
        }
        	
        if(stream!=null)
        objData.put("Stream",  stream);
        
        if(debug)
        System.err.println(objData);
        
        try {
			rawStringAsBytes.close();
		} catch (IOException e) {
			e.printStackTrace();
    		}
    }
    /**
     * read an array
     */
	private int readArray(String objectRef,int i,Map objData,byte[] raw,boolean isEncryptionObject,Map textFields){	
			
			boolean debug=false;
			int start=0,end=0;
			boolean maybeKey=false;
			StringBuffer rawValue=new StringBuffer();
			StringBuffer possKey=new StringBuffer();
		
			while(true){
				
				if(maybeKey){
				
					int j=i;
					
					if(debug)
						System.out.println((char)raw[j]);
				
					//find first valid char
					while((raw[j]==13)|(raw[j]==10)|(raw[j]==32))
					j++;
					
					if(debug)
						System.out.println((char)raw[j]);
				
					if((raw[j]==60)&&(raw[j+1]==60)){
						
						if(debug)
							System.out.println("Poss key");;
						i=j;
						Map subDictionary=new Hashtable();
						objData.put(possKey.substring(1),subDictionary);
						i=readDictionary(objectRef,1,subDictionary,i,raw,isEncryptionObject,textFields);
						
						//roll on if needed
						if(raw[i]==62)
							i++;
					
						possKey=new StringBuffer();
					}else{
						
						if(debug)
							System.out.println("Get value");
						if(rawValue.charAt(rawValue.length()-1)!=' ')
							rawValue.append(' ');
						
						rawValue.append(possKey);
						rawValue.append(' ');
						possKey=new StringBuffer();
						maybeKey=false;
						i--;
						
						if(debug)
							System.out.println("Value="+possKey);
					}
				
				//identify possible keys and read
				}else if(raw[i]==47){
					
					if(debug)
						System.out.println("Found /");
					
					maybeKey=true;
					while(true){
						possKey.append((char)raw[i]);
						i++;
						
						//allow for [/value] by updating end count
						if(raw[i]==93)
							end++;
			
						if((raw[i]==47)|(raw[i]==13)|(raw[i]==10)|(raw[i]==32)|(raw[i]==60)|(raw[i]==93))
						break;
						
					}
					
					if(debug)
						System.out.println("Key="+possKey);
					
				}else{		
					
					//if(debug)
					//	System.out.println("Else"+" "+(char)raw[i]);
					
					if(raw[i-1]==47){ //needed for [/Indexed /DeviceCMYK 60 1 0 R] to get second /
						rawValue.append('/');
					}
					
					if ((raw[i] == 13) | (raw[i] == 10)) //added as lines split in ghostscript output
						rawValue.append(' ');
					else 
						rawValue.append((char) raw[i]);
				
					if(raw[i-1]!=92){ 
						if(raw[i]==91)
							start++;
						else if(raw[i]==93)
							end++;
					}
				}
			
				if((raw[i]==93)&(start==end))
					break;
			
				i++;
			}
		
			objData.put("rawValue",rawValue.toString().trim());
			
			
			if(debug){
				System.out.println(rawValue+" "+objData);
			}
			return i;
	}

	/**
	 * read reference table start to see if new 1.5 type or traditional xref
	 * @throws PdfException
	 */
	final public String readReferenceTable() throws PdfException {
	    
	    int pointer = readFirstStartRef(),eof=-1;
	    xref.addElement(pointer);
	    try{
	        eof = (int) pdf_datafile.length();
	    } catch (Exception e) {
	        try {
                this.pdf_datafile.close();
            } catch (IOException e1) {
               LogWriter.writeLog("Exception "+e+" closing file");
            }
		    
            throw new PdfException("Exception " + e + " reading trailer");
		}
	    
		if(pointer>=eof){
			LogWriter.writeLog("Pointer not if file - trying to manually find startref");
			refTableInvalid=true;
			return findOffsets();
		}else if(isCompressedStream(pointer,eof)){
		    return readCompressedStream(pointer,eof);
		}else
		    return readLegacyReferenceTable(pointer,eof);
	    
	}
	
	/** Utility method used during processing of type1C files */
	final private int getWord(byte[] content, int index, int size) {
		int result = 0;
		for (int i = 0; i < size; i++) {
			result = (result << 8) + (content[index + i] & 0xff);

		}
		return result;
	}
	
	/**
     * read 1.5 compression stream ref table
	 * @throws PdfException
     */
    private String readCompressedStream(int pointer, int eof)
            throws PdfException {

        String rootObject = "", encryptValue = null, value,Index;
        int current,numbEntries;

        while (pointer != -1) {
            
            /**
             * get values to read stream ref
             */
            Map obj_values = readObject(pointer, false, null);
            String ref=(String) obj_values.get("Reference");
            
            value=(String) obj_values.get("Index");
            if(value==null){
                current=0;
                numbEntries=Integer.parseInt((String)obj_values.get("Size"));
            }else{
                Index=Strip.removeArrayDeleminators(value);
                StringTokenizer values=new StringTokenizer(Index);
                current=Integer.parseInt(values.nextToken());
                numbEntries=Integer.parseInt(values.nextToken());
            }
            
            //read the field sizes
            value=(String) obj_values.get("W");
            int[] fieldSizes=new int[3];
            StringTokenizer  values=new StringTokenizer(Strip.removeArrayDeleminators(value));
            for(int i=0;i<3;i++)
                fieldSizes[i]=Integer.parseInt(values.nextToken());
            
            //now read the xrefs stream
            byte[] xrefs=this.readStream(obj_values,ref,true);
            
            //now parse the stream and extract values
            int pntr=0;
            int[] defaultValue={1,0,0};
            for(int i=0;i<numbEntries;i++){
                
                //read the next 3 values
                int[] nextValue=new int[3]; 
                for(int ii=0;ii<3;ii++){
                		if(fieldSizes[ii]==0){
                			nextValue[ii]=defaultValue[ii];
                		}else{
                			nextValue[ii]=getWord(xrefs,pntr,fieldSizes[ii]);
                			pntr=pntr+fieldSizes[ii];
                		}
                }
                
                //handle values appropriately
                int id=0,gen;
                switch(nextValue[0]){
                		case 0:
                			current=nextValue[1];
                		    gen=nextValue[2];
                		    current++;
                		    
                		break;
                		case 1:
                		    id=nextValue[1];
                		    gen=nextValue[2];
                		    storeObjectOffset(current, id, gen,false);
                		    current++;
                		break;
                		case 2:
                		    id=nextValue[1];
                		    gen=nextValue[2];
                		    storeObjectOffset(current, id, gen,true);
                		    current++;
                		    
                		break;
                		default:
                		    throw new PdfException("Exception Unsupported Compression mode with value "+nextValue[0]);
                		
                }
            }
            
            /**
             * now process trailer values - only first set of table values for
             * root, encryption and info
             */
            if (rootObject.length() == 0) {

                value = (String) obj_values.get("Root"); //get root
                if (value != null)
                    rootObject = value;

                /**
                 * handle encryption (currently just looks for Encryption
                 * object)
                 */
                encryptValue = (String) obj_values.get("Encrypt");

                if (encryptValue != null) {
                    ID = (String) obj_values.get("ID"); //get ID object
                    if (ID == null) {
                        ID = "";
                    } else {
                        ID = Strip.removeArrayDeleminators(ID);

                        if (ID.startsWith("<"))
                            ID = ID.substring(1, ID.indexOf(">"));
                    }
                }

                value = (String) obj_values.get("Info"); //get Info object
                if ((value != null)
                        && ((!this.isEncrypted()) | (this.isPasswordSupplied())))
                    infoObject = value;
                else
                    infoObject = null;

            }

            //make sure first values used if several tables and code for prev
            value = (String) obj_values.get("Prev");
            //see if other trailers
            if (value != null) {
                obj_values = new Hashtable();
                pointer = Integer.parseInt(value);
            } else
                pointer = -1;
        }

        calculateObjectLength();
        
        return rootObject;
    }
    
    /**
     * test first bytes to see if new 1.5 style table with obj or contains ref
     * @throws PdfException
     */
    private boolean isCompressedStream(int pointer,int eof) throws PdfException {
        
        boolean isCompressed=false;
        int bufSize = 50,charReached=0;
        
        final int UNSET=-1;
        final int COMPRESSED=1;
        final int LEGACY=2;
        int type=UNSET;
        byte[] newPattern = new String("obj").getBytes();
        byte[] oldPattern = new String("ref").getBytes();
        
        while (true) {
            
            /** adjust buffer if less than 1024 bytes left in file */
            if (pointer + bufSize > eof)
                bufSize = eof - pointer;
            
            if(bufSize<0)
            	bufSize=50;
            byte[] buffer = new byte[bufSize];
            
            /** get bytes into buffer */
            movePointer(pointer);
            try{
                pdf_datafile.read(buffer);
            } catch (Exception e) {
                try {
                    this.pdf_datafile.close();
                } catch (IOException e1) {
                   LogWriter.writeLog("Exception "+e+" closing file");
                }
                
                throw new PdfException("Exception " + e + " scanning trailer for ref or obj");
            }
            
            /**look for xref or obj */
            for (int i = 0; i < bufSize; i++) {
                
                byte currentByte = buffer[i];
               
                /** check for xref OR end - reset if not */
                if ((currentByte == oldPattern[charReached])&&(type!=COMPRESSED)){
                    charReached++;
                    type=LEGACY;
                }else if ((currentByte == newPattern[charReached])&&(type!=LEGACY)){
                    charReached++;
                    type=COMPRESSED;
                }else{
                    charReached = 0;
                    type=UNSET;
                    
                }
                
                //update pointer
                pointer = pointer + bufSize;
                
                if (charReached == 2)
                    break;
                
            }
            
            if(charReached==2)
                break;
        }
        
        /**
         * throw exception if no match or tell user which type
         */
        if(type==UNSET){
            try {
                this.pdf_datafile.close();
            } catch (IOException e1) {
               LogWriter.writeLog("Exception "+1+" closing file");
            }
            throw new PdfException("Exception unable to find ref or obj in trailer");
        }
        
        if(type==COMPRESSED)
            return true;
        else
            return false;
    }
   
	/**
	 * read reference table from file so we can locate
	 * objects in pdf file and read the trailers
	 */
	final private String readLegacyReferenceTable(int pointer,int eof) throws PdfException {
		String line = "", rootObject = "", value = "", flag = "",encryptValue=null;
		//holds the f or n
		int id = 0; //offset for each object
		int generation = 0; //used to hold generation number for each object
		boolean notID=true;
		int current = 0; //current object number
		byte[] Bytes = null;
		int bufSize = 1024,p;
		
		int charReached = 0, endTable = 0;
		byte[] pattern = { 37, 37, 69, 79, 70 }; //pattern %%EOF
		
		Map obj_values = new Hashtable();
		
		/**read and decode 1 or more trailers*/
		while (true) {
	
			try {
	
				//allow for pointer outside file
				
				Bytes=readTrailer(bufSize, charReached, pattern, pointer, eof);
				
			} catch (Exception e) {
				Bytes=null;
				try {
                    this.pdf_datafile.close();
                } catch (IOException e1) {
                   LogWriter.writeLog("Exception "+e+" closing file");
                }
				throw new PdfException("Exception " + e + " reading trailer");
			}
	
			if (Bytes == null) //safety catch
				break;
			
			/**get trailer*/
			int i = 0;
			StringBuffer startRef = new StringBuffer();
			StringBuffer key = new StringBuffer();
			StringBuffer operand = new StringBuffer();
			
			int maxLen=Bytes.length;
			
			
			//for(int a=0;a<100;a++)
			//	System.out.println((char)Bytes[i+a]);
			while (i <maxLen) {//look for trailer keyword
				if ((Bytes[i] == 116)& (Bytes[i + 1] == 114)& (Bytes[i + 2] == 97)& (Bytes[i + 3] == 105)& (Bytes[i + 4] == 108)& (Bytes[i + 5] == 101)& (Bytes[i + 6] == 114))
					break;
				
				i++;
			}
			
			//save endtable position for later
			endTable = i;
	
			//move to beyond <<
			while ((Bytes[i] != 60) && (Bytes[i + 1] != 60))
				i++;
				
			i = readRef2(Bytes, obj_values, i, key, operand);
		
			//System.out.println(obj_values);
			
			//look for xref as end of startref
			while ((Bytes[i] != 116)&& (Bytes[i + 1] != 120)
				&& (Bytes[i + 2] != 114)&& (Bytes[i + 3] != 101)&& (Bytes[i + 4] != 102)) 
				i++;
			
			i = i + 8;
			//move to start of value ignoring spaces or returns
			while ((i < maxLen)&& ((Bytes[i] == 10)| (Bytes[i] == 32)| (Bytes[i] == 13)))
				i++;
			
			//allow for characters between xref and startref
			while ((i < maxLen)&& (Bytes[i] != 10)&& (Bytes[i] != 32)&& (Bytes[i] != 13)) {
				startRef.append((char) Bytes[i]);
				i++;
			}
			
			/**convert xref to string to get pointer*/
			if (startRef.length() > 0)
				pointer = Integer.parseInt(startRef.toString());
	
			if (pointer == -1) {
				LogWriter.writeLog("Problem with startRef");
				
				/**now read the objects for the trailers*/
			} else if ((Bytes[0] == 120)& (Bytes[1] == 114)& (Bytes[2] == 101)& (Bytes[3] == 102)) { //make sure starts xref
	
				i = 5;
				
				//move to start of value ignoring spaces or returns
				while (((Bytes[i] == 10)| (Bytes[i] == 32)| (Bytes[i] == 13)))
					i++;
		
				current = readXRefs(current, Bytes, endTable, i);
				i=endTable;
				/**now process trailer values - only first set of table values for root, encryption and info*/
				if (rootObject.length() == 0) {
				
					value = (String) obj_values.get("Root"); //get root
					if (value != null)
						rootObject = value;
				
					/**handle encryption (currently just looks for Encryption object)*/
					encryptValue = (String) obj_values.get("Encrypt");
					
					if (encryptValue != null){
						ID = (String) obj_values.get("ID"); //get ID object
						if(ID==null){
							ID="";
						}else{
							ID=Strip.removeArrayDeleminators(ID);
							
							if(ID.startsWith("<"))
							ID=ID.substring(1,ID.indexOf(">"));
						}
						
					}
					
					value = (String) obj_values.get("Info"); //get Info object
					if ((value != null)&&((!this.isEncrypted())|(this.isPasswordSupplied())))
					    infoObject=value;
					else
					    infoObject=null;
						
				}
				
				//make sure first values used if several tables and code for prev
				value = (String) obj_values.get("Prev");
				//see if other trailers
				if (value != null) {
					//reset values for loop
					bufSize = 1024;
					charReached = 0;
					obj_values = new Hashtable();
					pointer = Integer.parseInt(value);
					
					//track ref table so we can work out object length
					xref.addElement(pointer);
	
				} else
					pointer = -1;
	
			} else{
				pointer=-1;
				rootObject = findOffsets();
				refTableInvalid=true;
			}
			if (pointer == -1)
				break;
		}
	
		/**
		 * check offsets
		 */
		//checkOffsets(validOffsets);
		if(encryptValue!=null)
		readEncryptionObject(encryptValue);
			
		if(!refTableInvalid)
		calculateObjectLength();
		
		return rootObject;
	}

	/**
     * precalculate sizes for each object
     */
    private void calculateObjectLength() {
        
        //add eol to refs as catchall
        try{
            this.xref.addElement( (int) pdf_datafile.length());
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    
        //get order list of refs
        int[] xrefs=this.xref.get();
        int xrefCount=xrefs.length;
        int[] xrefID=new int[xrefCount];                    
        for(int i=0;i<xrefCount;i++)
            xrefID[i]=i;
        xrefID=Sorts.quicksort( xrefs, xrefID );
        
        //get ordered list of objects in offset order
        int objectCount=offset.getCapacity();
        ObjLengthTable=new int[objectCount];
        int[] id=new int[objectCount];  
        int[] offsets=new int[objectCount];
        
        //read from local copies and pop lookup table
        int[] off=offset.get();
        boolean[] isComp=isCompressed.get();
        for(int i=0;i<objectCount;i++){
        		if(!isComp[i]){
        			offsets[i]=off[i];
        			id[i]=i;
        		}
        }
        
        id=Sorts.quicksort( offsets, id );
        
        int i=0;
        //ignore empty values
        while(true){
            if(offsets[id[i]]!=0)
                break;
            i++;
        }
        
        /**
         * loop to calc all object lengths
         * */
        int  start=offsets[id[i]],end;
        
        //find next xref
        int j=0;
        while(xrefs[xrefID[j]]<start+1)
            j++;
        
        while(i<objectCount-1){
            
            end=offsets[id[i+1]];
            int objLength=end-start-1;
            
            //adjust for any xref
            if(xrefs[xrefID[j]]<end){
                objLength=xrefs[xrefID[j]]-start-1;
                while(xrefs[xrefID[j]]<end+1)
                    j++;
            }
            ObjLengthTable[id[i]]=objLength;
            //System.out.println(id[i]+" "+objLength+" "+start+" "+end);
            start=end;
            while(xrefs[xrefID[j]]<start+1)
                j++;
            i++;
        }
        
        //special case - last object
        
        ObjLengthTable[id[i]]=xrefs[xrefID[j]]-start-1;
        //System.out.println("*"+id[i]+" "+start+" "+xref+" "+eof);
    }
    /**
     * read table of values
     */
    private int readXRefs( int current, byte[] bBytes, int endTable, int i) {
    	
    	byte[] Bytes=bBytes;
    	
    	int p;
    	char flag='c';
		int id=0,tokenCount=0;
		int generation=0;
		int lineLen=0;
		int startLine,endLine;
		
    	int[] breaks=new int[5];
		int[] starts=new int[5];
    	
    	// loop to read all references
    	while (i < endTable) { //exit end at trailer
    		
    		startLine=i;
    		endLine=-1;
    		
    		/**
    		 * read line locations
    		 */
    		//move to start of value ignoring spaces or returns
    		while ((Bytes[i] != 10) & (Bytes[i] != 13)) {
    			//scan for %
    			if((endLine==-1)&&(Bytes[i]==37))
				endLine=i-1;
				
    			i++;
    		}
    		
    		//set end if no comment
    		if(endLine==-1)
    		endLine=i-1;
    		
    		//strip any spaces
    		while(Bytes[startLine]==32)
    			startLine++;
    		
    		//strip any spaces
    		while(Bytes[endLine]==32)
    			endLine--;
    		
    		i++;
    		
    		/**
    		 * decode the line
    		 */
    		tokenCount=0;
    		lineLen=endLine-startLine+1;
    		
    		if(lineLen>0){
    			
    			//decide if line is a section header or value
    			
    			//first count tokens
    			int lastChar=1,currentChar;
    			for(int j=1;j<lineLen;j++){
    				currentChar=(int) Bytes[startLine+j];
    					
    				if((currentChar==32)&&(lastChar!=32)){
    					breaks[tokenCount]=j;
    					tokenCount++;
    				}else if((currentChar!=32)&&(lastChar==32)){
    					starts[tokenCount]=j;
    				}
    				
    				lastChar=currentChar;
    			}
    			
    			//update numbers so loops work
    			breaks[tokenCount]=lineLen;
    			tokenCount++;
    			
    			if (tokenCount == 2){   				
    				current=parseInt(startLine,startLine+breaks[0],Bytes);	
    			}else {
    				
    				id = parseInt(startLine,startLine+breaks[0],Bytes);
    				generation=parseInt(startLine+starts[1],startLine+breaks[1],Bytes);
    				
    				flag =(char)Bytes[startLine+starts[2]]; 
				if (flag=='n') { // only add objects in use
    					storeObjectOffset(current, id, generation,false);
    					xref.addElement( id);
    				}
    				current++; //update our pointer
    			}
    		}
    	}
    	return current;
    }
    
    private final static int[] powers={1,10,100,1000,10000,100000,1000000,10000000,100000000,
    		1000000000};
    
    /**
	 * turn stream of bytes into a number
	 */
	private int parseInt(int i, int j, byte[] bytes) {
		int finalValue=0;
		int power=0;
		i--; //decrement  pointer to speed up
		for(int current=j-1;current>i;current--){
			finalValue=finalValue+(((int)bytes[current]-48)*powers[power]);
			//System.out.println(finalValue+" "+powers[power]+" "+current+" "+(char)bytes[current]+" "+bytes[current]);
			power++;
		}
		//System.exit(1);
		return finalValue;
	}
	
	/**
     * @param Bytes
     * @param obj_values
     * @param i
     * @param key
     * @param operand
     * @return
     */
    private int readRef2(byte[] Bytes, Map obj_values, int i, StringBuffer key, StringBuffer operand) {
        boolean notID;
        int p;
        
        //now read key pairs until >>
        while (true) {
        	
        	i++;
        	
        	//exit at closing >>
        	if ((Bytes[i] == 62) && (Bytes[i + 1] == 62))
        		break;

        	if (Bytes[i] == 47) { //everything from /
        		
        		i++;
        		//get key up to space or [
        		while (true) {
        			if ((Bytes[i] == 32) | (Bytes[i] == 91)|(Bytes[i] == 10)|(Bytes[i] == 13)|(Bytes[i]==60))
        				break;

        			key.append((char) Bytes[i]);
        			i++;
        		}
        		
        		if((key.length()==2)&&(key.charAt(0)=='I')&&(key.charAt(1)=='D'))
        			notID=false;
        		else
        			notID=true;
        		
        		//ignore spaces some pdf use ID[ so we trap for [ (char 91)
        		if ((Bytes[i] != 91)) {
        			while (Bytes[i] == 32)
        				i++;
        		}
        	
        		int Oplen=0,brackets=0;
        		
        		int dictCount=0;
        		//get operand up to end
        		while (true) {
        			
        			char c = (char) Bytes[i];
        			
        			if((Bytes[i-1]==60)&&(Bytes[i]==60))
        					dictCount++;
        			
        			if((c=='(')&&(i>0)&&((Bytes[i-1]!=92)|((i>1)&&(Bytes[i-1]==92)&&(Bytes[i-2]!=92))))
        					brackets++;
        			else if((c==')')&&(i>0)&&((Bytes[i-1]!=92)|((i>1)&&(Bytes[i-1]==92)&&(Bytes[i-2]!=92))))
        					brackets++;
        			
        			//System.out.print(c);
        			if((c == 47)&notID&&(dictCount==0)) //allow for no spacing
        			i--;
        			
        			//allow for ID=[<3a4614ef17287563abfd439fbb4ad0ae><7d0c03d0767811d8b491000502832bed>]/Pr
        			//also allow for ID[(])()]
        			if((!notID)&&(c==']')&&(brackets==0))
        					break;
        			
        			if ((dictCount==0)&&(((c == 10) | (c == 13) | ((c == 47)&&notID))&&(Oplen>0)))
        				break;
        			
        			//exit at closing >>
        			if ((Bytes[i] == 62) && (Bytes[i + 1] == 62)){
        				if(dictCount==0)
        					break;
        				else
        					dictCount--;
        			}
        				
        			//allow for escape
        			if (c == '\\') {
        				i++;
        				c = (char) Bytes[i];	
        			}

        			//avoid returns at start
        			if ((( Bytes[i] == 10) | ( Bytes[i]== 13))&(Oplen==0)){
        			}else{
        				operand.append((char) Bytes[i]);
        				Oplen++;
        			}
        			
        			i++;
        		}
        		
        		operand = removeTrailingSpaces(operand);

        		//save pair and reset - allow for null value
        		String finalValue= operand.toString();
        		if(!finalValue.equals("null")){
        			p=finalValue.indexOf("%");
        			if((p!=-1)&(finalValue.indexOf("\\%")!=p-1))
        			finalValue=finalValue.substring(0,p).trim();

        			obj_values.put(key.toString(),finalValue);
        		
        		}

        		key = new StringBuffer();
        		operand = new StringBuffer();

        	}
        			
        	if ((Bytes[i] == 62) && (Bytes[i + 1] == 62))
        	break;
        	
        }
        return i;
    }
    /**
     * @param bufSize
     * @param charReached
     * @param pattern
     * @param pointer
     * @param bis
     * @param eof
     * @throws IOException
     */
    private byte[] readTrailer(int bufSize, int charReached, byte[] pattern,
            int pointer, int eof) throws IOException {

    		/**read in the bytes, using the startRef as our terminator*/
		ByteArrayOutputStream bis = new ByteArrayOutputStream();
		
        while (true) {

            /** adjust buffer if less than 1024 bytes left in file */
            if (pointer + bufSize > eof)
                bufSize = eof - pointer;

            byte[] buffer = new byte[bufSize];

            /** get bytes into buffer */
            movePointer(pointer);
            pdf_datafile.read(buffer);
            
            boolean endFound=false;

            /** write out and lookf for startref at end */
            for (int i = 0; i < bufSize; i++) {

                byte currentByte = buffer[i];

                /** check for startref at end - reset if not */
                if (currentByte == pattern[charReached])
                    charReached++;
                else
                    charReached = 0;

                if (charReached == 5){ //located %%EOF and get last few bytes
                	
	                	for (int j = 0; j < i+1; j++) 
	                		bis.write(buffer[j]);
	                	
	                	i = bufSize;
	                	endFound=true;
                	
                }
            }
            
            //write out block if whole block used
            if(!endFound)
            		bis.write(buffer);
            
            //update pointer
            pointer = pointer + bufSize;

            if (charReached == 5)
                break;

        }
        
        bis.close();
        return bis.toByteArray();
		
    }
    /**
     * read the form data from the file
     * @return
     */
    final public PdfFileInformation readPdfFileMetadata(String ref) {
    
        //read info object (may be defined and object set in different trailers so must be done at end)
    	if((infoObject!=null)&&((!isEncrypted)|(isPasswordSupplied)))
    		readInformationObject(infoObject);
    	
    	//read and set XML value
    	if(ref!=null)
    	    currentFileInformation.setFileXMLMetaData(convertStreamToXML(ref).toString());
        
    	return currentFileInformation;
    }

	
    /**
     * take object ref for XML in stream, read and return as StringBuffer
     */
    public  StringBuffer convertStreamToXML(String ref) {
        
        StringBuffer XMLObject = null;
        if(ref!=null){
            XMLObject = new StringBuffer();
            
            String line = "";
            BufferedReader mappingStream =null;
            ByteArrayInputStream bis=null;
            
            //get stream of data and read
            try {
                
                byte[] stream = readStream(ref);
                bis=new ByteArrayInputStream(stream);
                mappingStream =
                    new BufferedReader(
                            new InputStreamReader(bis));
                
                //read values into lookup table
                if (mappingStream != null) {
                    
                    while (true) {
                        line = mappingStream.readLine();
                        
                        if (line == null)
                            break;
                        
                        //append to XML data
                        XMLObject.append(line);
                        XMLObject.append('\n');
                    }
                }
            } catch (Exception e) {
                LogWriter.writeLog(
                        "Exception " + e + " reading XML object " + ref);	
            }
            
            if(mappingStream!=null){
                try {
                    mappingStream.close();
                    bis.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            
        }
        
        return XMLObject;
    }
    //////////////////////////////////////////////////////////////////////////
	  /**
	   * get value which can be direct or object
	   */
	  final public String getValue(String value) {
		
		  if ((value != null)&&(value.endsWith(" R"))){ //indirect
		
			  Map indirectObject=readObject(value,false, null);
			  //System.out.println(value+" "+indirectObject);
			  value=(String) indirectObject.get("rawValue");
			
		  }
		
		  return value;
	  }
	  
//////////////////////////////////////////////////////////////////////////
	  /**
	   * get text value as byte stream which can be direct or object
	   */
	  final public byte[] getByteTextStringValue(Object rawValue,Map fields) {
	  	
	  	if(rawValue instanceof String){
	  		String value=(String) rawValue;
	  		if ((value != null)&&(value.endsWith(" R"))){ //indirect
	  			
	  			Map indirectObject=readObject(value,false, fields);
	  			
	  			rawValue=(byte[]) indirectObject.get("rawValue");
	  			
	  		}
	  	}
	  	
	  	return (byte[]) rawValue;
	  }
	  

		/**
		 * get sub dictionary value which can be direct or object
		 */
		final public Map getSubDictionary(Object  value) {
		
			if(value instanceof String){
				return readObject((String)value,false, null);
			}else{
				return (Map) value;
			}
			
		}
	
	/**remove any trailing spaces at end*/
	private StringBuffer removeTrailingSpaces(StringBuffer operand) {

		/*remove any trailing spaces on operand*/
		int l = operand.length();
		for (int ii = l - 1; ii > -1; ii--) {
			if (operand.charAt(ii) == ' ')
				operand.deleteCharAt(ii);
			else
				ii = -2;
		}

		return operand;

	}
	
	/**convert to String*/
		public static  String convertToString(byte[] byteStream) {

			StringBuffer operand=new StringBuffer();
			
			/*remove any trailing spaces on operand*/
			int l = byteStream.length;
			for (int ii =0; ii<l; ii++) {
				operand.append((char)byteStream[ii]);
			}

			return operand.toString();

		}

	/**
		 * return flag to show if encrypted
		 */
	final public boolean isEncrypted() {
		return isEncrypted;
	}
	
	/**
		 * return flag to show if valid password has been supplied
		 */
	final public boolean isPasswordSupplied() {
		return isPasswordSupplied;
	}

	/**
		 * return flag to show if encrypted
		 */
	final public boolean isExtractionAllowed() {
		return extractionIsAllowed;
	}
	
	/**show if file can be displayed*/
	public boolean isFileViewable() {
		
			return isFileViewable;
	}
	
	//////////////////////////////////////////////////////////////////////////
	  /**
	  * reads the line/s from file which make up an object
	  * includes move
	  */
	  final private byte[] decrypt(byte[] data,String ref,byte[] key,boolean isEncryption) throws PdfSecurityException{
 		
//<start-13>
			  if((isEncrypted)|(isEncryption)){
				
				byte[] currentKey=new byte[keyLength];
			  	
			  	if(ref.length()>0)
				currentKey=new byte[keyLength+5];
				
				if(key==null){
					for(int ii=0;ii<keyLength;ii++)
					currentKey[ii]=encryptionKey[ii];
					
				}else{
					for(int ii=0;ii<keyLength;ii++)
					currentKey[ii]=key[ii];
				}
				
					try{
					
						if(ref.length()>0){
							int pointer=ref.indexOf(" ");
							int pointer2=ref.indexOf(" ",pointer+1);
						
							int obj=Integer.parseInt(ref.substring(0,pointer));
							int gen=Integer.parseInt(ref.substring(pointer+1,pointer2));
						
							currentKey[keyLength]=((byte)(obj & 0xff));
							currentKey[keyLength+1]=((byte)((obj>>8) & 0xff));
							currentKey[keyLength+2]=((byte)((obj>>16) & 0xff));
							currentKey[keyLength+3]=((byte)(gen & 0xff));
							currentKey[keyLength+4]=((byte)((gen>>8) & 0xff));
						}
						byte[] finalKey = new byte[Math.min(currentKey.length,16)];
						if(ref.length()>0){
							MessageDigest currentDigest =MessageDigest.getInstance("MD5"); 	
							currentDigest.update(currentKey);
							System.arraycopy(currentDigest.digest(),0, finalKey,0, finalKey.length);
						}else{
							System.arraycopy(currentKey,0, finalKey,0, finalKey.length);
						}	
						
						/**only initialise once - seems to take a long time*/
						if(cipher==null)	
						cipher = Cipher.getInstance("RC4");
						
						SecretKey testKey = new SecretKeySpec(finalKey, "RC4");
						
						if(isEncryption)
						cipher.init(Cipher.ENCRYPT_MODE, testKey);
						else
						cipher.init(Cipher.DECRYPT_MODE, testKey);
						
						data=cipher.doFinal(data);
						
					}catch(Exception e){
					    
						throw new PdfSecurityException("Exception "+e+" decrypting content");
						
					}

			  }
			  
			   //<end-13>
			  return data;
	  }	

	/**
	 * routine to create a padded key
	 */
	private byte[] getPaddedKey(byte[] password){
			
			/**get 32 bytes for  the key*/
			byte[] key=new byte[32];

			int passwordLength=password.length;
			if(passwordLength>32)
			    passwordLength=32;

			for(int ii=0;ii<passwordLength;ii++)
                key[ii]= encryptionPassword[ii];
		
			for(int ii=passwordLength;ii<32;ii++){
			
				key[ii]=(byte)Integer.parseInt(padding[ii-passwordLength],16);
				
				
			}
		
			return key;
	}
	
	/**see if valid for password*/
	private boolean testUserPassword() throws PdfSecurityException{
			
			int count=32;
			
			byte[] rawValue=new byte[32];
			
			byte[] keyValue=new byte[32];
		
			for(int i=0;i<32;i++)
			rawValue[i]=(byte)Integer.parseInt(padding[i],16);
			
			byte[] encryptedU=(byte[])rawValue.clone();

			if (rev==2) {
				encryptionKey=calculateKey(O,P,ID);
				encryptedU=decrypt(encryptedU,"",null,true);
				
			} else if(rev==3) {
				count=16;	
				encryptionKey=calculateKey(O,P,ID);
				byte[] originalKey=(byte[]) encryptionKey.clone(); 
				
				MessageDigest md = null;
				try { 
					md = MessageDigest.getInstance("MD5"); 
				} catch (Exception e) {
					LogWriter.writeLog("Exception "+e+" with digest");
				}
				
				md.update(encryptedU);
				
				//feed in ID
				keyValue=new byte[ID.length()/2];
				for(int ii=0;ii<ID.length();ii=ii+2){
					String nextValue=ID.substring(ii,ii+2);
					keyValue[ii/2]=(byte)Integer.parseInt(nextValue,16);
				}
				
				keyValue = md.digest(keyValue);
				keyValue=decrypt(keyValue,"",null,true);
					
				byte[] nextKey = new byte[keyLength];
				
				for (int i=1; i<=19; i++) {
		
					for (int j=0; j<keyLength; j++) 
					nextKey[j] = (byte)(originalKey[j] ^ i);
	
					encryptionKey=nextKey;
					keyValue=decrypt(keyValue,"",null,true);
	
				}
				
				encryptionKey=originalKey;

				encryptedU = new byte[32];
				System.arraycopy(keyValue,0, encryptedU,0, 16);
				System.arraycopy(rawValue,0, encryptedU,16, 16);
				
			}
			
			boolean isMatch=true;
			
			for(int i=0;i<count;i++){
				if(U[i]!=encryptedU[i]){
					isMatch=false;
					i=U.length;
				}
			}
		
			return isMatch;
	}
	
	/**set the key value*/
	private void setKey() throws PdfSecurityException{
		MessageDigest md=null;
		
					/**calculate key to use*/
					byte[] key=getPaddedKey(encryptionPassword);
				
					/**feed into Md5 function*/
					try{
	
						// Obtain a message digest object.
						md = MessageDigest.getInstance("MD5"); 
						encryptionKey=md.digest(key);
						
						/**rev 3 extra security*/
						if(rev==3){
							for (int ii=0; ii<50; ii++) 
							encryptionKey = md.digest(encryptionKey);
						}


					}catch(Exception e){
								throw new PdfSecurityException("Exception "+e+" generating encryption key");
					}
											
	}
	
	/**see if valid for password*/
	private boolean testOwnerPassword() throws PdfSecurityException{
		
		byte[] originalPassword=this.encryptionPassword;
			
		byte[] ownerValue=new byte[keyLength];
		byte[] inputValue=(byte[])O.clone();
		setKey();
		byte[] originalKey=(byte[])encryptionKey.clone();		
			
		if(rev==2)
				ownerValue=decrypt(inputValue,"",null,false);
		else if(rev==3){
				
				ownerValue=inputValue;		
				byte[] nextKey = new byte[keyLength];
					
				for (int i=19; i>=0; i--) {
						
					for (int j=0; j<keyLength; j++) 
					nextKey[j] = (byte)(originalKey[j] ^ i);
					
					encryptionKey=nextKey;
					ownerValue=decrypt(ownerValue,"",null,false);
					
				}
		}	
			
		/**use for password*/
		/**	
		StringBuffer newKey=new StringBuffer();
		for(int ii=0;ii<ownerValue.length;ii++){
			newKey.append((char)ownerValue[ii]);
			System.out.print(ownerValue[ii]+" ");
		}
		*/
	
		encryptionPassword = ownerValue; //newKey.toString();
		
		setKey();
		boolean isMatch=testUserPassword();
		
		//put back to original if not in fact correct
		if(isMatch==false){
			encryptionPassword=originalPassword;
			setKey();
		}else{
		}
			
			return isMatch;
		}
	
	/**
     * find a valid offset
     */
    final private String findOffsets() throws PdfSecurityException {
        LogWriter
                .writeLog("Corrupt xref table - trying to find objects manually");

        String root_id = "";
        try {
            movePointer(0);
        } catch (Exception e) {

        }

        while (true) {
            String line = null;

            int i = (int) this.getPointer();

            try {
                line = pdf_datafile.readLine();
            } catch (Exception e) {
                LogWriter.writeLog("Exception " + e + " reading line");
            }
            if (line == null)
                break;

            if (line.indexOf(" obj") != -1) {

                int pointer = line.indexOf(" ");
                if (pointer > -1) {
                    int current_number = Integer.parseInt(line.substring(0,
                            pointer));
                    storeObjectOffset(current_number, i, 1,false);
                }
                
            } else if (line.indexOf("Root") != -1) {

                int start = line.indexOf("Root") + 4;
                int pointer = line.indexOf("R", start);
                if (pointer > -1)
                    root_id = line.substring(start, pointer + 1).trim();
            } else if (line.indexOf("/Encrypt") != -1) {
                //too much risk on corrupt file
                throw new PdfSecurityException("Corrupted, encrypted file");
            }
        }

        return root_id;
    }

	/**extract  metadata for  encryption object
	 */
	final public void readEncryptionObject(String ref) throws PdfSecurityException {

		//<start-13>
		if (!isInitialised) {
			isInitialised = true;
			SetSecurity.init();
		}
		
		//get values
		Map encryptionValues = readObject(ref, true, null);
		
		//check type of filter and see if supported
		String filter = (String) encryptionValues.get("Filter");
		int v = 1;
		String value = (String) encryptionValues.get("V");
		if (value != null)
			v = Integer.parseInt(value);

		value = (String) encryptionValues.get("Length");
		if (value != null)
			keyLength = Integer.parseInt(value) / 8;

		//throw exception if we have an unknown encryption method
		if ((v > 2) | (filter.indexOf("Standard") == -1))
			throw new PdfSecurityException(
				"Unsupported Encryption method " + encryptionValues);

		//get rest of the values (which are not optional)
		rev = Integer.parseInt((String) encryptionValues.get("R"));
		P = Integer.parseInt((String) encryptionValues.get("P"));

		Object OValue = encryptionValues.get("O");
		if (OValue instanceof String) {
			String hexString = (String) OValue;
			int keyLength = hexString.length() / 2;
			O = new byte[keyLength];

			for (int ii = 0; ii < keyLength; ii++) {
				int p = ii * 2;
				O[ii] =
					(byte) Integer.parseInt(hexString.substring(p, p + 2), 16);
			}

		} else {
			O = (byte[]) OValue;
		}

		Object UValue = encryptionValues.get("U");
		if (UValue instanceof String) {
			String hexString = (String) UValue;
			int keyLength = hexString.length() / 2;
			U = new byte[keyLength];

			for (int ii = 0; ii < keyLength; ii++) {
				int p = ii * 2;
				U[ii] =
					(byte) Integer.parseInt(hexString.substring(p, p + 2), 16);
			}

		} else {
			U = (byte[]) UValue;
		}

		//<end-13>
		isEncrypted = true;
		isFileViewable = false;

		LogWriter.writeLog("File has encryption settings");

		try{
			verifyAccess();
		}catch(PdfSecurityException e){
			LogWriter.writeLog("File requires password");
		}
		
	}	
	
	/**test password and set access settings*/
	private void verifyAccess() throws PdfSecurityException{
		
		/**assume false*/
		isPasswordSupplied=false;
		extractionIsAllowed=false;
		
		//<start-13>
		/**workout if user or owner password valid*/
		boolean isOwnerPassword =testOwnerPassword();
		
		if(!isOwnerPassword){
			boolean isUserPassword=testUserPassword();
			
			/**test if user first*/
			if(isUserPassword){
				//tell if not default value
				if(encryptionPassword.length>0)
				LogWriter.writeLog("Correct user password supplied ");
				
				isFileViewable=true;
				isPasswordSupplied=true;
				
				if((P & 16)==16)
				extractionIsAllowed=true;
				
			}else
				throw new PdfSecurityException("No valid password supplied");
			
		}else{
			LogWriter.writeLog("Correct owner password supplied");
			isFileViewable=true;
			isPasswordSupplied=true;
			extractionIsAllowed=true;
		}
		
		//<end-13>
	}
	
	/**
	 * calculate the key
	*/
	private byte[] calculateKey(byte[] O,int P,String ID) throws PdfSecurityException{
		
		MessageDigest md=null;
		
		byte[] keyValue=null;
		
		/**calculate key to use*/
		byte[] key=getPaddedKey(encryptionPassword);
		
		/**feed into Md5 function*/
		try{
			
			// Obtain a message digest object.
			md = MessageDigest.getInstance("MD5"); 
		
			md.update(key);
		
			//write in O
			md.update(O);
		
			byte[] PValue=new byte[4];
			PValue[0]=((byte)((P) & 0xff));
			PValue[1]=((byte)((P>>8) & 0xff));
			PValue[2]=((byte)((P>>16) & 0xff));
			PValue[3]=((byte)((P>>24) & 0xff));
		
			md.update(PValue);
		
			//feed in ID
			keyValue=new byte[ID.length()/2];
			for(int ii=0;ii<ID.length();ii=ii+2){
				String nextValue=ID.substring(ii,ii+2);
				keyValue[ii/2]=(byte)Integer.parseInt(nextValue,16);
			}
			
			keyValue = md.digest(keyValue);
			
			//for rev 3
			if(rev==3){
				for(int i=0;i<50;i++)
				keyValue = md.digest(keyValue);
			}
					
		}catch(Exception e){
	
			throw new PdfSecurityException("Exception "+e+" generating encryption key");
		}		
				
		/**put significant bytes into key*/
		byte[] returnKey = new byte[keyLength];
		System.arraycopy(keyValue,0, returnKey,0, keyLength);		
		
		return returnKey;
	}
	
	///////////////////////////////////////////////////////////////////////////
	/**
	 * read information object and return pointer to correct
	 * place
	 */
	final private void readInformationObject(String value) {

		try {

			//LogWriter.writeLog("Information object "+value+" present");

			Hashtable fields=new Hashtable();
			String[] names=currentFileInformation.getFieldNames();
			for(int ii=0;ii<names.length;ii++){
				fields.put(names[ii],"z");
			}
			
			//get info
			Map info_values = readObject(value,false, fields);
			
			//System.out.println(info_values);
			/**set the information values*/
					
					//put into fields so we can display
					for (int i = 0; i < names.length; i++){
						Object nextValue=info_values.get(names[i]);
						//System.out.println(names[i]);
						if(nextValue!=null){
							/**allow for stream value*/
							if(nextValue instanceof byte[]){
								//System.out.println(names[i]);
								String textValue=this.getTextString((byte[]) nextValue);
								//System.out.println(textValue+"<<<<<<<<<<<<<<<<<<<<<<<");
								currentFileInformation.setFieldValue( i,textValue);
							}else if(nextValue instanceof String ){
								String stringValue=(String)nextValue;
								if(stringValue.indexOf("False")!=-1){
									currentFileInformation.setFieldValue( i,"False");
								}else if(stringValue.indexOf("False")!=-1){
									currentFileInformation.setFieldValue( i,"True");
								}else{
									//System.out.println("TEXT value "+nextValue+" in file "+ObjectStore.getCurrentFilename());
									//System.exit(1);
									//currentFileInformation.setFieldValue( i,newValue.toString());
								}
							}else{
								//System.out.println("TEXT value "+nextValue+" in file "+ObjectStore.getCurrentFilename());
								//System.exit(1);
								//currentFileInformation.setFieldValue( i,newValue.toString());
							}
						}
					}
			
			
		} catch (Exception e) {
			System.out.println(" problem with info");
			LogWriter.writeLog(
				"Exception " + e + " reading information object "+value);
			//System.exit(1);
		}
	}
	/**
	 * return pdf data
	 */
	public byte[] getPdfBuffer() {
		return pdf_datafile.getPdfBuffer();
	}
	
	/**
	 * read a text String held in fieldName in string
	 */
	public String getTextString(byte[] rawText) {
		
		//make sure encoding loaded
		StandardFonts.checkLoaded(StandardFonts.PDF);
		
		String text="";
		StringBuffer convertedText=new StringBuffer();
		char nextChar;
		
		TextTokens rawChars=new TextTokens(rawText);
		
		//test to see if unicode
		if(rawChars.isUnicode()){
			//its unicode
			while(rawChars.hasMoreTokens()){
				nextChar=rawChars.nextUnicodeToken();
				if(nextChar==9)
					convertedText.append(' ');
				else if(nextChar>31)
					convertedText.append(nextChar);
			}
			
		}else{
			//pdfDoc encoding
			
			while(rawChars.hasMoreTokens()){
				nextChar=rawChars.nextToken();
				if(nextChar==9)
					convertedText.append(' ');
				else if(nextChar>31)
				convertedText.append(StandardFonts.getEncodedChar(StandardFonts.PDF,nextChar));
			}
		}
		//System.exit(1);
		return convertedText.toString();
		
	}
	
	/**
	 * read any names
	 */
	public void readNames(Object nameObj){
	    
	    Map values=null;
	    
	    if(nameObj instanceof String)
	        values=readObject((String)nameObj,false,null);
	    else
	        values=(Map) nameObj;
	    
	    Object dests= values.get("Dests");
	    
	    String names=(String) getValue((String) values.get("Names"));
	   
	    if(names!=null){
	        String nameList = Strip.removeArrayDeleminators(names); //get initial pages
	        if(nameList.startsWith("<feff")){ //handle [<feff005f00500041004700450031> 1 0 R]
	            StringTokenizer keyValues =new StringTokenizer(nameList);
	            while(keyValues.hasMoreTokens()){
	                String nextKey=keyValues.nextToken();
	                nextKey=nextKey.substring(1,nextKey.length()-1);
		            String value=keyValues.nextToken()+" "+keyValues.nextToken()+" "+keyValues.nextToken();
		            nameLookup.put(nextKey,value);
		            
	            }
	            
	        }else if(nameList.indexOf("(")!=-1){ //its a binary list so we need to read from the raw bytes
	        	
	        	/**read the raw bytes so we can decode correctly*/
	        	byte[] raw=readObjectAsByteArray((String) nameObj,false);
	        	int dataLen=raw.length;
	        	int i=0;
	        	
	                /**
	        	 *move to first (
	        	 */
	        	while(raw[i]!=40){
	        		i++;
		            }
	        	i++;
	        	
	        	/**
	        	 * read all value pairs
		            */
	        	while(i<dataLen){
		      
	        		ByteArrayOutputStream bis=new ByteArrayOutputStream();
	        		try{
	        			if(raw[i+1]!=41){ //trap empty field
		            
	        				/**
	        				 * read the bytes for the text string
	        				 */
	        				while(true){
	        					
	        					i++;
	        					boolean isOctal=false;
	        					
	        					//trap escape
	        					if((raw[i]==92)){
	        						i++;
	        						
	        						if(raw[i]=='b')
	        							raw[i]='\b';
	        						else if(raw[i]=='n')
	        							raw[i]='\n';
	        						else if(raw[i]=='t')
	        							raw[i]='\t';
	        						else if(raw[i]=='r')
	        							raw[i]='\r';
	        						else if(raw[i]=='f')
	        							raw[i]='\f';
	        						else if(Character.isDigit((char) raw[i])){ //octal
	        							StringBuffer octal=new StringBuffer(3);
	        							for(int ii=0;ii<3;ii++){
	        								octal.append((char)raw[i]);
	        								i++;
	            }
	        							//move back 1
	        							i--;
	        							isOctal=true;
	        							raw[i]=(byte) Integer.parseInt(octal.toString(),8);
	        						}
	        					}
	            
	        					//exit at end
	        					if((!isOctal)&&(raw[i]==41)&&(raw[i-1]!=92))
	        						break;
		            
	        					bis.write(raw[i]);	
		        }
	        			}
	        			
	        			//decrypt the text stream
	        			bis.close();
	        			byte[] streamData=(byte[]) bis.toByteArray();
	        			streamData=decrypt(streamData,(String)nameObj,null,false);
	        			
	        			
	        			/**
	        			 * read object  ref
	        			 */
	        			StringBuffer objectName=new StringBuffer();
	        			i++;
	        			int end=i;
	        			
	        			//ignore any extra spaces
	        			while(raw[end]==32)
	        				end++;
	        			
	        			//find next start (
	        			while((raw[end]!=40)&(end+1<dataLen)){	
	        				if(raw[end]==93) //lokout for ]
	        					break;
	        				end++;
	        			}
	        			
	        			int nextStart=end;
	        			if(raw[end]==(int)']')
	        				nextStart=dataLen;
	        			
	        			//ignore any extra spaces
	        			while(raw[end]==32)
	        				end--;
	        			int charLength=end-i;
	        			objectName=new StringBuffer(charLength);
	        			for(int ii=0;ii<charLength;ii++)
	        				objectName.append((char)raw[ii+i]);
	        			
	        			//store
	        			nameLookup.put(objectName.toString(),getTextString(streamData));
	        			i=nextStart; //next item or exit at end
	        		}catch(Exception e){
	        			e.printStackTrace();
	        		}
	        	}
	        	
	        }else
	            LogWriter.writeLog("Name list format not supported");
	    }else if(dests!=null){
		    Map destValues=null;
		    if(dests instanceof String)
		    	destValues=readObject((String)dests,false,null);
		    else
		    	destValues=(Map) dests;
		    
		    //handle any kids
		    String kidsObj=(String)destValues.get("Kids");
		    if(kidsObj!=null){
			    String kids = Strip.removeArrayDeleminators(getValue((String) destValues.get("Kids"))); //get initial pages
			    if (kids.length() > 0) {/**allow for empty value and put next pages in the queue*/				
					StringTokenizer initialValues =new StringTokenizer(kids, "R");
					while (initialValues.hasMoreTokens())
					readNames(initialValues.nextToken().trim() + " R");
						//queue.addElement(initialValues.nextToken().trim() + " R");
				}
		    }
		}
	    
	}
	
    /**
     * convert name into object ref
     */
    public String convertNameToRef(String value) {
        
        return (String) nameLookup.get(value);
    }
    
    /**
	 * convert all object refs (ie 1 0 R) into actual data.
	 * Works recursively to cover all levels.
     * @param pageLookup
	 */
    public void flattenValuesInObject(Map formData, Map newValues,Map fields, PageLookup pageLookup,String formObject) {
        final boolean debug =false;
    	
        if(debug)
            System.out.println(formData);
        
			newValues.put("PageNumber","1");
	    	Iterator keys=formData.keySet().iterator();
	    	while(keys.hasNext()){
	    		String currentKey=(String) keys.next();
	    		Object currentValue=null;
	    		
	    		if(debug)
	                System.out.println("currentKey="+currentKey);
	    		
	    		if(currentKey.equals("P")){
	    			//add page
	    			try{
	    				String value=(String) formData.get("P");
	    				
	    				if(value!=null){
	    					int page = pageLookup.convertObjectToPageNumber(value);
	    					newValues.put("PageNumber",""+page);
	    					//currentForm.remove("P");
	    				}
	    			}catch(Exception e){
	    				//e.printStackTrace();
	    				System.err.println("addFormElementFailing");
	    				
	    			}
	    		}else if(currentKey.equals("Stream")){
	    		    /**read the stream*/
	    		    byte[] objectData =readStream(formData,formObject,false);
	    			
	    		    newValues.put("DecodedStream",objectData);
	    		}else if((!currentKey.equals("Kids"))&&(!currentKey.equals("Parent")))
	    			currentValue=formData.get(currentKey);
	    		
	    		if(debug)
	    		    System.out.println("currentValue="+currentValue);
	    		
	    		if(currentValue!=null){
	    			if(currentKey.equals("rawValue")){
		    			
		    			if(currentValue instanceof byte[]){
		    				
		    				byte[] fieldBytes=getByteTextStringValue(currentValue,fields);
		    				
		    				if(fieldBytes!=null)
		    					currentValue=getTextString(fieldBytes);
		    			}
		    		}else  if((fields!=null)&&(fields.get(currentKey)!=null)&&(currentValue instanceof byte[])){
	    				
	    				byte[] fieldBytes=getByteTextStringValue(currentValue,fields);
	    				
	    				if(fieldBytes!=null)
	    					currentValue=getTextString(fieldBytes);
	    			}
	    			
	    			if(currentValue instanceof String){ //remap xx=[1 0 R] but not [1 0 R 2 0 R]
	    				String keyString=currentValue.toString();
	    				StringTokenizer tokens=new StringTokenizer(keyString);
	    				if(tokens.countTokens()==3){
		    				int i1=keyString.indexOf(" R");
		    				int i2=keyString.indexOf(" R",i1+1);
		    				
		    				if(debug)
		    				    System.out.println("i1="+i1+" i2="+i2);
		    				
		    				if((i2==-1)&&(keyString.endsWith("]")&&(keyString.indexOf(" R")!=-1))){
		    					keyString=Strip.removeArrayDeleminators(keyString);
		    					formObject=keyString;
		    					Map stringValue=new HashMap();
		    					flattenValuesInObject(readObject(keyString,false,fields), stringValue,fields,pageLookup,formObject);
		    					newValues.put(currentKey,stringValue);
		    					
		    				}else if((i2==-1)&&(keyString.endsWith(" R"))){
		    					Map stringValue=new HashMap();
		    					formObject=keyString;
		    					flattenValuesInObject(readObject(keyString,false,fields), stringValue,fields,pageLookup,formObject);
		    					newValues.put(currentKey,stringValue);
		    				}else
		    					newValues.put(currentKey,currentValue);
	    				}else //if /CalRGB 6 0 R just put back or the moment
	    					newValues.put(currentKey,currentValue);
	    			}else if(currentValue instanceof Map){ // rewmap {N=35 0 R}
	    				Map valueMap=(Map) currentValue;
	    				Map updatedValue=new HashMap();
	    				flattenValuesInObject(valueMap, updatedValue,fields,pageLookup,formObject);
	    				newValues.put(currentKey,updatedValue);
	    			}else{
	    				newValues.put(currentKey,currentValue);
	    			}
	    		}
	    		}
	    	}
    }
