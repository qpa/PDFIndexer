/*
* ===========================================
* Java Pdf Extraction Decoding Access Library
* ===========================================
*
* Project Info:  http://www.jpedal.org
* Project Lead:  Mark Stephens (mark@idrsolutions.com)
*
* (C) Copyright 2004, IDRsolutions and Contributors.
*
* 	This file is part of JPedal
*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*
* ---------------
* PdfFontsData.java
* ---------------
* (C) Copyright 2004, by IDRsolutions and Contributors.
*
* Original Author:  Mark Stephens (mark@idrsolutions.com)
* Contributor(s):
*
* 20040223 Substantially rewritten.
*/
package org.jpedal.fonts;

//standard java
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Map;
import java.util.StringTokenizer;

import org.jpedal.PdfDecoder;
import org.jpedal.exception.PdfFontException;
import org.jpedal.io.PdfObjectReader;
import org.jpedal.utils.LogWriter;
import org.jpedal.utils.Strip;
import org.jpedal.utils.ToInteger;

/**
 * contains all generic pdf font data for fonts.<P>
 *
  */
public class PdfFont {

	static{
		setStandardFontMappings();
	}
	
	public PdfFont(){}
	
	/**get handles onto Reader so we can access the file*/
	public PdfFont(PdfObjectReader current_pdf_file) {

		init(current_pdf_file);
		
	}
	
	/**read in a font and its details for generic usage*/
	public void createFont(String fontName) throws Exception{
	}
	
	static public void setStandardFontMappings(){
		int count=StandardFonts.files_names.length;
		
        for(int i=0;i<count;i++){
        	String key=StandardFonts.files_names_bis[i].toLowerCase();
        	String value=StandardFonts.javaFonts[i].toLowerCase();
        	
        	if((!key.equals(value))&&(!PdfDecoder.fontSubstitutionAliasTable.containsKey(key)))
        		PdfDecoder.fontSubstitutionAliasTable.put(key,value);
        	
        }
        
        for(int i=0;i<count;i++){
        	
        	String key=StandardFonts.files_names[i].toLowerCase();
        	String value=StandardFonts.javaFonts[i].toLowerCase();
        	if((!key.equals(value))&&(!PdfDecoder.fontSubstitutionAliasTable.containsKey(key)))
        		PdfDecoder.fontSubstitutionAliasTable.put(key,value);
            StandardFonts.javaFontList.put(StandardFonts.files_names[i],"x");
        }
        
	}
	
	//flag to show if actually 1c
	public boolean is1C=false;

	protected String substituteFont=null;
	
	/**holds mappings for drawing the glpyhs*/
	protected Hashtable charStrings=new Hashtable();
	
	protected boolean renderPage=false;
	
	private final float xscale =(float)0.001;
		
	/**copy of Trm so we can choose if cache should be flushed*/
	protected float[][] lastTrm=new float[3][3];
	
	/**embedded encoding*/
	protected int embeddedEnc=StandardFonts.STD;
	
	/**holds lookup to map char differences in embedded font*/
	protected String[] diffs;
	
	/**lookup for font names less any + suffix*/
	private String fontName="default";

	/**flag to show if Font included embedded data*/
	public boolean isFontEmbedded=false;
		
	/**String used to reference font (ie F1)*/
	protected String fontID="";
	
	/**number of glyphs - 65536 for CID fonts*/
	protected int maxCharCount=256;
	
	/**show if encoding set*/
	protected boolean hasEncoding=true;

	/**basefont name*/
	protected String baseFontName="";
	
	/**flag to show if double-byte*/
	private boolean isDoubleByte=false;
	
	/**make 256 value fonts to f000 range if flag set*/
	protected boolean remapFont=false;
	
	/**default font to use in display*/
	protected String defaultFont = "Lucida Sans";
	
	/**used to render page by drawing routines*/
	private static FontRenderContext frc =new FontRenderContext(null, true, true);

	/**font type*/
	protected int fontTypes;
	
	protected String substituteFontFile=null,substituteFontName=null;
	
	
	/**holds lookup to map char differences*/
	private String[] diffTable;
	
	/**holds flags for font*/
	private int fontFlag=0;

	/**lookup for which of each char for embedded fonts which we can flush*/
	private float[] widthTable ;
	
	/**current font to plot, or <code>null</code> if not used yet*/
	private Font unscaledFont = null;

	
	/**handle onto file access*/
	protected PdfObjectReader currentPdfFile;

	/**loader to load data from jar*/
	protected ClassLoader loader = this.getClass().getClassLoader();
		
	/**shapes we have already drawn to speed up plotting, or <code>null</code> if there are none*/
	protected Area[] cachedShapes = null;
	
	/**FontBBox for font*/
	public double[] FontMatrix={0.001d,0d,0d,0.001d,0,0};
	
	/**font bounding box*/
	public float[] FontBBox= { 0f, 0f, 1f, 1f };
	
	/**
	 * flag to show
	 * Gxxx, Bxxx, Cxxx.
	 */
	protected boolean isHex = false ;

	/**holds lookup to map char values*/
	private String[] unicodeMappings;
		
	/**encoding pattern used for font. -1 means not set*/
	protected int fontEnc = -1;
	
	/**flag to show type of font*/
	protected boolean isCIDFont=false;
	
	/**lookup CID index mappings*/
	protected String[] CMAP;
	
	/** CID font encoding*/
	protected String CIDfontEncoding;
	
	/**default width for font*/
	private float defaultWidth=1f;
	
	protected boolean isFontSubstituted=false;

	/**list of installed fonts*/
    private static String[] fontList;

    /**test if cid.jar present first time we need it*/
	private static boolean isCidJarPresent;

	/**
	 * used to show truetype used for type 0 CID
	 */
	public boolean isFontSubstituted() {
		return isFontSubstituted;
	}
	
	/**
	 * flag if double byte CID char
	 */
	public boolean isDoubleByte() {
		return isDoubleByte;
	}
	
	/**set the default width of a CID font*/
	final protected void setCIDFontDefaultWidth(String value) {

		/**convert to float value*/
		defaultWidth=Float.parseFloat(value)/1000f;
		
	}

	/**Method to add the widths of a CID font*/
	final protected void setCIDFontWidths(String values) {

		//remove first and last []
		values = values.substring(1, values.length() - 1).trim();
		
		widthTable=new float[65536];
		
		//set all values to -1 so I can spot ones with no value
		for(int ii=0;ii<65536;ii++)
			widthTable[ii]=-1;
		
		StringTokenizer widthValues = new StringTokenizer(values, " []",true);
		
		String nextValue="";
		
		while (widthValues.hasMoreTokens()) {
			
			if(!widthValues.hasMoreTokens())
				break;
			
			while(true){
				nextValue = widthValues.nextToken();
				if(!nextValue.equals(" "))
					break;
			}
			
			int pointer = Integer.parseInt(nextValue);
			
			while(true){
				nextValue = widthValues.nextToken();
				if(!nextValue.equals(" "))
					break;
			}
			
			//process either range or []
			if (nextValue.equals("[")) {
				while(true){
					
					while(true){
						nextValue = widthValues.nextToken();
						if(!nextValue.equals(" "))
							break;
					}
					
					if(nextValue.equals("]"))
						break;
					
					widthTable[pointer]=Float.parseFloat(nextValue)/1000f;
					pointer++;
					
				}

			} else {
				
				int endPointer = 1 + Integer.parseInt(nextValue);
				
				while(true){
					nextValue = widthValues.nextToken();
					if(!nextValue.equals(" "))
						break;
				}

				for (int ii = pointer; ii < endPointer; ii++)
					widthTable[ii]=Float.parseFloat(nextValue)/1000f;
				
			}
		}
	}
	
	/**flag if CID font*/
	final public boolean isCIDFont() {

			return isCIDFont;
	}

	/**set number of glyphs to 256 or 65536*/
	final protected void init(PdfObjectReader current_pdf_file){
		
		this.currentPdfFile = current_pdf_file;
		
		//setup font size and initialise objects
		if(isCIDFont)
			maxCharCount=65536;
		
	}
	
	
	/**return unicode value for this index value */
	final private String getUnicodeMapping(int char_int){
		if(unicodeMappings==null)
			return null;
		else
		return  unicodeMappings[char_int];
	}
	
	/**store encoding and load required mappings*/
	final protected void putFontEncoding(int enc) {
		
		/**save encoding */
		fontEnc=enc;
		
		StandardFonts.checkLoaded(enc);
		
	}
	
	/**
	 * used for standard non-substituted version
	 */
	public Area getStandardGlyph(float[][]Trm,int rawInt,String displayValue,float currentWidth) {
		    
		/**flush cache if needed*/
		if((lastTrm[0][0]!=Trm[0][0])|(lastTrm[1][0]!=Trm[1][0])|
				(lastTrm[0][1]!=Trm[0][1])|(lastTrm[1][1]!=Trm[1][1])){	
			lastTrm=Trm;
			cachedShapes = null;
		}
		
		//either calculate the glyph to draw or reuse if alreasy drawn
		Area transformedGlyph2 = getCachedShape(rawInt);
		
		double dY = -1,dX=1;
		
		//allow for text running up the page
		if (((Trm[1][0] < 0)&(Trm[0][1] >= 0))|((Trm[0][1] < 0)&(Trm[1][0] >= 0))) {
			dX=1f;
			dY =-1f;
			
		}
		
		/**else if ((Trm[1][0] < 0)|(Trm[0][1] < 0)) {
		 dX=-dX;
		 dY =-dY;
		 } */
		
		if (transformedGlyph2 == null) {
			
			//remap font if needed
			String xx=displayValue;
			if((remapFont)&&(getUnscaledFont().canDisplay(xx.charAt(0))==false))
				xx=""+(char)(rawInt+ 0xf000);
			
			transformedGlyph2=getGlyph(rawInt, displayValue, currentWidth);
			
			if(transformedGlyph2!=null){
				//create shape for text using tranformation to make correct size
				AffineTransform at =new AffineTransform(dX*Trm[0][0],dX*Trm[0][1],dY*Trm[1][0],dY*Trm[1][1] ,0,0);
				
				transformedGlyph2.transform( at);
			}
			
			//save so we can reuse if it occurs again in this TJ command
			setCachedShape(rawInt, transformedGlyph2);
		
		}
		
		return transformedGlyph2;
	}
	
	
	/**
	 * convert value read from TJ operand into correct glyph<br>Also check to
	 * see if mapped onto unicode value
	 */
	final public String getGlyphValue(int rawInt) {
		
		String return_value = null;
		
		 /***/
		if(isCIDFont){
			
			//	test for unicode
			String unicodeMappings=getUnicodeMapping(rawInt);
			if(unicodeMappings!=null)
				return_value=unicodeMappings;
			
			if(return_value == null){
				
				//get font encoding
				String fontEncoding =CIDfontEncoding;
				
				if(diffTable!=null){
					return_value =diffTable[rawInt];
				}else if(fontEncoding!=null){
					if(fontEncoding.startsWith("Identity-")){
						return_value=""+(char)rawInt;
					}else if(CMAP!=null){
						String newChar=CMAP[rawInt];
						
						if(newChar!=null)
							return_value=newChar;
					}
				}
				
				if(return_value==null)
					return_value=""+((char)rawInt);
			}
			
		}else
			return_value=getStandardGlyphValue(rawInt);
		
		return return_value;
		
	}
	
	
	/**
	 * read translation table
	 * @throws PdfFontException 
	 */
	final private void handleCIDEncoding(String encodingType) throws PdfFontException 
	{
		String line = "";
		int begin, end, entry;
		boolean inDefinition = false;
		BufferedReader CIDstream=null;
		
		//lose the / on encoding type
		if(encodingType.startsWith("/"))
			encodingType=encodingType.substring(1);
		
		/**put encoding in lookup table*/
		CIDfontEncoding=encodingType;
		
		/** if not 2 standard encodings 
		 * 	load CIDMAP
		 */
		 
		if(encodingType.startsWith("Identity-")){
			
			//flag as 2 bytes
			isDoubleByte=true;
			
		}else{
			
			//test if cid.jar present on first time and throw exception if not
			if(!isCidJarPresent){
				isCidJarPresent=true;
				InputStream in=Thread.currentThread().getContextClassLoader().getResourceAsStream("org/jpedal/res/cid/00_ReadMe.pdf");
		    		if(in==null)
		    			throw new PdfFontException("cid.jar not on classpath");
			}
			
			CMAP=new String[65536];
			
			//remap values
			if(encodingType.equals("ETenms-B5-H"))
				encodingType="ETen-B5-H";
			else if(encodingType.equals("ETenms-B5-V"))
				encodingType="ETen-B5-V";

			try{
				CIDstream =new BufferedReader
				(new InputStreamReader(loader.getResourceAsStream(
					"org/jpedal/res/cid/" + encodingType), "Cp1252"));
			
				
			} catch (Exception e) {
				LogWriter.writeLog("Problem reading encoding for CID font "+fontID+" "+encodingType+" Check CID.jar installed");
			}
		
			if(encodingType.equals("UniJIS-UCS2-H"))
			    isDoubleByte=true;
			
			//read values into lookup table
			if (CIDstream != null) {
				while (true) {
					
					try{
						line = CIDstream.readLine();
						
					} catch (Exception e) {}
					
					if (line == null)
						break;
					
					if (line.indexOf("endcidrange") != -1)
						inDefinition=false;
					
					if (inDefinition == true) {
						StringTokenizer CIDentry =new StringTokenizer(line, " <>[]");
						
						//flag if multiple values
						boolean multiple_values = false;
						if (line.indexOf("[") != -1)
							multiple_values = true;
						
						//first 2 values define start and end
						begin = Integer.parseInt(CIDentry.nextToken(), 16);
						end = Integer.parseInt(CIDentry.nextToken(), 16);
						entry = Integer.parseInt(CIDentry.nextToken(), 16);
						
						//put into array
						for (int i = begin; i < end + 1; i++) {
							if (multiple_values == true) {
								//put either single values or range
								entry =Integer.parseInt(CIDentry.nextToken(), 16);	
								CMAP[i]= "" + (char)entry;
							} else {
								CMAP[i]="" + (char)entry;
								entry++;
							}
						}
					}
					if (line.indexOf("begincidrange") != -1)
						inDefinition = true;
				}
			}
		}
		
		if(CIDstream!=null){
			try{
				CIDstream.close();
			} catch (Exception e) {
				LogWriter.writeLog("Problem reading encoding for CID font "+fontID+" "+encodingType+" Check CID.jar installed");
			}
		}
		
	}	

	/**
	 * convert value read from TJ operand into correct glyph<br> Also check to
	 * see if mapped onto unicode value
	 */
	final public String getStandardGlyphValue(int char_int) {
		
		String return_value = "", unicode_char = null, mapped_char = null;
		
		//get font encoding
		int font_encoding = getFontEncoding( true);
		
		//get possible values
		unicode_char = getUnicodeMapping(char_int);
		
		mapped_char = getMappedChar(char_int,true);
		
		/**
		 * get name of character ie 32 is space
		*/
	
		//handle if unicode
		if ((unicode_char != null))// & (mapped_char==null))
			return_value = unicode_char;

		// handle if differences first then standard mappings
		else if (mapped_char != null) { //convert name into character
			
			// First check if the char has been mapped specifically for this
			String char_mapping =StandardFonts.getUnicodeName(this.fontEnc +mapped_char);
			
			if (char_mapping != null)
				return_value = char_mapping;
			else {
						
				char_mapping =StandardFonts.getUnicodeName(mapped_char);

				if (char_mapping != null)
					return_value = char_mapping;
				else {
				    if(mapped_char.length()==1){
				        return_value = mapped_char;
				    }else if (mapped_char.length() > 1) {
						char c = mapped_char.charAt(0);
						if (c == 'B' | c == 'C' | c == 'c' | c == 'G' ) {
							mapped_char = mapped_char.substring(1);
							try {
								int val =(isHex)
										? Integer.valueOf(mapped_char, 16).intValue() : Integer.parseInt(mapped_char);
								return_value = "" + (char) val;
							} catch (Exception e) {
								return_value = "";
							}
						} else
							return_value = "";
					} else
						return_value = "";
				}
			}
		} else if (font_encoding > -1) //handle encoding
			return_value=StandardFonts.getEncodedChar(font_encoding,char_int);
			
		return return_value;
	}
	
	/**set the font being used or try to approximate*/
	public final Font setFont(String font_family_name,int size) {
	   
		int style =Font.PLAIN;
		boolean isFontInstalled = false;
		String weight =null,mappedName=null;
		
		String testFont=font_family_name;
		if(font_family_name!=null)
			testFont=font_family_name.toLowerCase();
		
		//pick up any weight in type 3 font or - standard font mapped to Java
		int pointer = font_family_name.indexOf(",");
		if ((pointer == -1)&&(StandardFonts.javaFontList.get(font_family_name)!=null))
			pointer = font_family_name.indexOf("-");
		
		if (pointer != -1) {
		    
		    //see if present with ,
			mappedName=(String) PdfDecoder.fontSubstitutionAliasTable.get(testFont);
			
			weight =testFont.substring(pointer + 1, testFont.length());
			
			if (weight.indexOf("bold") != -1)
				style = Font.BOLD;
			else if (weight.indexOf("roman") != -1)
				style = Font.ROMAN_BASELINE;
			
			if (weight.indexOf("italic") != -1)
				style = style+Font.ITALIC;
			else if (weight.indexOf("oblique") != -1)
				style = style+Font.ITALIC;
			
			font_family_name = font_family_name.substring(0, pointer);
			
		}
		
		//remap if not type 3 match
		if(mappedName==null)
		mappedName=(String) PdfDecoder.fontSubstitutionAliasTable.get(testFont);
		
		if(mappedName!=null){
			font_family_name=mappedName;
			testFont=font_family_name.toLowerCase();
		}
		//see if installed
		if(fontList!=null){
			int count = fontList.length;
			for (int i = 0; i < count; i++) {
				if (fontList[i].equals(testFont)) {
					isFontInstalled = true;
					font_family_name=fontList[i];
					i = count;
				}
			}		
		}
		
		/**approximate display if not installed*/
		if (isFontInstalled == false) {
	
		    //try to approximate font
			if(weight==null){
				
				//pick up any weight
				String test = font_family_name.toLowerCase();
				if (test.indexOf("heavy") != -1)
					style = Font.BOLD;
				else if (test.indexOf("bold") != -1)
					style = Font.BOLD;
				else if (test.indexOf("roman") != -1)
					style = Font.ROMAN_BASELINE;
				
				if (test.indexOf("italic") != -1)
					style = style+Font.ITALIC;
				else if (test.indexOf("oblique") != -1)
					style = style+Font.ITALIC;
				
			}

			font_family_name = defaultFont;
		}
		
		unscaledFont = new Font(font_family_name, style, size);
		
		//System.out.println(font_family_name+" "+unscaledFont);
		
		return unscaledFont;
	}
	
	/**set the font used for default from Java fonts on system
	 * - check it is a valid font (otherwise it will default to Lucida anyway)
	 */
	public final void setDefaultDisplayFont(String fontName) throws PdfFontException{

		defaultFont=fontName;
		
	}
	
	/**
	 * Returns the unscaled font, initializing it first if it hasn't been used before.
	 */
	private final Font getUnscaledFont() {
		
		/**commenting out  this broke originaldoc.pdf*/
		if (unscaledFont == null)
			unscaledFont = new Font(defaultFont, Font.PLAIN, 1);
		
		return unscaledFont;
	}
	
	/**
	 * reset font handle
	 * @fontHandle
	public final void unsetUnscaledFont() {
		unscaledFont=null;
	}*/

	/**read in generic font details from the pdf file*/
	final protected void readGenericFontMetadata(Map values) {
		
		LogWriter.writeMethod("{readGenericFontMetadata "+ fontID+"}", 0);

		// Get font size matrix
		String fontMatrix = (String) values.get("FontMatrix");
		if (fontMatrix != null) {
			StringTokenizer tokens = new StringTokenizer(fontMatrix, "[] ");
	
			for (int i = 0; i < 6; i++){
				FontMatrix[i] =(Float.parseFloat(tokens.nextToken()));
				//System.out.println(i+" "+fontMatricies[i]);
			}
		}
				
		//Get font size matrix for type 3 font
		String fontBounding = (String) values.get("FontBBox");
		
		if (fontBounding != null) {
			StringTokenizer tokens =new StringTokenizer(fontBounding, "[] ");

			for (int i = 0; i < 4; i++)
				FontBBox[i] = Float.parseFloat(tokens.nextToken());
			
		}
		
		// Get base font name
		baseFontName =currentPdfFile.getValue((String) values.get("BaseFont"));
		
		//allow for CID name in fontname
		if(baseFontName==null)
			baseFontName =currentPdfFile.getValue((String) values.get("FontName"));
	
		//should have a name but some don't so use Name
		if (baseFontName == null)
			baseFontName = fontID;
		else
			baseFontName = baseFontName.substring(1);
		
		/**save name less any suffix*/
		fontName=baseFontName;
		int index=baseFontName.indexOf("+");
		if (index  == 6)
			fontName = baseFontName.substring(index + 1);
		
	}

	/**
	 * get font name as a string from ID (ie Tf /F1) and load if one of Adobe 14
	 */
	final public String getFontName() {
		
		//check if one of 14 standard fonts and load if needed
		StandardFonts.loadStandardFontWidth(fontName);
		
		return fontName;
	}
	
	/**
	 * get raw font name which may include +xxxxxx
	 */
	final public String getRawFontName() {
		
		return baseFontName;
	}


	final protected int getFontEncoding( boolean notNull) {
		int result = fontEnc;
		
		if (result == -1 && notNull)
			result = StandardFonts.STD;
		
		return result;
	}
	
	/** Returns width of the specified character<br>
	 *  Allows for no value set*/
	final public float getWidth( int charInt) {
		//try embedded font first (indexed by number)
		float width =-1;
		
		if(widthTable!=null)
			width =  widthTable[charInt];
		
		if (width == -1) {
			
			if(isCIDFont){
				width= defaultWidth;
				
			}else{
				
				//try standard values which are indexed under NAME of char
				String charName = getMappedChar( charInt,false);
				
				if((charName!=null)&&(charName.equals(".notdef")))
					charName=StandardFonts.getUnicodeChar(getFontEncoding( true) , charInt);
				
				Float value =StandardFonts.getStandardWidth(fontName , charName);
				
				if (value != null)
					width=value.floatValue();
				else
					width=0;
				
			}
		}
		
		return width;
	}
	
	/**generic CID code
	 * @throws PdfFontException */
	public Map createCIDFont(Map values,Map descFontValues) throws PdfFontException{
		
		Map fontDescriptor=null;
		
		/**read encoding values*/
		String encoding =(String) values.get("Encoding");
		if(encoding!=null)
			handleCIDEncoding(encoding);
		
		/**unicode settings*/
		Object toUnicode= values.get("ToUnicode");
		if(toUnicode!=null){
		    if(toUnicode instanceof String)
		        this.readUnicode(currentPdfFile.readStream((String)toUnicode),fontID);
		    else
		        this.readUnicode((byte[])((Map)toUnicode).get("DecodedStream"),fontID);
		}
		//byte[] data=currentPdfFile.readStream(unicode_value);
		/**read widths*/
		String rawWidths = currentPdfFile.getValue((String) descFontValues.get("W"));
		if(rawWidths!=null)
			setCIDFontWidths(rawWidths);
		
		/**set default width*/
		String defaultWidth = currentPdfFile.getValue((String) descFontValues.get("DW"));
		if(defaultWidth!=null)
			setCIDFontDefaultWidth(defaultWidth);
		
		/**set CIDtoGIDMap*/
		Object  CIDtoGIDvalue = descFontValues.get("CIDToGIDMap");
		if(CIDtoGIDvalue!=null){
			if(CIDtoGIDvalue instanceof String){
				String CIDtoGIDMap=(String) CIDtoGIDvalue;
				
				//load a stream object
				if(CIDtoGIDMap.endsWith(" R")){
					byte[] CIDMaps=currentPdfFile.readStream(CIDtoGIDMap);
					for(int i=0;i<CIDMaps.length;i=i+2){
						char val=(char)((CIDMaps[i]<<8)+CIDMaps[i+1]);
						putMappedChar(i, ""+val); 
					}
				}else if(CIDtoGIDMap.equals("/Identity")){
					handleCIDEncoding("Identity-");
				}else{
					LogWriter.writeLog("not yet supported in demo.");
					System.err.println("not yet supported in demo.");
				}
				
			}else{
				
				LogWriter.writeLog("not yet supported in demo.");
				System.err.println("not yet supported in demo.");
				
			}
		}
		
		/**set default font - value is mandatory*/
		Object  Info = descFontValues.get("CIDSystemInfo");
		Map CIDSystemInfo=new Hashtable();
		if(Info instanceof Map)
			CIDSystemInfo=(Map) Info;
		else
			CIDSystemInfo=currentPdfFile.readObject((String)Info,false, null);
		
		/**handle ordering*/
		String ordering=(String) CIDSystemInfo.get("Ordering");
				
		if(ordering!=null){
			
			if(ordering.indexOf("Japan")!=-1){
				
				substituteFontFile="kochi-mincho.ttf";
				substituteFontName="Kochi Mincho";
				//substituteFontFile="/home/markee/msgothic.ttf";
				//substituteFontName="msgothic";
				//substituteFontFile="/mnt/shared/KozGoPro-Medium-Acro.otf";
				//substituteFontName="kos";
			}else if(ordering.indexOf("Korean")!=-1){
System.err.println("Unsupported font encoding "+ordering);

			}else if(ordering.indexOf("Chinese")!=-1){
				System.err.println("Chinese "+ordering);
			}else{
				//System.err.println("Unsupported font encoding "+ordering);
				//LogWriter.writeLog("Unsupported font encoding "+ordering);
			}
			
			if(substituteFontName!=null)
			LogWriter.writeLog("Using font "+substituteFontName+" for "+ordering);
			
		}
		
		/**get object describing fontdescriptor and read values*/
		String fontDescriptorRef =(String) descFontValues.get("FontDescriptor");
		
		if (fontDescriptorRef != null && fontDescriptorRef.length() > 1) {
			
			fontDescriptor =currentPdfFile.readObject(fontDescriptorRef,false, null);
			
			/**read other info*/
			readGenericFontMetadata(fontDescriptor);
		}
		
		return fontDescriptor;
		
	}

	/**
	 * 
	 */
	final protected void selectDefaultFont() {
		/**load fonts for specific encoding*
		 * 
		//get list of fonts and see if installed
		String[] fontList =GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
		System.out.println(substituteFontFile+" "+this.substituteFontName);
		Hiragino Kaku Gothic Pro
Hiragino Kaku Gothic Std
Hiragino Maru Gothic Pro
Hiragino Mincho Pro

defaultFont="Hiragino Mincho Pro";

		int count = fontList.length;
		for (int i = 0; i < count; i++) {
		    System.out.println(fontList[i]);
			//if (fontList[i].equals(font_family_name)) {
			//	isFontInstalled = true;
			//	i = count;
			//}
		}	
		if(CIDfontEncoding.startsWith("GBpc-EUC")){
			substituteFontFile="kochi-mincho.ttf";
			substituteFontName="Kochi Mincho";
		}*/
	}

	/**read inwidth values*/
	public void readWidths(Map values) throws Exception{

		LogWriter.writeMethod("{readWidths}"+values, 0);
			
		// place font data in fonts array
		String firstChar = currentPdfFile.getValue((String) values.get("FirstChar"));
		int firstCharNumber = 1;
		if (firstChar != null)
			firstCharNumber = ToInteger.getInteger(firstChar);
		String lastChar = currentPdfFile.getValue((String) values.get("LastChar"));

		int count=0;
		
		//read first,last char, widths and put last into array for fast access
		String width_value =currentPdfFile.getValue((String) values.get("Widths"));
		
		if (width_value != null) {
			
			widthTable = new float[maxCharCount];

			//set all values to -1 so I can spot ones with no value
			for(int ii=0;ii<maxCharCount;ii++)
				widthTable[ii]=-1;
			
			String rawWidths =width_value.substring(1, width_value.length() - 1).trim();
			
			StringTokenizer widthValues = new StringTokenizer(rawWidths);
			
			int lastCharNumber = ToInteger.getInteger(lastChar) ;
			float widthValue;
			
			//scaling factor to convert type 3 to 1000 spacing
			float ratio=(float) (1f/FontMatrix[0]);
			if(ratio<0)
			ratio=-ratio;
			for (int i = firstCharNumber; i < lastCharNumber+1; i++) {
				
				if(!widthValues.hasMoreTokens()){
					widthValue=0;
				}else{ 
					if(fontTypes==StandardFonts.TYPE3) //convert to 1000 scale unit
						widthValue =Float.parseFloat(widthValues.nextToken())/(ratio);	
					else
						widthValue =Float.parseFloat(widthValues.nextToken())*xscale;
					
					widthTable[i]=widthValue;
					
				}
			}
		}		
	}
	
	/**read in a font and its details from the pdf file*/
	public Map createFont(Map values, String fontID,boolean renderPage,Map descFontValues) throws Exception{

		LogWriter.writeMethod("{readNonCIDFont}"+values+"{render="+renderPage, 0);
		
		
		if((fontList==null)&(renderPage)){
		    fontList =GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
	
		    //make sure lowercase
		    int count=fontList.length;
		    for (int i = 0; i < count; i++)
				fontList[i]=fontList[i].toLowerCase();
		}
		
		this.fontID=fontID;
		this.renderPage=renderPage;
		
		readGenericFontMetadata(values);
		
		// Get font type
		String fontType = (String) values.get("Subtype");
		if (fontType == null)
			fontType = "";
		
		//handle to unicode mapping
		Object toUnicode= values.get("ToUnicode");
		if(toUnicode!=null){
		    if(toUnicode instanceof String)
		        this.readUnicode(currentPdfFile.readStream((String)toUnicode),fontID);
		    else
		        this.readUnicode((byte[])((Map)toUnicode).get("DecodedStream"),fontID);
		}	
//		byte[] data=currentPdfFile.readStream(unicode_value);
		
		// place font data in fonts array
		String firstChar = (String) values.get("FirstChar");
		int firstCharNumber = 1;
		if (firstChar != null)
			firstCharNumber = ToInteger.getInteger(firstChar);
		String lastChar = (String) values.get("LastChar");
		
		int count=0;
		
		//read first,last char, widths and put last into array for fast access
		String width_value =currentPdfFile.getValue((String) values.get("Widths"));
		
		if (width_value != null) {
			
			widthTable = new float[maxCharCount];
			
			//set all values to -1 so I can spot ones with no value
			for(int ii=0;ii<maxCharCount;ii++)
				widthTable[ii]=-1;
			
			String rawWidths =width_value.substring(1, width_value.length() - 1).trim();
			
			StringTokenizer widthValues = new StringTokenizer(rawWidths);
			
			int lastCharNumber = ToInteger.getInteger(lastChar) + 1;
			float widthValue=-1;
			
			//scaling factor to convert type 3 to 1000 spacing
			float ratio=(float) (1f/FontMatrix[0]);
			ratio=-ratio;
			for (int i = firstCharNumber; i < lastCharNumber; i++) {
				
				if(widthValues.hasMoreTokens()==false)
					widthValue=0;
				else if(fontTypes==StandardFonts.TYPE3) //convert to 1000 scale unit
					widthValue =Float.parseFloat(widthValues.nextToken())/(ratio);	
				else
					widthValue =Float.parseFloat(widthValues.nextToken())*xscale;
				
				widthTable[i]=widthValue;
			
			}
		}		
		
		//get encoding info or Unicode and put in lookup table
		Object encValue =values.get("Encoding");
		
		if (encValue != null) {
			if(encValue instanceof String)
				handleFontEncoding((String) encValue,null,fontType);
			else
				handleFontEncoding("",(Map) encValue,fontType);					

		} else {
		    handleNoEncoding();
		}

		
		Map fontDescriptor = null;
		
		//get object describing font descriptor
		Object rawFont=values.get("FontDescriptor");
		
		if(rawFont instanceof String){
			String fontDescriptorRef = (String) rawFont;
			if (fontDescriptorRef != null && fontDescriptorRef.length() > 1)
				fontDescriptor =currentPdfFile.readObject(fontDescriptorRef,false, null);
		}else 
			fontDescriptor=(Map) rawFont;
			
		if(fontDescriptor!=null){
			/**handle flags and set local variables*/
			int flags=0;
			String value=(String) fontDescriptor.get("Flags");
			if(value!=null)
				flags=Integer.parseInt(value);
			
			fontFlag=flags;
			//System.err.println("fontFlag="+fontFlag);
			//reset to defaults 
			remapFont=false;
			
			int flag=fontFlag;
			if((flag & 4)==4)
				remapFont=true;
			
			//fontDescriptor =currentPdfFile.readObject(fontDescriptorRef,false, null);
			
		}
		   
		return fontDescriptor ;
	}

	/**
     * 
     */
    private void handleNoEncoding() {
        if(this.baseFontName.equals("ZapfDingbats")){
        	putFontEncoding(StandardFonts.ZAPF);
        	StandardFonts.checkLoaded(StandardFonts.ZAPF);
        	
        }else if(this.baseFontName.equals("Symbol"))
        	putFontEncoding(StandardFonts.SYMBOL);
        else
        	putFontEncoding(StandardFonts.STD); //default to standard
        hasEncoding=false;
    }

    ///////////////////////////////////////////////////////////////////////
	/**
	 * handle font encoding and store information
	 */
	final private void handleFontEncoding(String ref,Map values,String fontType){
		
		//Read fonts encoding
		int encoding = getFontEncoding( false);
		
		String encName = "";
		int encValue = encoding;
		if (encValue == -1) {
			
			if (fontType.equals("/TrueType"))
				encValue = StandardFonts.MAC;
			else
				encValue = StandardFonts.STD;
		}
		
		//allow for object and stream of commands
		if( (ref.indexOf(" ") != -1)|(values!=null)){
			
			if(values==null)
			values =currentPdfFile.readObject(ref,false, null);
			
			String baseEncoding = currentPdfFile.getValue( (String) values.get("BaseEncoding"));
			
			if (baseEncoding != null) {
				if (baseEncoding.startsWith("/"))
					baseEncoding = baseEncoding.substring(1);
				encName = baseEncoding;
				hasEncoding=true;
			}else{
			    handleNoEncoding();    
			}
			
			String diffs=currentPdfFile.getValue((String) values.get("Differences"));
			if (diffs != null) {
					
				//remove [] and then split into elements
				diffs = Strip.removeArrayDeleminators(diffs);
			
				int pointer = 0;
				String ignoreValues=" \r\n";
				StringTokenizer eachValue =new StringTokenizer(diffs," /\r\n",true);
				while (eachValue.hasMoreTokens()) {

					String value = eachValue.nextToken();
					
					if(ignoreValues.indexOf(value)!=-1){
					}else if(value.equals("/")){ //next value
					    
					    //get glyph name
					    value=eachValue.nextToken();
					    while(ignoreValues.indexOf(value)!=-1)
					    value=eachValue.nextToken();
					    
						
						putMappedChar( pointer, value);
						pointer++;

						char c=value.charAt(0);
						if (c=='B' | c=='c' | c=='C' | c=='G') {
							int i = 1,l=value.length();
							while (!isHex && i < l)
								isHex =Character.isLetter(value.charAt(i++));		
						}
					}else if (Character.isDigit(value.charAt(0))){ //new pointer
					    
					    pointer = Integer.parseInt(value);
						
					}
				}
			}
		} else
			encName = ref;
			
		if (encName.indexOf("MacRomanEncoding") != -1)
			encValue = StandardFonts.MAC;
		else if (encName.indexOf("WinAnsiEncoding") != -1)
			encValue = StandardFonts.WIN;
		else if (encName.indexOf("MacExpertEncoding") != -1)
			encValue = StandardFonts.MACEXPERT;
		else if ((encName.indexOf("STD") == -1) & (encValue == -1))
			LogWriter.writeLog("Encoding type " + encName + " not implemented");
		
		if (encValue > -1)
			putFontEncoding(encValue);
	}

	/** Insert a new mapped char in the name mapping table */
	final protected void putMappedChar(int charInt, String mappedChar) {
		
		if(diffTable==null)
			diffTable = new  String[maxCharCount];
		
		if(diffTable[charInt]==null)
		diffTable[charInt]= mappedChar;
		
	}

	/**
	 * Caches the specified shape.
	 */
	protected final void setCachedShape(int idx, Area shape) {
		// using local variable instead of sync'ing
		Area[] cache = cachedShapes;
		if (cache == null)
			cachedShapes = cache = new Area[maxCharCount];
		if(shape==null)
			cache[idx] = cache[idx] =null;
		else
			cache[idx] = cache[idx] = (Area)shape.clone();
	}
	
	
	/**
	 *holds amount of y displacement for embedded type 3font
	 */
	public double getType3Ydisplacement(int rawInt) {
		return 0;
	}

	/** Returns the char glyph corresponding to the specified code for the specified font. */
	public final String getMappedChar(int charInt,boolean remap) {
		
		String result =null;
		
		//check differences
		if(diffTable!=null)
		result =diffTable[charInt];

		if((remap)&&(result!=null)&&(result.equals(".notdef")))
			result=" ";
		
		//check standard encoding
		if (result == null)
			result =StandardFonts.getUnicodeChar(getFontEncoding( true) , charInt);

		//check embedded stream as not in baseFont encoding
		if((isFontEmbedded)&&(result==null)){
			
				//diffs from embedded 1C file
				if(diffs!=null)
					result =diffs[charInt];
				
				
				//Embedded encoding (which can be different from the encoding!)
				if ((result == null))
					result =StandardFonts.getUnicodeChar(this.embeddedEnc , charInt);
				
		}
			
		return result;
	}

	final protected String getEmbeddedChar(int charInt) {
		
		String embeddedResult=null;
		
		//check embedded stream as not in baseFont encoding
		if(isFontEmbedded){
			
			//diffs from embedded 1C file
			if(diffs!=null)
				embeddedResult =diffs[charInt];

			//Embedded encoding (which can be different from the encoding!)
			if ((embeddedResult == null))
				embeddedResult =StandardFonts.getUnicodeChar(this.embeddedEnc , charInt);
			
		}
		
		return embeddedResult;
	}

	/**
	 * read unicode translation table
	 */
	final protected void readUnicode(byte[] data, String font_ID){
		
		String line = "";
		int begin, end, entry,inDefinition = 0;
		
		BufferedReader unicode_mapping_stream =null;
		ByteArrayInputStream bis=null;
		//initialise unicode holder
		unicodeMappings = new String[maxCharCount];
		
		//get stream of data
		try {
			
			//get the data for an object
			bis=new ByteArrayInputStream(data);
			unicode_mapping_stream =new BufferedReader(new InputStreamReader(bis));
			
			//read values into lookup table
			if (unicode_mapping_stream != null) {
				while (true) {
					
					line = unicode_mapping_stream.readLine();
					
					if ((line == null))
						break;
					else if (line.indexOf("endbf") != -1)
						inDefinition = 0;	
					
					if (inDefinition == 1) {
						
						StringTokenizer unicode_entry =new StringTokenizer(line, " <>[]");
	
						//first value defines start 
						begin = Integer.parseInt(unicode_entry.nextToken(), 16);
						
						/**
						 * get raw entry and convert to string
						 */
						String rawEntry=unicode_entry.nextToken();
						String value="";
						if(rawEntry.length()<4){
							entry =Integer.parseInt(unicode_entry.nextToken(), 16);
							value=String.valueOf((char)entry);
						}else{
							for(int i=0;i<rawEntry.length();i=i+4){
								entry=Integer.parseInt(rawEntry.substring(i,i+4), 16);
								value=value+ String.valueOf((char)entry);
							}
						}
						
						//put into array
						unicodeMappings[begin]= value;	
						
					}else if (inDefinition == 2) {
						StringTokenizer unicode_entry =
							new StringTokenizer(line, " <>[]");
						
						//first value defines start 
						begin = Integer.parseInt(unicode_entry.nextToken(), 16);
						end = Integer.parseInt(unicode_entry.nextToken(), 16);
						
						//get values
						String rawEntry="";
						while (unicode_entry.hasMoreTokens())
							rawEntry=rawEntry+unicode_entry.nextToken();
						int offset=0;
						
						//put into array
						for (int i = begin; i < end + 1; i++) {
							
							String value="";
							int count=rawEntry.length();
							for(int ii=0;ii<count;ii=ii+4){
								entry=Integer.parseInt(rawEntry.substring(ii,ii+4), 16);
								
								//add offset to last value
								if(i+4>count)
									entry=entry+offset;
								
								value=value+ String.valueOf((char)entry);
							}
							unicodeMappings[i]=value;		
							offset++;
							
						}
					}
					if (line.indexOf("beginbfchar") != -1)
						inDefinition = 1;
					else if (line.indexOf("beginbfrange") != -1)
						inDefinition = 2;
					
				}
			}
			
		} catch (Exception e) {
			LogWriter.writeLog("Exception setting up text object " + e);
		}
		
		if(unicode_mapping_stream!=null){
			try {
				bis.close();
				unicode_mapping_stream.close();
			} catch (IOException e1) {
				LogWriter.writeLog("Exception setting up text object " + e1);
			}
		}
	}

	
	/**
	 * gets type of font (ie 3 ) so we can call type
	 * specific code.
	 * @return int of type 
	 */
	final public int getFontType() {
		return fontTypes;
	}
	
	/**
	 * used by  non-embedded font where not standard
	 */
	public Area getApproximateGlyph(float[][]Trm,int rawInt,String displayValue,float currentWidth) {
		
		/**flush cache if needed*/
		if((lastTrm[0][0]!=Trm[0][0])|(lastTrm[1][0]!=Trm[1][0])|
				(lastTrm[0][1]!=Trm[0][1])|(lastTrm[1][1]!=Trm[1][1])){	
			lastTrm=Trm;
			cachedShapes = null;
		}
		
		//either calculate the glyph to draw or reuse if alreasy drawn
		Area transformedGlyph2 = getCachedShape(rawInt);
		
		double dY = -1,dX=1;
		
		//allow for text running up the page
		if (((Trm[1][0] < 0)&(Trm[0][1] >= 0))|((Trm[0][1] < 0)&(Trm[1][0] >= 0))) {
			dX=1f;
			dY =-1f;
			
		}
		
		/**else
		 if ((Trm[1][0] < 0)|(Trm[0][1] < 0)) {
		 dX=-dX;
		 dY =-dY;
		 } 
		 */
		
		//boolean fontMatched=true;
		if (transformedGlyph2 == null) {
			
			//remap font if needed
			String xx=displayValue;
			if((remapFont)&&(getUnscaledFont().canDisplay(xx.charAt(0))==false))
				xx=""+(char)(rawInt+ 0xf000);
			
			/**
			//if cannot display return to Lucida
			if(getUnscaledFont().canDisplay(xx.charAt(0))==false){
				xx=displayValue;
				fontMatched=false;
			}*/
			
			/**use default if cannot be displayed*
			GlyphVector gv1=null;
			if(fontMatched){
				gv1 =getUnscaledFont().createGlyphVector(frc, xx);
			}else{
				Font tempFont = new Font(defaultFont, 0, 1);
				gv1 =tempFont.createGlyphVector(frc, xx);
			}*/
			
			GlyphVector gv1 =getUnscaledFont().createGlyphVector(frc, xx);
			
			transformedGlyph2 = new Area(gv1.getOutline());
			
			//put glyph into display position
			double glyphX=gv1.getOutline().getBounds2D().getX();
			
			AffineTransform at=null;
			
			//ensure inside box 
			if(glyphX<0){
				glyphX=-glyphX;
				at =AffineTransform.getTranslateInstance(glyphX*2,0);
				transformedGlyph2.transform(at);
			}
			
			//<start-13>
			double glyphWidth=gv1.getVisualBounds().getWidth()+(glyphX*2);
			double scaleFactor=currentWidth/glyphWidth;
			
			if(scaleFactor<1)	{
				at =AffineTransform.getScaleInstance(scaleFactor,1);
				transformedGlyph2.transform(at);
				
			}
			
			//create shape for text using tranformation to make correct size
			at =new AffineTransform(dX*Trm[0][0],dX*Trm[0][1],dY*Trm[1][0],dY*Trm[1][1] ,0,0);
			
			transformedGlyph2.transform( at);
			
			//save so we can reuse if it occurs again in this TJ command
			setCachedShape(rawInt, transformedGlyph2);
		}
		
		return transformedGlyph2;
	}
	
	/**returns a generic glyph using inbuilt fonts*/
	protected Area getGlyph(int rawInt, String displayValue,float currentWidth){
		
		boolean fontMatched=true;
		
	    /**use default if cannot be displayed*/
		GlyphVector gv1=null;
		
		//remap font if needed
		String xx=displayValue;
		
		if((remapFont)&&(getUnscaledFont().canDisplay(xx.charAt(0))==false))
			xx=""+(char)(rawInt+ 0xf000);
		
		/**commented out 18/8/04 when font code updated*/
		//if cannot display return to Lucida
		if(getUnscaledFont().canDisplay(xx.charAt(0))==false){
			xx=displayValue;
			fontMatched=false;
		}
		
		if(fontMatched){
			gv1 =getUnscaledFont().createGlyphVector(frc, xx);
		}else{
			Font tempFont = new Font(defaultFont, 0, 1);
			if(tempFont.canDisplay(xx.charAt(0))==false)
				tempFont = new Font("lucida", 0, 1);
			if(tempFont.canDisplay(xx.charAt(0)))
			gv1 =tempFont.createGlyphVector(frc, xx);
		}
		
		//gv1 =getUnscaledFont().createGlyphVector(frc, xx);
		
		Area transformedGlyph2 = null;
		if(gv1!=null){
			transformedGlyph2=new Area(gv1.getOutline());
			
			//put glyph into display position
			double glyphX=gv1.getOutline().getBounds2D().getX();
			//double maxX=gv1.getOutline().getBounds2D().getMaxX()-gv1.getOutline().getBounds2D().getWidth();
			
			AffineTransform at=null;
			
			//ensure inside box 
			if(glyphX<0){
				glyphX=-glyphX;
				at =AffineTransform.getTranslateInstance(glyphX,0);
				transformedGlyph2.transform(at);
			}
			
			//<start-13>
			//double glyphWidth=gv1.getVisualBounds().getWidth()+(glyphX*2);
			//double scaleFactor=currentWidth/glyphWidth;
			double scaleFactor=currentWidth/(transformedGlyph2.getBounds2D().getWidth());
			
			if(scaleFactor<1)	{
				at =AffineTransform.getScaleInstance(scaleFactor,1);
				transformedGlyph2.transform(at);
				
			}
		}
		
		return transformedGlyph2;
	}
	
	/**
	 * Returns the specified shape from the cache, or <code>null</code> if the shape
	 * is not in the cache.
	 */
	protected final Area getCachedShape(int idx) {
		// using local variable instead of sync'ing
		Area[] cache = cachedShapes;

		if(cache==null)
			return null;
		else{
			Area currentShape=cache[idx];
			
			if(currentShape==null)
				return null;
			else
				return  (Area)currentShape.clone(); 
		}
		//return cache == null ? null : (Area)cache[idx].clone();
		//return cache == null ? null : cache[idx];
	}
	

	/**
	 * name of font used to display
	 */
	public String getSubstituteFont() {
		return this.substituteFontName;
	}

	/**
	 * test if there is a valid value
	 */
	public boolean isValidCodeRange(int rawInt) {
		if(CMAP==null)
			return false;
		else{
			System.out.println(CMAP[rawInt]+"<<"+rawInt);
			return (CMAP[rawInt]!=null);
		}
	}

	/**used in truetype code in generic renderer*/
	public float getTTWidth(String charGlyph, int rawInt, String displayValue) {
		// TODO Auto-generated method stub
		return 0;
	}

	public PdfGlyph getEmbeddedGlyph(GlyphFactory factory, String charGlyph, float[][] trm, int rawInt, String displayValue, float currentWidth) {
		// TODO Auto-generated method stub
		return null;
	}

	/**set subtype (only used by generic font*/
	public void setSubtype(int fontType) {
		this.fontTypes=fontType;
		
	}
}
