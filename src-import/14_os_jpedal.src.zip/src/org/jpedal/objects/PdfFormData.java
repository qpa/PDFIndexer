/*
* ===========================================
* Java Pdf Extraction Decoding Access Library
* ===========================================
*
* Project Info:  http://www.jpedal.org
* Project Lead:  Mark Stephens (mark@idrsolutions.com)
*
* (C) Copyright 2003, IDRsolutions and Contributors.
* 
* 	This file is part of JPedal
*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*
* ---------------
* PdfFormData.java
* ---------------
* (C) Copyright 2002, by IDRsolutions and Contributors.
*
* Original Author:  Mark Stephens (mark@idrsolutions.com)
* Contributor(s):
*/
package org.jpedal.objects;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.jpedal.exception.PdfException;
import org.jpedal.utils.Strip;
import org.w3c.dom.Document;

/**
 * Added as a repository to store form data in so that it can be reused. 
 * Data stored in a List - each element is a Map
 */
public class PdfFormData
{
	
	/**
	 * list of elements - each element is a form object from the pdf
	 */
	private java.util.List formObjects=new Vector();
	
	final public static int XFA_TEMPLATE=0;
	
	final public static int XFA_DATASET=1;
	
	final public static int XFA_CONFIG=2;
	
	private StringBuffer xfaTemplate=null;
	private StringBuffer xfaDataset=null;
	private StringBuffer xfaConfig=null;
	
   
	/**numbwer of elements*/
	private int formCount=0;
	
	/**flag to show if we truncate*/
	private boolean isDemo=false;

	private static boolean failed;
	
	public PdfFormData(boolean isDemo){
		this.isDemo=isDemo;
	}
	
	/**
	 * flag to show if XFA (not yet implemented)
	 */
	public boolean hasXFAFormData(){
		return false;
	}
	
	/**
	 * (NOT LIVE)
	 * @throws PdfException
	 */
	public Document getXFAFormData(int type) throws PdfException{
	    
	    if(type==XFA_TEMPLATE)
	        return null;
	    else  if(type==XFA_DATASET)
	    	return null;
	    else  if(type==XFA_CONFIG)
		    return null;
	    else
	        throw new PdfException("Unknown type for XFA");
	        
	}
	
	/**
	 * (NOT LIVE)
	 * @throws PdfException
	 */
	public void setXFAFormData(int type,StringBuffer content) throws PdfException{
	    
	    if(type==XFA_TEMPLATE)
	       xfaTemplate=content;
	    else  if(type==XFA_DATASET)
	        xfaDataset=content;
	    else  if(type==XFA_CONFIG)
	        xfaConfig=content;
	    else
	        throw new PdfException("Unknown type for XFA");
	        
	}
	
	/**<p>Used internally to add a form object as it is extracted from the pdf stream. 
	 * Should not need to be called in normal usage.
	*/
	public void addFormElement(Map currentForm){
		
		String value;
		/**get values*/
		try{
			value=(String) currentForm.get("V"); 
			if(value!=null){
				currentForm.put("V",makeDemo(stripBrackets(value)));
			}
		}catch(Exception e){
			if(failed){
				PdfFormData.failed=true;
				System.err.println("addFormElementFailing");
			}
		}
		
/*		String[] standardValues={"FT","TM","TU","T"};
		String[] key={"type","mapName","userName","fieldName"};
		
		for(int i=0;i<standardValues.length;i++){
			value=(String) currentForm.get(standardValues[i]);
			if(value!=null){
				//strip the / off the /Tx and other types
				if((i==0)&&(value.startsWith("/")))
					value=value.substring(1);
				currentForm.put(key[i],value);
				currentForm.remove(standardValues[i]);
			}
		}*/
		
		Iterator iter = currentForm.keySet().iterator();
		while(iter.hasNext()){
		    Object localKey = iter.next();
		    Object localValue = currentForm.get(localKey);
		    if(localValue instanceof String){
			    value = (String) localValue;
			    if(value!=null){
			        if(value.startsWith("/"))
			            value=value.substring(1);
			        currentForm.put(localKey,value);
			    }
		    }
		}
		
		//add rectangle
		value=(String) currentForm.get("Rect");
		if(value!=null)
			currentForm.put("Rect",Strip.removeArrayDeleminators(value));
		
		/**and put into data object*/
		
		//if(fieldName!=null){
		formObjects.add(formCount,currentForm);
		formCount++;
		//System.out.println(currentForm);
		//}
		
	}
	
	/**remove brackets*/
	private String stripBrackets(String value){
	
		if(value.startsWith("("))
		value=value.substring(1);
		
		if(value.endsWith(")"))
		value=value.substring(0,value.length()-1);
		
		return value;
	}
	
	
	/**add in demo limit*/
	private String makeDemo(String value){
		
		/**alter data in demo version*/
		if (isDemo & (value != null)) {
			StringBuffer textData=new StringBuffer(value);
			int len = textData.length();
			for (int ii = 0; ii < len; ii = ii + 4) {
				
				textData.replace(ii, ii + 1, "1");
				
			}
			value=textData.toString();
		}
		return value;
	}
	
	/**
	 * get all data as list of items with each Form item stored in a Map
	 */
	final public List getFormData()
	{
		
		return formObjects;
	}
	
}
