/*
* ===========================================
* Storypad
* ===========================================
*
* Project Info:  http://www.idrsolutions.com
* Project Lead:  Mark Stephens (mark@idrsolutions.com)
*
* (C) Copyright 2002, IDRsolutions and Contributors.
*
* ---------------
* FileFilterer.java
* ---------------
* (C) Copyright 2002, by IDRsolutions and Contributors.
*
* Original Author:  Mark Stephens (mark@idrsolutions.com)
* Contributor(s):
*
* $Id: FileFilterer.java,v 1.1 2005/05/03 11:59:01 chris Exp $
*
* Changes (since 01-Jun-2002)
* --------------------------
*/
package org.jpedal.examples.simpleviewer.utils;
import java.io.File;

/**
 * Used in GUI example code Scope:<b>(All)</b>
 * <p>Provides filters for save dialogs
 *<p>&nbsp;
 * <p>(based on p362 in Oreilly swing)
 * <P>
 * 
 */
public class FileFilterer extends javax.swing.filechooser.FileFilter
{
	String[] extensions;
	String description;
	
	//number off possible values
	int  items = 0;
	
	//setup file and descriptor
	public FileFilterer( String[] ext, String desc ) 
	{
		items = ext.length;
		
		//setup as lower case list
		extensions = new String[items];
		for( int i = 0;i < items;i++ )
		{
			extensions[i] = ext[i].toLowerCase();
			
			//and add a description
			description = desc;
		}
	}
	final public String getDescription()
	{
		return description;
	}
	final public boolean accept( File f )
	{
		boolean accept_flag = false;
		
		//allow directories
		if( f.isDirectory() )
			accept_flag = true;
		else
		{
			//check file against list
			String file_name = f.getName().toLowerCase();
			for( int i = 0;i < items;i++ )
			{
				if( file_name.endsWith( extensions[i] ) )
					accept_flag = true;
			}
		}
		return accept_flag;
	}
}
