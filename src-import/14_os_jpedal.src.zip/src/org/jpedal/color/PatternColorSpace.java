/*
* ===========================================
* Java Pdf Extraction Decoding Access Library
* ===========================================
*
* Project Info:  http://www.jpedal.org
* Project Lead:  Mark Stephens (mark@idrsolutions.com)
*
* (C) Copyright 2003, IDRsolutions and Contributors.
*
* 	This file is part of JPedal
*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*
* ---------------
* PatternColorSpace.java
* ---------------
* (C) Copyright 2003, by IDRsolutions and Contributors.
*
* Original Author:  Mark Stephens (mark@idrsolutions.com)
* Contributor(s):
*
*
*/
package org.jpedal.color;

import java.awt.Color;
import java.awt.GradientPaint;
import java.util.HashMap;
import java.util.Map;

import org.jpedal.io.PdfObjectReader;
import org.jpedal.utils.Strip;

/**
 * handle Pattern ColorSpace
 */
public class PatternColorSpace
	extends GenericColorSpace{
		
	PdfObjectReader currentPdfFile=null;
	
	public PatternColorSpace(String currentColorspace,Map colorValues,PdfObjectReader currentPdfFile){	
		
		value = ColorSpaces.Pattern;
		
		currentColor = Color.white;
		
		this.currentPdfFile = currentPdfFile;
		
	}
	
	/**
	 * convert color value to pattern
	 */
	public void setColorXX(String[] value_loc,int operandCount){
		
		final String key = (value_loc[0]).substring(1);
		Map patternValue=null;
		final Object raw = patternValues.get(key);
		if(raw instanceof Map){
			patternValue = (Map) raw;}
		else {
			patternValue = currentPdfFile.readObject((String)raw,false,null);}
		
		System.out.println(patternValue);
		
		final int shadingType = Integer.parseInt(((String) patternValue.get("PatternType")));
		
		/**
		 * set pattern
		 */
		if((shadingType == 1)){ //tiling
		}else if((shadingType == 2)){ //shading
			Map shadingValue=currentPdfFile.readObject((String)patternValue.get("Shading"),false,null);
			
			/**
			 * substitute values
			*/
			//convert any colorspace value into an object
			String raw_colorspace_name =(String) shadingValue.get("ColorSpace");
			if((raw_colorspace_name != null)){
			raw_colorspace_name = Strip.removeArrayDeleminators(raw_colorspace_name);}
			
			GenericColorSpace decodeColorData=new GenericColorSpace();
			if((raw_colorspace_name != null)){
				
				if(raw_colorspace_name.startsWith("/")){ //allow for direct value like /DeviceRGB
					decodeColorData = ColorspaceDecoder.getColorSpaceInstance(raw_colorspace_name,null,currentPdfFile);
				}else{
					final Map colorspaceValues = currentPdfFile.getSubDictionary(raw_colorspace_name);
					raw_colorspace_name = (String)colorspaceValues.get("rawValue");			
					decodeColorData = ColorspaceDecoder.getColorSpaceInstance(raw_colorspace_name,colorspaceValues,currentPdfFile);
				}
			}
			shadingValue.put("ColorSpace",decodeColorData);
			
			System.out.println(">>>>"+shadingValue);
			
			//convert any other data
			final Map newValue = new HashMap();
			currentPdfFile.flattenValuesInObject(shadingValue,newValue,null,null,null);
			shadingValue = newValue;
			
			//create a shading object
			final GradientPaint gp = new GradientPaint(75.0f,75.0f,Color.white,95.0f,95.0f,Color.gray,true);
			
			System.out.println(">>>>"+shadingValue);
			
			System.exit(1);
			//Paint shading=(Paint) new GradientPaintFill();//new Type2ShadedPaint(shadingValue);
			this.currentColor = gp;
		}else{
		}
		
		final String objectRef = ((String) patternValue.get("Shading"));
		
		/**
		System.out.println(currentPdfFile.readObject((String)objectRef,false,null));
		//System.exit(1);
		if(objectRef!=null){
			
			//decode and create grahpic of glyph
			PdfStreamDecoder glyphDecoder=new PdfStreamDecoder();
			DynamicVectorRenderer glyphDisplay=new DynamicVectorRenderer(false,3);
			try{
				 glyphDecoder.init(false,false,0,0,new PdfPageData(),0,glyphDisplay,currentPdfFile,new Hashtable(),new Hashtable());
				 /***//**
			}catch(Exception e){
				LogWriter.writeLog("Font exception with shading  "+e);
			}
			
			int  renderX=glyphDecoder.decodePageContent(objectRef,0,0);
			
			BufferedImage shadedImage=new BufferedImage(800,800, BufferedImage.TYPE_INT_ARGB);
			glyphDisplay.paint((Graphics2D) shadedImage.getGraphics(),null);
			ShowGUIMessage.showGUIMessage("x",shadedImage,"x");
			glyphDecoder=null;
			//return new T3Glyph(glyphDisplay, renderX);
		}*/
		
	}
	
	

	

}