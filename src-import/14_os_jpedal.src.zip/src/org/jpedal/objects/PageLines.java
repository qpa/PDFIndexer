/*
* ===========================================
* Java Pdf Extraction Decoding Access Library
* ===========================================
*
* Project Info:  http://www.jpedal.org
* Project Lead:  Mark Stephens (mark@iFdrsolutions.com)
*
* (C) Copyright 2003, IDRsolutions and Contributors.
*
* 	This file is part of JPedal
*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*
* ---------------
* PageLines.java
* ---------------
* (C) Copyright 2002, by IDRsolutions and Contributors.
*
* Original Author:  Mark Stephens (mark@idrsolutions.com)
* Contributor(s):
*
*/
package org.jpedal.objects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import org.jpedal.utils.repositories.Vector_Float;
import org.jpedal.utils.repositories.Vector_Int;
import org.jpedal.utils.repositories.Vector_Rectangle;

/**
 * @author markee
 *
 * holds data on lines on the page - used internally by IDR (not part of API)
 */
public class PageLines {
    
    private int initSize=20;
    
    //co-ords of tiny lines which may fit together
    private Vector_Int t_x1 = new Vector_Int(initSize);
    private Vector_Int t_x2 = new Vector_Int(initSize);
    private Vector_Int t_y1 = new Vector_Int(initSize);
    private Vector_Int t_y2 = new Vector_Int(initSize);
    
    //co-ords of lines
    private Vector_Float v_x1 = new Vector_Float(initSize);
    
    private Vector_Float v_x2 = new Vector_Float(initSize);

    private Vector_Float v_y1 = new Vector_Float(initSize);

    private Vector_Float v_y2 = new Vector_Float(initSize);
    
    private Vector_Rectangle v_shape = new Vector_Rectangle(initSize);
    
    private Vector_Float h_x1 = new Vector_Float(initSize);
    
    private Vector_Float h_x2 = new Vector_Float(initSize);

    private Vector_Float h_y1 = new Vector_Float(initSize);

    private Vector_Float h_y2 = new Vector_Float(initSize);
    
    private Vector_Rectangle h_shape = new Vector_Rectangle(initSize);
    
    
    /** holds dividing line found when test for vertical line */
    private float vertical_x_divide = -1;

    
    /**
     * test to see if any horizontal line between either points
     */
    final public boolean testHorizontalBetween(float line_min_width,
            float a_x1, float a_x2, float a_y1, float a_y2, float b_x1,
            float b_x2, float b_y1, float b_y2) {
        boolean has_divide = false;
        int line_count = h_x1.size(); //scan all lines
        float overlap_x1 = 0, overlap_x2 = 0;
        float temp, line_width, line_width_a, line_width_b;
        
        final float[] l_x1, l_x2, l_y1, l_y2;
        l_x1=this.h_x1.get();
        l_x2=this.h_x2.get();
        l_y1=this.h_y1.get();
        l_y2=this.h_y2.get();
        
        
        if (a_y2 < b_y1) { //make sure a is the top item
            temp = a_y1;
            a_y1 = b_y1;
            b_y1 = temp;
            temp = a_y2;
            a_y2 = b_y2;
            b_y2 = temp;
        }

        //calculate widths & choose smaller
        line_width_a = a_x2 - a_x1;
        line_width_b = b_x2 - b_x1;
        if (line_width_a < line_width_b)
            line_width = line_width_a;
        else
            line_width = line_width_b;

        //workout overlap
        if (a_x1 > b_x1)
            overlap_x1 = a_x1;
        else
            overlap_x1 = b_x1;
        if (a_x2 < b_x2)
            overlap_x2 = a_x2;
        else
            overlap_x2 = b_x2;
        
        for (int i = 0; i < line_count; i++) {
            
            //ignore lines out of range
            if((l_y1[i]<a_y1)|(l_y2[i]>a_y2)){
	            //check fits min requirement first (-1 for don't bother)
	            if ((line_min_width == -1) | (line_min_width > l_x2[i] - l_x1[i])) {
	                //check line is longer than either shape and fits between on x
	                // and y
	                if ((l_x2[i] - l_x1[i] > line_width) && (overlap_x1 >= l_x1[i])
	                        && (overlap_x2 <= l_x2[i]) && (a_y2 > l_y1[i])
	                        && (b_y1 < l_y2[i])) {
	                    has_divide = true;
	                    i = line_count;
	                }
	            }
            }
        }

        return has_divide;
    }
    
    /**
     * test to see if any horizontal line between either points
     */
    final public boolean testHorizontalBetweenLines(float a_x1, float a_x2, float a_y1, float a_y2, float b_x1,
            float b_x2, float b_y1, float b_y2) {
        
    	boolean has_divide = false;
        
        float overlap_x1 = 0, overlap_x2 = 0;
        float temp, line_width, line_width_a, line_width_b;
        
        final float[] l_x1, l_x2, l_y1, l_y2;
        l_x1=this.h_x1.get();
        l_x2=this.h_x2.get();
        l_y1=this.h_y1.get();
        l_y2=this.h_y2.get();
        
        int line_count = l_x1.length;//scan all lines
        
        
        if (a_y2 < b_y1) { //make sure a is the top item
            temp = a_y1;
            a_y1 = b_y1;
            b_y1 = temp;
            temp = a_y2;
            a_y2 = b_y2;
            b_y2 = temp;
        }

        int  midAx=(int)((a_x1+a_x2)/2);
        int  midBx=(int)((b_x1+b_x2)/2);
        
        for (int i = 0; i < line_count; i++) {
            
            //ignore lines out of range
            if((l_y1[i]<a_y1)&&(l_y2[i]>b_y2)){
	            
	                //check line is longer than either shape and fits between on x
	                // and y
	                if ((l_x1[i]<midAx)&&(l_x1[i]<midBx)&&(l_x2[i]>midAx)&&(l_x2[i]>midBx)) {
	                    has_divide = true;
	                    i = line_count;
	                }
	            
            }
        }

        return has_divide;
    }
    
    /**
     * test to see if any horizontal line between either points
     */
    final public boolean testVerticalBetween(float a_x1, float a_x2,
            float a_y1, float a_y2, float b_x1, float b_x2, float b_y1,
            float b_y2) {
        //reset value to default
        vertical_x_divide = -1;

        boolean has_divide = false;
        int line_count = v_x1.size(); //count
        float overlap_y1 = 0, overlap_y2;
        float temp, line_height, line_height_a, line_height_b;
        final float[] l_x1, l_x2, l_y1, l_y2;
        l_x1=this.v_x1.get();
        l_x2=this.v_x2.get();
        l_y1=this.v_y1.get();
        l_y2=this.v_y2.get();
        
        if (a_x1 > b_x1) { //make sure a is the left item
            temp = a_x1;
            a_x1 = b_x1;
            b_x1 = temp;
            temp = a_x2;
            a_x2 = b_x2;
            b_x2 = temp;
        }

        //calculate heights & choose smaller
        line_height_a = a_y1 - a_y2;
        line_height_b = b_y1 - b_y2;
        if (line_height_a < line_height_b)
            line_height = line_height_a;
        else
            line_height = line_height_b;

        //workout overlap
        if (a_y1 > b_y1)
            overlap_y1 = b_y1;
        else
            overlap_y1 = a_y1;
        if (a_y2 < b_y2)
            overlap_y2 = b_y2;
        else
            overlap_y2 = a_y2;
        
        for (int i = 0; i < line_count; i++) {
            
            //ignore lines out of range
            if((l_x1[i]<a_x1)|(l_x2[i]>a_x2)){
	            //check line is longer than either shape and fits between on x and
	            // blocks overlap on shapes
	            if (((l_y1[i] - l_y2[i]) > line_height) && (overlap_y1 < l_y1[i])
	                    && (l_y2[i] < overlap_y2) && (a_x2 < l_x1[i]) && (b_x1 > l_x2[i])) {
	                has_divide = true;
	                vertical_x_divide = l_x1[i];
	                i = line_count;
	            }
            }
        }
        return has_divide;
    }
    
    /**return x value found on last test for vertical line*/
    final public float getVerticalLineX() {
        return vertical_x_divide;
    }
    
    /**add line on page*/
    final public void addVerticalLine(float x1, float y1,float x2, float y2) {
        
        //have sure y1 above y2
        if(y1<y2){
            float tmp=y1;
            y1=y2;
            y2=tmp;
            tmp=x1;
            x1=x2;
            x2=tmp;
        }
        
        v_x1.addElement(x1);
        v_x2.addElement(x2);
        v_y1.addElement(y1);
        v_y2.addElement(y2);
        
        v_shape.addElement(new Rectangle((int)x1,(int)y2,(int)(x2-x1),(int)(y1-y2)));
    
    }
    
    /**add line on page*/
    final public void addHorizontalLine(float x1, float y1,float x2, float y2) {
        
        //have sure x1 on left
        if(x1>x2){
            float tmp=y1;
            y1=y2;
            y2=tmp;
            tmp=x1;
            x1=x2;
            x2=tmp;
        }
        
        h_x1.addElement(x1);
        h_x2.addElement(x2);
        h_y1.addElement(y1);
        h_y2.addElement(y2);
        
        h_shape.addElement(new Rectangle((int)x1,(int)y2,(int)(x2-x1),(int)(y1-y2)));
      
    }

    /**
     * add lines to display
     */
    public void drawLines(Graphics2D g2) {
        try{
        g2.setColor(Color.red);
        
        //draw vertical lines
        int count=v_shape.size();
        
        for (int i = 0; i < count; i++){
            Rectangle rect=v_shape.elementAt(i);
            if(rect!=null)
	        g2.draw(rect);
        }
        //and horizontal
        count=h_shape.size();
        
        for (int i = 0; i < count; i++){
            Rectangle rect=h_shape.elementAt(i);
            
            if(rect!=null)
	        g2.draw(rect);
            
        }
	        
        }catch(Exception e){
            e.printStackTrace();
        }
    }

	/**
	 * take all tint sublines and see if they appear to make a whole line
	 */
	public void lookForCompositeLines() {
		
		//copy to local arrays for speed!
		int[] x1=t_x1.get();
		int[] y1=t_y1.get();
		int[] x2=t_x2.get();
		int[] y2=t_y2.get();
		
		int count=x1.length;
		
		boolean debug=false;
		
		//iniital values
		int current_x1=x1[0];
		int current_y1=y1[0];
		int current_x2=x1[0];
		int current_y2=y2[0];
		
		int matches=3;
		//look for horizontal lines
		for(int p=1;p<count;p++){
			
			//ignore empty values in array
			if((x1[p]==0)&&(y1[p]==0)&&(x2[p]==0)&&(y2[p]==0))
					continue;
			
			/**
			if((x1[p]>26)&&(y2[p]>461)&&
					(x2[p]<100)&&
					(y1[p]<500)){
				System.out.println(x1[p]+" "+y1[p]+" "+x2[p]+" "+y2[p]);
				debug=true;
			}else
				debug=false;*/
			
			
			if(debug)
			System.out.println(p+" Testing "+x1[p]+" "+y1[p]+" "+x2[p]+" "+y2[p]);
			
			boolean onLine=Math.abs(current_y1-y1[p])<2;
			
			//if its on the same line and less than 10 pixels away, regard as continuous
			if((onLine)&&((Math.abs(x1[p]-current_x2)<10)|(Math.abs(x2[p]-current_x1)<10))){
				if(current_x2<x2[p])
					current_x2=x2[p];
				else if(current_x1>x1[p])
					current_x1=x1[p];
				
				if(debug)
				System.out.println("ON line");
			}else if((current_x1!=current_x2)){ //end of line (second test allow for underneath
				
				//must be over 10 pixels long to avoid spurious match
				if(current_x2-current_x1>10){
					if(debug)
					System.out.println("====================Line found "+current_x1+" "+current_y1+" "+current_x2+" "+current_y2);
					
					//add line
					addHorizontalLine(current_x1, current_y1,current_x2, current_y1);
				}else if(debug)
					System.out.println("Too short "+current_x1+" "+current_x2);
				
				//use new  default values
				current_y1=y1[p];
				current_x1=x1[p];
				current_x2=x1[p];
				current_y2=y2[p];
				
			}else{ //try again
				if(debug)
				System.out.println("NO");
				current_y1=y1[p];
				current_x1=x1[p];
				current_x2=x2[p];
				current_y2=y2[p];
			}
		}
		
		//check for last line on exit
		if((current_x1!=current_x2)&&(current_x2-current_x1>50)){ //end of line
			if(debug)
			System.out.println("Line found "+current_x1+" "+current_y1+" "+current_x2+" "+current_y2);
			
			addHorizontalLine(current_x1, current_y1,current_x2, current_y1);
		}
		
		//System.exit(1);
		
		//flush values
		t_x1.clear();
		t_y1.clear();
		t_x2.clear();
		t_y2.clear();
		
	}

	/**
	 * add tiny lines to allow for long valid lines drawn as set of small lines we would miss
	 */
	public void addPossiblePartLine(int x1, int y1, int x2, int y2) {
		
		t_x1.addElement(x1);
		t_y1.addElement(y1);
		t_x2.addElement(x2);
		t_y2.addElement(y2);
		
	}

}
